---
name: peps-cambridge-maths-quiz
description: Create interactive, auto-marked online Maths quizzes, worksheets and practice sheets for Providence English Private School (PEPS) aligned to Cambridge Primary Mathematics 0096 (Years 1–6) and Lower Secondary Mathematics 0862 (Years 7–9), tagged with Cambridge objective codes (e.g. 4Nf.03, 8Ae.06), as one branded web page with instant marking, the PEPS five-band Cambridge Attainment Rubric with each learner's level highlighted, results saved to the school's Google Drive, and a teacher answer key. Use whenever a teacher asks for an online, interactive or self-marking maths quiz, worksheet or practice sheet, test, practice quiz, exit ticket, homework check or Checkpoint-style practice for Year/Stage 1–9, or mentions Cambridge maths objective codes or strands — even without saying "interactive" or "PEPS". For printed/Word papers use peps-cambridge-maths-paper; for IGCSE use peps-cambridge-assessments; for science use peps-cambridge-science-quiz.
---

# PEPS Cambridge Maths — interactive auto-marked quizzes

Produces a single `.html` quiz that works in any browser (laptop, tablet, phone) and is uploaded to the school's GitHub Pages site or shared by link. Quizzes are taken **in class**:

1. The start screen shows *Year · Mathematics · Quiz number · today's date*, the title and the facts (questions, marks, time).
2. The learner picks their **Section** (4A, 4B …), types the **4-digit class code** the teacher writes on the board, presses **Show my class**, and picks **their name** from the list. No typing of names, no logins.
3. They answer and are marked instantly. The results page follows the PEPS Cambridge Attainment Rubric: student header (Name / Class / Section / Date / Teacher / Marks), overall level, a 4-column objective summary, the full five-band rubric table with the learner's band highlighted ★ per objective, and a question-by-question review.
4. The report is saved automatically as a PDF in the school's Drive: `PEPS Quiz Results / Mathematics / Year 4 / 4B / Q03 – Fractions Unit Quiz /`, with a summary Sheet per section and one per year group (first attempt marked **Official**). Teachers see only their own classes; HODs their subject; SLT everything.

Class lists, class codes, teachers and access live in the school's private **School Setup Sheet**; names never appear in the quiz file. The results service (`assets/results_service.gs`) is already set up by the school once — see `references/results-and-drive.md`.

Quality depends on three things: every question genuinely tests the tagged objective at the right stage, every answer is correct and markable in all the ways a child might reasonably type it, and nothing gives marks away. The workflow protects all three.

## Files
- `scripts/build_quiz.py` — spec.json → quiz `.html` (+ `--key` answer key; `--preview` builds a copy that does not save results, for checking and teacher previews). Validates objective codes, answers, marks and the quiz number; prints coverage. Read `references/spec-format.md` before writing a spec.
- `scripts/check_quiz.py` — opens a **preview** build in headless Chromium, answers every question correctly / blank / wrong through the real controls, confirms 100 % / 0 % / 0 %, and saves screenshots + `contact_sheet.png`. **Always run it.**
- `scripts/figures.py` — SVG helpers: clocks, number lines, bar charts, pictograms, fraction shapes, labelled polygons, angles, squared-grid shapes, coordinate grids, base-10 blocks, arrays, counters, tally, 2D/3D shapes, jugs/thermometers/rulers, Venn, pie and line graphs. See the module docstring.
- `references/objectives-primary.md` (Stages 1–6) and `references/objectives-lower-secondary.md` (Stages 7–9, plus TWM) — the full Cambridge objective lists with codes. Read only the stage you need: `sed -n '/^## Stage 5/,/^## Stage 6/p' references/objectives-primary.md`.
- `references/question-design.md` — choosing question types, writing distractors, age-appropriate language and layout, marking pitfalls per type.
- `references/rubric.md` — the PEPS Cambridge Attainment Rubric rules and how to write the rubric text. **Read before writing a spec.**
- `references/results-and-drive.md` — how results reach Google Drive, and what to tell a teacher if saving fails.
- `references/quality-checklist.md` — pre-delivery checks.
- `references/example_make_spec.py` — worked Year 4 fractions quiz: answer checks in Python, figures, and a complete rubric.
- `references/example_worksheet_spec.py` — worked Year 4 fractions online worksheet (Remember box, Challenge, points, rubric).
- `assets/quiz_template.html` (engine), `assets/school_config.json` (subject, programme names, the school's results-service URL, sections), `assets/results_service.gs` (the school's Google Apps Script), `assets/peps_logo.jpg`.

## Workflow

### 1. Pin down the request
Needed: **type** (quiz / worksheet / practice sheet) · **Year** (1–9) · **quiz number** (quizzes only) · **topic or objective codes** · **number of questions / marks** · **mode** (test or practice) · **time limit**. (The teacher's name on each report comes automatically from the School Setup Sheet for the section the learner picks — no need to ask.) Take what the teacher gave; ask once, briefly, only for what's genuinely missing. If it isn't clear whether they want an online quiz or a printed Word paper, ask (printed → peps-cambridge-maths-paper). **For quizzes the number is always the teacher's choice — never invent it; ask if it is missing** (worksheets have no number) (it names the Drive folders and files). Sensible defaults for the rest (state them in the reply):
- Year N = Cambridge Stage N (PEPS mapping). Years 1–6 → Primary 0096, Years 7–9 → Lower Secondary 0862.
- Length: Years 1–2 → 8–10 questions, no timer; Years 3–4 → 12–15 questions, 20–25 min; Years 5–6 → 15–20 questions, 30 min; Years 7–9 → 15–20 questions (20–30 marks), 30–40 min.
- Mode `test` (marked at the end, one attempt) unless the teacher says practice / homework / revision → `practice` (Check after each question, hints, retry allowed).
- Calculator: not allowed unless stated (Primary and Checkpoint Paper 1 style).

Scope rule: a topic name ("fractions") means the objectives of **that stage** in the matching sub-strand(s). If the teacher gives codes, use exactly those. Never pull objectives from a higher stage; earlier-stage content only as a clearly-labelled warm-up if asked (then set `allow_other_stages`).

### 2. Plan
Read the stage section of the objectives file and `references/question-design.md`. Draft a blueprint: for each question — objective code, type, marks, what it tests. Spread marks sensibly across the requested objectives, mix types (not all MCQ), and order easy → hard. For MCQ, plan an even spread of answer letters.

Because every objective gets its own rubric row with mark ranges from that objective's marks, give **each objective at least 4–5 marks** (ideally 5+) so all five bands are reachable; prefer 3–5 objectives with more marks each over many 1-mark objectives. With 1–3 marks some bands have no whole-mark score (the rubric then says so, as in the PEPS sample).

### 3. Write questions and verify every answer
Write the question, answer, accepted alternatives and a one- or two-line explanation together. **Compute every numeric answer and every distractor in Python** before putting it in the spec — never mental arithmetic. Record which misconception each distractor represents. Think about every way a learner could correctly type the answer (units, commas, `0.5` vs `.5`, `2x+15` vs `15+2x`, `(4, 2)` vs `4,2`) and make sure each is accepted by the chosen type (see question-design.md).

Language: short sentences, one instruction each, context familiar to learners in the UAE (AED, dirhams/fils, local names, metric units). Keep the language of the objective (e.g. "term-to-term rule", "simplest form").

### 4. Rubric text
For every objective, write the Achievement Descriptor, Feedback and Feedforward for all five bands in `spec["rubric"]` — specific to that objective and this quiz's content, following `references/rubric.md`. The build warns and uses generic wording for anything missing; don't ship generic wording.

### 5. Figures
Use `scripts/figures.py` (import it and put the returned SVG string in `figure`, or save `.svg` files next to the spec). Draw figures to be read: values on gridlines, scales that can show the answer, labels that don't overlap. For angle facts say "Not drawn accurately" in the prompt.

### 6. Build and test
```bash
python <skill_dir>/scripts/build_quiz.py spec.json --key --preview -o preview.html
python <skill_dir>/scripts/check_quiz.py preview.html --mobile
python <skill_dir>/scripts/build_quiz.py spec.json          # the real quiz: saves results to Drive
```
Fix every build error and every checker problem, then rebuild. View `contact_sheet.png` (and `mobile_q1.png`, `99_results.png`) with the Read tool: each question renders cleanly, figures match the text, nothing is cut off, the rubric table looks right. Then go through `references/quality-checklist.md`.

If `assets/school_config.json` has no `results_url` yet, the real build prints "results NOT saved": deliver it anyway, say in one line that results will only save to Drive once the school's results service is connected, and point to `references/results-and-drive.md`.

### 7. Deliver
Send the quiz `.html` (the real build, not the preview), the `_ANSWER_KEY.html`, and the spec.json (so the quiz can be edited and rebuilt later). In the reply, briefly give: year/stage, quiz number, questions/marks/time/mode, the objective codes covered (and any requested objective that can't be auto-marked, e.g. constructions or conducting investigations), where results will be saved (`Mathematics / Year n / <section> / Qnn – <title>`), and one line on sharing it (upload to the school GitHub Pages site and give the link; write the class code on the board in the lesson). Offer the natural next step (a matching practice version, or a harder version).

## Worksheets and practice sheets (PEPS rules)
Set `"type": "worksheet"` (or `"practice sheet"`). Then: **no number**, **dated** (`date`, default today) and saved in their own *Worksheets / <date> – <Title>* folders; **points instead of marks**; **practice mode by default** (Check, hints, retry); a **Remember box** (key points + worked example) is **compulsory** — on the start screen and behind a 📘 button during the work; **2–3 Challenge questions** are **compulsory**, always last, under a ★ CHALLENGE banner (their points count). The rubric and report work as for quizzes. Worksheets are for practice: more questions of the same kind building in difficulty (e.g. 6–10 main + 2–3 challenge), hints on most questions. Details: `references/spec-format.md` → *Worksheets*.

## House style
- File names: `PEPS_Y<year>_Maths_Q<nn>_<Title>.html` (the build does this; set `file_name` to override).
- Title: short and learner-facing, e.g. "Fractions Check-up", "Unit 3: Angles — Practice".
- Show objective codes on questions (`show_objectives: true`, the default).
- Levels always use the five Cambridge Attainment bands: Emerging (0–20%), Developing (21–40%), Meets Expectations (41–60%), Secure (61–80%), Exceeding (81%+) — for each objective and overall. Quizzes say "Marks" throughout.
- Years 1–3 automatically get larger text and a 🔊 read-aloud button.
- Answers are encoded in the page so they can't be read at a glance, but a determined learner with developer tools could find them: say so if the quiz is being used for anything high-stakes.
