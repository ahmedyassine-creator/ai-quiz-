# Cambridge Primary Mathematics (0096) — learning objectives, Stages 1–6

Source: Cambridge Primary Mathematics Curriculum Framework 0096 (first teaching 2020).
PEPS mapping: **Year N = Stage N** (Year 1 → Stage 1 … Year 6 → Stage 6).

Code format: `<stage><strand letter><sub-strand letter>.<nn>`
- N = Number: **Nc** Counting and sequences · **Ni** Integers and powers · **Nm** Money (Stages 1–3 only) · **Np** Place value, ordering and rounding · **Nf** Fractions, decimals, percentages, ratio and proportion
- G = Geometry and Measure: **Gt** Time · **Gg** Geometrical reasoning, shapes and measurements · **Gp** Position and transformation
- S = Statistics and Probability: **Ss** Statistics · **Sp** Probability (from Stage 2)

Extract only the stage you need, e.g. `sed -n '/^## Stage 3/,/^## Stage 4/p' references/objectives-primary.md`.
Thinking and Working Mathematically (TWM) characteristics are listed in `objectives-lower-secondary.md` (same for all stages).

Some objectives are practical (conduct an investigation, measure with instruments, draw, construct). An auto-marked quiz can only assess them indirectly (reading a scale in a picture, choosing the right representation, interpreting given results). Tag such questions with the objective but say in the reply that the practical part is not covered.

## Stage 1

### Number — Counting and sequences
- 1Nc.01 Count objects from 0 to 20, recognising conservation of number and one-to-one correspondence.
- 1Nc.02 Recognise the number of objects presented in familiar patterns up to 10, without counting.
- 1Nc.03 Estimate the number of objects or people (up to 20), and check by counting.
- 1Nc.04 Count on in ones, twos or tens, and count back in ones and tens, starting from any number (from 0 to 20).
- 1Nc.05 Understand even and odd numbers as 'every other number' when counting (from 0 to 20).
- 1Nc.06 Use familiar language to describe sequences of objects.

### Number — Integers and powers
- 1Ni.01 Recite, read and write number names and whole numbers (from 0 to 20).
- 1Ni.02 Understand addition as: counting on; combining two sets.
- 1Ni.03 Understand subtraction as: counting back; take away; difference.
- 1Ni.04 Recognise complements of 10.
- 1Ni.05 Estimate, add and subtract whole numbers (where the answer is from 0 to 20).
- 1Ni.06 Know doubles up to double 10.

### Number — Money
- 1Nm.01 Recognise money used in local currency.

### Number — Place value, ordering and rounding
- 1Np.01 Understand that zero represents none of something.
- 1Np.02 Compose, decompose and regroup numbers from 10 to 20.
- 1Np.03 Understand the relative size of quantities to compare and order numbers from 0 to 20.
- 1Np.04 Recognise and use ordinal numbers from 1st to 10th.

### Number — Fractions, decimals, percentages, ratio and proportion
- 1Nf.01 Understand that an object or shape can be split into two equal parts or two unequal parts.
- 1Nf.02 Understand that a half can describe one of two equal parts of a quantity or set of objects.
- 1Nf.03 Understand that a half can act as an operator (whole number answers).
- 1Nf.04 Understand and visualise that halves can be combined to make wholes.

### Geometry and Measure — Time
- 1Gt.01 Use familiar language to describe units of time.
- 1Gt.02 Know the days of the week and the months of the year.
- 1Gt.03 Recognise time to the hour and half hour.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 1Gg.01 Identify, describe and sort 2D shapes by their characteristics or properties, including reference to number of sides and whether the sides are curved or straight.
- 1Gg.02 Use familiar language to describe length, including long, longer, longest, thin, thinner, thinnest, short, shorter, shortest, tall, taller and tallest.
- 1Gg.03 Identify, describe and sort 3D shapes by their properties, including reference to the number of faces, edges and whether faces are flat or curved.
- 1Gg.04 Use familiar language to describe mass, including heavy, light, less and more.
- 1Gg.05 Use familiar language to describe capacity, including full, empty, less and more.
- 1Gg.06 Differentiate between 2D and 3D shapes.
- 1Gg.07 Identify when a shape looks identical as it rotates.
- 1Gg.08 Explore instruments that have numbered scales, and select the most appropriate instrument to measure length, mass, capacity and temperature.

### Geometry and Measure — Position and transformation
- 1Gp.01 Use familiar language to describe position and direction.

### Statistics and Probability — Statistics
- 1Ss.01 Answer non-statistical questions (categorical data).
- 1Ss.02 Record, organise and represent categorical data using: practical resources and drawings; lists and tables; Venn and Carroll diagrams; block graphs and pictograms.
- 1Ss.03 Describe data, using familiar language including reference to more, less, most or least to answer non-statistical questions and discuss conclusions.

## Stage 2

### Number — Counting and sequences
- 2Nc.01 Count objects from 0 to 100.
- 2Nc.02 Recognise the number of objects presented in unfamiliar patterns up to 10, without counting.
- 2Nc.03 Estimate the number of objects or people (up to 100).
- 2Nc.04 Count on and count back in ones, twos, fives or tens, starting from any number (from 0 to 100).
- 2Nc.05 Recognise the characteristics of even and odd numbers (from 0 to 100).
- 2Nc.06 Recognise, describe and extend numerical sequences (from 0 to 100).

### Number — Integers and powers
- 2Ni.01 Recite, read and write number names and whole numbers (from 0 to 100).
- 2Ni.02 Understand and explain the relationship between addition and subtraction.
- 2Ni.03 Recognise complements of 20 and complements of multiples of 10 (up to 100).
- 2Ni.04 Estimate, add and subtract whole numbers with up to two digits (no regrouping of ones or tens).
- 2Ni.05 Understand multiplication as: repeated addition; an array.
- 2Ni.06 Understand division as: sharing (number of items per group); grouping (number of groups).
- 2Ni.07 Know 1, 2, 5 and 10 times tables.

### Number — Money
- 2Nm.01 Recognise value and money notation used in local currency.
- 2Nm.02 Compare values of different combinations of coins or notes.

### Number — Place value, ordering and rounding
- 2Np.01 Understand and explain that the value of each digit in a 2-digit number is determined by its position in that number, recognising zero as a place holder.
- 2Np.02 Compose, decompose and regroup 2-digit numbers, using tens and ones.
- 2Np.03 Understand the relative size of quantities to compare and order 2-digit numbers.
- 2Np.04 Recognise and use ordinal numbers.
- 2Np.05 Round 2-digit numbers to the nearest 10.

### Number — Fractions, decimals, percentages, ratio and proportion
- 2Nf.01 Understand that an object or shape can be split into four equal parts or four unequal parts.
- 2Nf.02 Understand that a quarter can describe one of four equal parts of a quantity or set of objects.
- 2Nf.03 Understand that one half and one quarter can be interpreted as division.
- 2Nf.04 Understand that fractions (half, quarter and three-quarters) can act as operators.
- 2Nf.05 Recognise the relative size of 1/4, 1/2, 3/4 and 1, and the equivalence of 1/2 and 2/4, and 2/2, 4/4 and 1.
- 2Nf.06 Understand and visualise that wholes, halves and quarters can be combined to create new fractions.

### Geometry and Measure — Time
- 2Gt.01 Order and compare units of time (seconds, minutes, hours, days, weeks, months and years).
- 2Gt.02 Read and record time to five minutes in digital notation (12-hour) and on analogue clocks.
- 2Gt.03 Interpret and use the information in calendars.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 2Gg.01 Identify, describe, sort, name and sketch 2D shapes by their properties, including reference to regular polygons, number of sides and vertices.
- 2Gg.02 Understand that a circle has a centre and any point on the boundary is at the same distance from the centre.
- 2Gg.03 Understand that length is a fixed distance between two points. Estimate and measure lengths using non-standard or standard units.
- 2Gg.04 Draw and measure lines, using standard units.
- 2Gg.05 Identify, describe, sort and name 3D shapes by their properties, including reference to number and shapes of faces, edges and vertices.
- 2Gg.06 Understand that mass is the quantity of matter in an object. Estimate and measure familiar objects using non-standard or standard units.
- 2Gg.07 Understand that capacity is the maximum amount that an object can contain. Estimate and measure the capacity of familiar objects using non-standard or standard units.
- 2Gg.08 Identify 2D and 3D shapes in familiar objects.
- 2Gg.09 Identify a horizontal or vertical line of symmetry on 2D shapes and patterns.
- 2Gg.10 Predict and check how many times a shape looks identical as it completes a full turn.
- 2Gg.11 Understand that an angle is a description of a turn, including reference to the terms whole, half and quarter turns, both clockwise and anticlockwise.
- 2Gg.12 Understand a measuring scale as a continuous number line where intermediate points have value.

### Geometry and Measure — Position and transformation
- 2Gp.01 Use knowledge of position and direction to describe movement.
- 2Gp.02 Sketch the reflection of a 2D shape in a vertical mirror line, including where the mirror line is the edge of the shape.

### Statistics and Probability — Statistics
- 2Ss.01 Conduct an investigation to answer non-statistical and statistical questions (categorical data).
- 2Ss.02 Record, organise and represent categorical data. Choose and explain which representation to use in a given situation: lists and tables; Venn and Carroll diagrams; tally charts; block graphs and pictograms.
- 2Ss.03 Describe data, identifying similarities and variations to answer non-statistical and statistical questions and discuss conclusions.

### Statistics and Probability — Probability
- 2Sp.01 Use familiar language associated with patterns and randomness, including regular pattern and random pattern.
- 2Sp.02 Conduct chance experiments with two outcomes, and present and describe the results.

## Stage 3

### Number — Counting and sequences
- 3Nc.01 Estimate the number of objects or people (up to 1000).
- 3Nc.02 Count on and count back in steps of constant size: 1-digit numbers, tens or hundreds, starting from any number (from 0 to 1000).
- 3Nc.03 Use knowledge of even and odd numbers up to 10 to recognise and sort numbers.
- 3Nc.04 Recognise the use of an object to represent an unknown quantity in addition and subtraction calculations.
- 3Nc.05 Recognise and extend linear sequences, and describe the term-to-term rule.
- 3Nc.06 Extend spatial patterns formed from adding and subtracting a constant.

### Number — Integers and powers
- 3Ni.01 Recite, read and write number names and whole numbers (from 0 to 1000).
- 3Ni.02 Understand the commutative and associative properties of addition, and use these to simplify calculations.
- 3Ni.03 Recognise complements of 100 and complements of multiples of 10 or 100 (up to 1000).
- 3Ni.04 Estimate, add and subtract whole numbers with up to three digits (regrouping of ones or tens).
- 3Ni.05 Understand and explain the relationship between multiplication and division.
- 3Ni.06 Understand and explain the commutative and distributive properties of multiplication, and use these to simplify calculations.
- 3Ni.07 Know 1, 2, 3, 4, 5, 6, 8, 9 and 10 times tables.
- 3Ni.08 Estimate and multiply whole numbers up to 100 by 2, 3, 4 and 5.
- 3Ni.09 Estimate and divide whole numbers up to 100 by 2, 3, 4 and 5.
- 3Ni.10 Recognise multiples of 2, 5 and 10 (up to 1000).

### Number — Money
- 3Nm.01 Interpret money notation for currencies that use a decimal point.
- 3Nm.02 Add and subtract amounts of money to give change.

### Number — Place value, ordering and rounding
- 3Np.01 Understand and explain that the value of each digit is determined by its position in that number (up to 3-digit numbers).
- 3Np.02 Use knowledge of place value to multiply whole numbers by 10.
- 3Np.03 Compose, decompose and regroup 3-digit numbers, using hundreds, tens and ones.
- 3Np.04 Understand the relative size of quantities to compare and order 3-digit positive numbers, using the symbols =, > and <.
- 3Np.05 Round 3-digit numbers to the nearest 10 or 100.

### Number — Fractions, decimals, percentages, ratio and proportion
- 3Nf.01 Understand and explain that fractions are several equal parts of an object or shape and all the parts, taken together, equal one whole.
- 3Nf.02 Understand that the relationship between the whole and the parts depends on the relative size of each, regardless of their shape or orientation.
- 3Nf.03 Understand and explain that fractions can describe equal parts of a quantity or set of objects.
- 3Nf.04 Understand that a fraction can be represented as a division of the numerator by the denominator (half, quarter and three-quarters).
- 3Nf.05 Understand that fractions (half, quarter, three-quarters, third and tenth) can act as operators.
- 3Nf.06 Recognise that two fractions can have an equivalent value (halves, quarters, fifths and tenths).
- 3Nf.07 Estimate, add and subtract fractions with the same denominator (within one whole).
- 3Nf.08 Use knowledge of equivalence to compare and order unit fractions and fractions with the same denominator, using the symbols =, > and <.

### Geometry and Measure — Time
- 3Gt.01 Choose the appropriate unit of time for familiar activities.
- 3Gt.02 Read and record time accurately in digital notation (12-hour) and on analogue clocks.
- 3Gt.03 Interpret and use the information in timetables (12-hour clock).
- 3Gt.04 Understand the difference between a time and a time interval. Find time intervals between the same units in days, weeks, months and years.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 3Gg.01 Identify, describe, classify, name and sketch 2D shapes by their properties. Differentiate between regular and irregular polygons.
- 3Gg.02 Estimate and measure lengths in centimetres (cm), metres (m) and kilometres (km). Understand the relationship between units.
- 3Gg.03 Understand that perimeter is the total distance around a 2D shape and can be calculated by adding lengths, and area is how much space a 2D shape occupies within its boundary.
- 3Gg.04 Draw lines, rectangles and squares. Estimate, measure and calculate the perimeter of a shape, using appropriate metric units, and area on a square grid.
- 3Gg.05 Identify, describe, sort, name and sketch 3D shapes by their properties.
- 3Gg.06 Estimate and measure the mass of objects in grams (g) and kilograms (kg). Understand the relationship between units.
- 3Gg.07 Estimate and measure capacity in millilitres (ml) and litres (l), and understand their relationships.
- 3Gg.08 Recognise pictures, drawings and diagrams of 3D shapes.
- 3Gg.09 Identify both horizontal and vertical lines of symmetry on 2D shapes and patterns.
- 3Gg.10 Compare angles with a right angle. Recognise that a straight line is equivalent to two right angles or a half turn.
- 3Gg.11 Use instruments that measure length, mass, capacity and temperature.

### Geometry and Measure — Position and transformation
- 3Gp.01 Interpret and create descriptions of position, direction and movement, including reference to cardinal points.
- 3Gp.02 Sketch the reflection of a 2D shape in a horizontal or vertical mirror line, including where the mirror line is the edge of the shape.

### Statistics and Probability — Statistics
- 3Ss.01 Conduct an investigation to answer non-statistical and statistical questions (categorical and discrete data).
- 3Ss.02 Record, organise and represent categorical and discrete data. Choose and explain which representation to use in a given situation: Venn and Carroll diagrams; tally charts and frequency tables; pictograms and bar charts.
- 3Ss.03 Interpret data, identifying similarities and variations, within data sets, to answer non-statistical and statistical questions and discuss conclusions.

### Statistics and Probability — Probability
- 3Sp.01 Use familiar language associated with chance to describe events, including 'it will happen', 'it will not happen', 'it might happen'.
- 3Sp.02 Conduct chance experiments, and present and describe the results.

## Stage 4

### Number — Counting and sequences
- 4Nc.01 Count on and count back in steps of constant size: 1-digit numbers, tens, hundreds or thousands, starting from any number, and extending beyond zero to include negative numbers.
- 4Nc.02 Recognise and explain generalisations when adding and subtracting combinations of even and odd numbers.
- 4Nc.03 Recognise the use of objects, shapes or symbols to represent unknown quantities in addition and subtraction calculations.
- 4Nc.04 Recognise and extend linear and non-linear sequences, and describe the term-to-term rule.
- 4Nc.05 Recognise and extend the spatial pattern of square numbers.

### Number — Integers and powers
- 4Ni.01 Read and write number names and whole numbers greater than 1000 and less than 0.
- 4Ni.02 Estimate, add and subtract whole numbers with up to three digits.
- 4Ni.03 Understand the associative property of multiplication, and use this to simplify calculations.
- 4Ni.04 Know all times tables from 1 to 10.
- 4Ni.05 Estimate and multiply whole numbers up to 1000 by 1-digit whole numbers.
- 4Ni.06 Estimate and divide whole numbers up to 100 by 1-digit whole numbers.
- 4Ni.07 Understand the relationship between multiples and factors.
- 4Ni.08 Use knowledge of factors and multiples to understand tests of divisibility by 2, 5, 10, 25, 50 and 100.

### Number — Place value, ordering and rounding
- 4Np.01 Understand and explain that the value of each digit in numbers is determined by its position in that number.
- 4Np.02 Use knowledge of place value to multiply and divide whole numbers by 10 and 100.
- 4Np.03 Compose, decompose and regroup whole numbers.
- 4Np.04 Understand the relative size of quantities to compare and order positive and negative numbers, using the symbols =, > and <.
- 4Np.05 Round numbers to the nearest 10, 100, 1000, 10 000 or 100 000.

### Number — Fractions, decimals, percentages, ratio and proportion
- 4Nf.01 Understand that the more parts a whole is divided into, the smaller the parts become.
- 4Nf.02 Understand that a fraction can be represented as a division of the numerator by the denominator (unit fractions and three-quarters).
- 4Nf.03 Understand that unit fractions can act as operators.
- 4Nf.04 Recognise that two proper fractions can have an equivalent value.
- 4Nf.05 Estimate, add and subtract fractions with the same denominator.
- 4Nf.06 Understand percentage as the number of parts in each hundred, and use the percentage symbol (%).
- 4Nf.07 Use knowledge of equivalence to compare and order proper fractions, using the symbols =, > and <.

### Geometry and Measure — Time
- 4Gt.01 Understand the direct relationship between units of time, and convert between them.
- 4Gt.02 Read and record time accurately in digital notation (12- and 24-hour) and on analogue clocks.
- 4Gt.03 Interpret and use the information in timetables (12- and 24-hour clock).
- 4Gt.04 Find time intervals between different units: days, weeks, months and years; seconds, minutes and hours that do not bridge through 60.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 4Gg.01 Investigate what shapes can be made if two or more shapes are combined, and analyse their properties, including reference to tessellation.
- 4Gg.02 Estimate and measure perimeter and area of 2D shapes, understanding that two areas can be added together to calculate the area of a compound shape.
- 4Gg.03 Draw rectangles and squares on square grids, and measure their perimeter and area. Derive and use formulae to calculate areas and perimeters of rectangles and squares.
- 4Gg.04 Estimate the area of irregular shapes on a square grid (whole and part squares).
- 4Gg.05 Identify 2D faces of 3D shapes, and describe their properties.
- 4Gg.06 Match nets to their corresponding 3D shapes.
- 4Gg.07 Identify all horizontal, vertical and diagonal lines of symmetry on 2D shapes and patterns.
- 4Gg.08 Estimate, compare and classify angles, using geometric vocabulary including acute, right and obtuse.
- 4Gg.09 Use knowledge of fractions to read and interpret a measuring scale.

### Geometry and Measure — Position and transformation
- 4Gp.01 Interpret and create descriptions of position, direction and movement, including reference to cardinal and ordinal points, and their notations.
- 4Gp.02 Understand that position can be described using coordinate notation. Read and plot coordinates in the first quadrant (with the aid of a grid).
- 4Gp.03 Reflect 2D shapes in a horizontal or vertical mirror line, including where the mirror line is the edge of the shape, on square grids.

### Statistics and Probability — Statistics
- 4Ss.01 Plan and conduct an investigation to answer statistical questions, considering what data to collect (categorical and discrete data).
- 4Ss.02 Record, organise and represent categorical and discrete data. Choose and explain which representation to use in a given situation: Venn and Carroll diagrams; tally charts and frequency tables; pictograms and bar charts; dot plots (one dot per count).
- 4Ss.03 Interpret data, identifying similarities and variations, within and between data sets, to answer statistical questions. Discuss conclusions, considering the sources of variation.

### Statistics and Probability — Probability
- 4Sp.01 Use language associated with chance to describe familiar events, including reference to maybe, likely, certain, impossible.
- 4Sp.02 Conduct chance experiments, using small and large numbers of trials, and present and describe the results using the language of probability.

## Stage 5

### Number — Counting and sequences
- 5Nc.01 Count on and count back in steps of constant size, and extend beyond zero to include negative numbers.
- 5Nc.02 Recognise the use of objects, shapes or symbols to represent two unknown quantities in addition and subtraction calculations.
- 5Nc.03 Use the relationship between repeated addition of a constant and multiplication to find any term of a linear sequence.
- 5Nc.04 Recognise and extend the spatial pattern of square and triangular numbers.

### Number — Integers and powers
- 5Ni.01 Estimate, add and subtract integers, including where one integer is negative.
- 5Ni.02 Understand which law of arithmetic to apply to simplify calculations.
- 5Ni.03 Understand that the four operations follow a particular order.
- 5Ni.04 Estimate and multiply whole numbers up to 1000 by 1-digit or 2-digit whole numbers.
- 5Ni.05 Estimate and divide whole numbers up to 1000 by 1-digit whole numbers.
- 5Ni.06 Understand and explain the difference between prime and composite numbers.
- 5Ni.07 Use knowledge of factors and multiples to understand tests of divisibility by 4 and 8.
- 5Ni.08 Use knowledge of multiplication to recognise square numbers (from 1 to 100).

### Number — Place value, ordering and rounding
- 5Np.01 Understand and explain the value of each digit in decimals (tenths and hundredths).
- 5Np.02 Use knowledge of place value to multiply and divide whole numbers by 10, 100 and 1000.
- 5Np.03 Use knowledge of place value to multiply and divide decimals by 10 and 100.
- 5Np.04 Compose, decompose and regroup numbers, including decimals (tenths and hundredths).
- 5Np.05 Round numbers with one decimal place to the nearest whole number.

### Number — Fractions, decimals, percentages, ratio and proportion
- 5Nf.01 Understand that a fraction can be represented as a division of the numerator by the denominator (unit fractions, three-quarters, tenths and hundredths).
- 5Nf.02 Understand that proper fractions can act as operators.
- 5Nf.03 Recognise that improper fractions and mixed numbers can have an equivalent value.
- 5Nf.04 Recognise that proper fractions, decimals (one decimal place) and percentages can have equivalent values.
- 5Nf.05 Estimate, add and subtract fractions with the same denominator and denominators that are multiples of each other.
- 5Nf.06 Estimate, multiply and divide unit fractions by a whole number.
- 5Nf.07 Recognise percentages of shapes, and write percentages as a fraction with denominator 100.
- 5Nf.08 Understand the relative size of quantities to compare and order numbers with one decimal place, proper fractions with the same denominator and percentages, using the symbols =, > and <.
- 5Nf.09 Estimate, add and subtract numbers with the same number of decimal places.
- 5Nf.10 Estimate and multiply numbers with one decimal place by 1-digit whole numbers.
- 5Nf.11 Understand that: a proportion compares part to whole; a ratio compares part to part of two or more quantities.

### Geometry and Measure — Time
- 5Gt.01 Understand time intervals less than one second.
- 5Gt.02 Compare times between time zones in digital notation (12- and 24-hour) and on analogue clocks.
- 5Gt.03 Find time intervals in seconds, minutes and hours that bridge through 60.
- 5Gt.04 Recognise that a time interval can be expressed as a decimal, or in mixed units.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 5Gg.01 Identify, describe, classify and sketch isosceles, equilateral or scalene triangles, including reference to angles and symmetrical properties.
- 5Gg.02 Estimate and measure perimeter and area of 2D shapes, understanding that shapes with the same perimeter can have different areas and vice versa.
- 5Gg.03 Draw compound shapes that can be divided into rectangles and squares. Estimate, measure and calculate their perimeter and area.
- 5Gg.04 Identify, describe and sketch 3D shapes in different orientations.
- 5Gg.05 Identify and sketch different nets for a cube.
- 5Gg.06 Use knowledge of reflective symmetry to identify and complete symmetrical patterns.
- 5Gg.07 Estimate, compare and classify angles, using geometric vocabulary including acute, right, obtuse and reflex.
- 5Gg.08 Know that the sum of the angles on a straight line is 180°, and use this to calculate missing angles on a straight line.

### Geometry and Measure — Position and transformation
- 5Gp.01 Compare the relative position of coordinates (with or without the aid of a grid).
- 5Gp.02 Use knowledge of 2D shapes and coordinates to plot points to form lines and shapes in the first quadrant (with the aid of a grid).
- 5Gp.03 Translate 2D shapes, identifying the corresponding points between the original and the translated image, on square grids.
- 5Gp.04 Reflect 2D shapes in both horizontal and vertical mirror lines to create patterns on square grids.

### Statistics and Probability — Statistics
- 5Ss.01 Plan and conduct an investigation to answer a set of related statistical questions, considering what data to collect (categorical, discrete and continuous data).
- 5Ss.02 Record, organise and represent categorical, discrete and continuous data. Choose and explain which representation to use in a given situation: Venn and Carroll diagrams; tally charts and frequency tables; bar charts; waffle diagrams; frequency diagrams for continuous data; line graphs; dot plots (one dot per data point).
- 5Ss.03 Understand that the mode and median are ways to describe and summarise data sets. Find and interpret the mode and the median, and consider their appropriateness for the context.
- 5Ss.04 Interpret data, identifying patterns, within and between data sets, to answer statistical questions. Discuss conclusions, considering the sources of variation.

### Statistics and Probability — Probability
- 5Sp.01 Use the language associated with likelihood to describe and compare likelihood and risk of familiar events, including those with equally likely outcomes.
- 5Sp.02 Recognise that some outcomes are equally likely to happen and some outcomes are more (or less) likely to happen, when doing practical activities.
- 5Sp.03 Conduct chance experiments or simulations, using small and large numbers of trials, and present and describe the results using the language of probability.

## Stage 6

### Number — Counting and sequences
- 6Nc.01 Count on and count back in steps of constant size, including fractions and decimals, and extend beyond zero to include negative numbers.
- 6Nc.02 Recognise the use of letters to represent quantities that vary in addition and subtraction calculations.
- 6Nc.03 Use the relationship between repeated addition of a constant and multiplication to find and use a position-to-term rule.
- 6Nc.04 Use knowledge of square numbers to generate terms in a sequence, given its position.

### Number — Integers and powers
- 6Ni.01 Estimate, add and subtract integers.
- 6Ni.02 Use knowledge of laws of arithmetic and order of operations to simplify calculations.
- 6Ni.03 Understand that brackets can be used to alter the order of operations.
- 6Ni.04 Estimate and multiply whole numbers up to 10 000 by 1-digit or 2-digit whole numbers.
- 6Ni.05 Estimate and divide whole numbers up to 1000 by 1-digit or 2-digit whole numbers.
- 6Ni.06 Understand common multiples and common factors.
- 6Ni.07 Use knowledge of factors and multiples to understand tests of divisibility by 3, 6 and 9.
- 6Ni.08 Use knowledge of multiplication and square numbers to recognise cube numbers (from 1 to 125).

### Number — Place value, ordering and rounding
- 6Np.01 Understand and explain the value of each digit in decimals (tenths, hundredths and thousandths).
- 6Np.02 Use knowledge of place value to multiply and divide whole numbers and decimals by 10, 100 and 1000.
- 6Np.03 Compose, decompose and regroup numbers, including decimals (tenths, hundredths and thousandths).
- 6Np.04 Round numbers with two decimal places to the nearest tenth or whole number.

### Number — Fractions, decimals, percentages, ratio and proportion
- 6Nf.01 Understand that a fraction can be represented as a division of the numerator by the denominator (proper and improper fractions).
- 6Nf.02 Understand that proper and improper fractions can act as operators.
- 6Nf.03 Use knowledge of equivalence to write fractions in their simplest form.
- 6Nf.04 Recognise that fractions, decimals (one or two decimal places) and percentages can have equivalent values.
- 6Nf.05 Estimate, add and subtract fractions with different denominators.
- 6Nf.06 Estimate, multiply and divide proper fractions by whole numbers.
- 6Nf.07 Recognise percentages (1%, and multiples of 5% up to 100%) of shapes and whole numbers.
- 6Nf.08 Understand the relative size of quantities to compare and order numbers with one or two decimal places, proper fractions with different denominators and percentages, using the symbols =, > and <.
- 6Nf.09 Estimate, add and subtract numbers with the same or different number of decimal places.
- 6Nf.10 Estimate and multiply numbers with one or two decimal places by 1-digit and 2-digit whole numbers.
- 6Nf.11 Estimate and divide numbers with one or two decimal places by whole numbers.
- 6Nf.12 Understand the relationship between two quantities when they are in direct proportion.
- 6Nf.13 Use knowledge of equivalence to understand and use equivalent ratios.

### Geometry and Measure — Time
- 6Gt.01 Convert between time intervals expressed as a decimal and in mixed units.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 6Gg.01 Identify, describe, classify and sketch quadrilaterals, including reference to angles, symmetrical properties, parallel sides and diagonals.
- 6Gg.02 Know the parts of a circle: centre; radius; diameter; circumference.
- 6Gg.03 Use knowledge of area of rectangles to estimate and calculate the area of right-angled triangles.
- 6Gg.04 Identify, describe and sketch compound 3D shapes.
- 6Gg.05 Understand the difference between capacity and volume.
- 6Gg.06 Identify and sketch different nets for cubes, cuboids, prisms and pyramids.
- 6Gg.07 Understand the relationship between area of 2D shapes and surface area of 3D shapes.
- 6Gg.08 Identify rotational symmetry in familiar shapes, patterns or images with maximum order 4. Describe rotational symmetry as 'order x'.
- 6Gg.09 Classify, estimate, measure and draw angles.
- 6Gg.10 Know that the sum of the angles in a triangle is 180°, and use this to calculate missing angles in a triangle.
- 6Gg.11 Construct circles of a specified radius or diameter.

### Geometry and Measure — Position and transformation
- 6Gp.01 Read and plot coordinates including integers, fractions and decimals, in all four quadrants (with the aid of a grid).
- 6Gp.02 Use knowledge of 2D shapes and coordinates to plot points to form lines and shapes in all four quadrants.
- 6Gp.03 Translate 2D shapes, identifying the corresponding points between the original and the translated image, on coordinate grids.
- 6Gp.04 Reflect 2D shapes in a given mirror line (vertical, horizontal and diagonal), on square grids.
- 6Gp.05 Rotate shapes 90° around a vertex (clockwise or anticlockwise).

### Statistics and Probability — Statistics
- 6Ss.01 Plan and conduct an investigation and make predictions for a set of related statistical questions, considering what data to collect (categorical, discrete and continuous data).
- 6Ss.02 Record, organise and represent categorical, discrete and continuous data. Choose and explain which representation to use in a given situation: Venn and Carroll diagrams; tally charts and frequency tables; bar charts; waffle diagrams and pie charts; frequency diagrams for continuous data; line graphs; scatter graphs; dot plots.
- 6Ss.03 Understand that the mode, median, mean and range are ways to describe and summarise data sets. Find and interpret the mode (including bimodal data), median, mean and range, and consider their appropriateness for the context.
- 6Ss.04 Interpret data, identifying patterns, within and between data sets, to answer statistical questions. Discuss conclusions, considering the sources of variation, and check predictions.

### Statistics and Probability — Probability
- 6Sp.01 Use the language associated with probability and proportion to describe and compare possible outcomes.
- 6Sp.02 Identify when two events can happen at the same time and when they cannot, and know that the latter are called 'mutually exclusive'.
- 6Sp.03 Recognise that some probabilities can only be modelled through experiments using a large number of trials.
- 6Sp.04 Conduct chance experiments or simulations, using small and large numbers of trials. Predict, analyse and describe the frequency of outcomes using the language of probability.
