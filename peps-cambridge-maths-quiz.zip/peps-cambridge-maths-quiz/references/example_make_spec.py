# Worked example: Year 4 Fractions unit quiz — 4 objectives × 5 marks, answers verified with Fraction,
# figures from figures.py, and a complete Cambridge Attainment Rubric (spec['rubric']).
# Run it to write spec.json, then build with build_quiz.py.
import sys, json; sys.path.insert(0, "<skill_dir>/scripts")  # use the real skill path
from figures import *
from fractions import Fraction as F
# verify arithmetic
assert F(1,4)*20==5 and F(1,3)*18==6 and F(1,5)*35==7 and F(1,10)*60==6 and F(1,6)*24==4
assert F(3,5)==F(6,10) and F(2,7)+F(3,7)==F(5,7) and F(9,10)-F(4,10)==F(1,2) and 1-F(3,8)-F(2,8)==F(3,8)
assert F(4,9)+F(3,9)==F(7,9) and 1-F(3,5)==F(2,5) and F(3,4)>F(5,8) and F(2,5)==F(4,10) and F(1,3)<F(1,2)
assert sorted([F(3,4),F(1,10),F(1,2),F(1,5)])==[F(1,10),F(1,5),F(1,2),F(3,4)]
q=[
 {"type":"numeric","objective":"4Nf.03","prompt":"What is {{f:1/4}} of 20?","answer":5,"explanation":"To find {{f:1/4}}, divide by 4: 20 ÷ 4 = 5."},
 {"type":"numeric","objective":"4Nf.03","figure":objects(18,per_row=9),"prompt":"Find {{f:1/3}} of these 18 counters.","answer":6,"explanation":"Share 18 into 3 equal groups: 18 ÷ 3 = 6."},
 {"type":"blanks","objective":"4Nf.03","text":"{{f:1/5}} of 35 = [[1]]<br>{{f:1/10}} of 60 = [[2]]","blanks":[{"answer":7},{"answer":6}],"explanation":"35 ÷ 5 = 7 and 60 ÷ 10 = 6."},
 {"type":"mcq","objective":"4Nf.03","prompt":"Sara has 24 sweets. She gives {{f:1/6}} of them to her brother. How many sweets does she give him?","options":["3","4","6","18"],"answer":1,
  "explanation":"24 ÷ 6 = 4. (18 is how many she has left; 6 would be {{f:1/4}} of 24.)"},
 {"type":"shade","objective":"4Nf.04","shape":"bar","parts":8,"answer":4,"prompt":"The bar has 8 equal parts. Shade a fraction that is <b>equivalent to {{f:1/2}}</b>.","explanation":"{{f:1/2}} = {{f:4/8}}, so shade 4 of the 8 parts."},
 {"type":"blanks","objective":"4Nf.04","text":"{{f:3/5}} = <span class='frac'><span class='n'>[[1]]</span><span class='d'>10</span></span>","blanks":[{"answer":6,"width":3}],"explanation":"5 × 2 = 10, so multiply the numerator by 2 as well: 3 × 2 = 6."},
 {"type":"match","objective":"4Nf.04","prompt":"Match each fraction to an equivalent fraction.","left":["{{f:1/2}}","{{f:1/4}}","{{f:3/4}}"],"right":["5/10","2/8","6/8","3/8"],"answer":[0,1,2],
  "explanation":"{{f:1/2}} = {{f:5/10}}, {{f:1/4}} = {{f:2/8}}, {{f:3/4}} = {{f:6/8}}. {{f:3/8}} is not equivalent to any of them."},
 {"type":"fraction","objective":"4Nf.05","prompt":"Work out {{f:2/7}} + {{f:3/7}}","answer":"5/7","explanation":"Same denominator, so add the numerators: 2 + 3 = 5 sevenths."},
 {"type":"fraction","objective":"4Nf.05","prompt":"Work out {{f:9/10}} − {{f:4/10}}","answer":"5/10","explanation":"Same denominator, so subtract the numerators: 9 − 4 = 5 tenths ({{f:5/10}} = {{f:1/2}})."},
 {"type":"fraction","objective":"4Nf.05","figure":fraction_shape("circle",8,0),"prompt":"A pizza is cut into 8 equal slices. Omar eats {{f:3/8}} and Huda eats {{f:2/8}}. What fraction of the pizza is left?","answer":"3/8",
  "explanation":"They eat {{f:3/8}} + {{f:2/8}} = {{f:5/8}}. The whole pizza is {{f:8/8}}, so {{f:8/8}} − {{f:5/8}} = {{f:3/8}} is left."},
 {"type":"mcq","objective":"4Nf.05","prompt":"What is {{f:4/9}} + {{f:3/9}}?","options":["{{f:1/9}}","{{f:7/18}}","{{f:7/9}}","{{f:12/9}}"],"answer":2,
  "explanation":"Add the numerators only: 4 + 3 = 7, so {{f:7/9}}. The denominator stays 9 — the parts are still ninths."},
 {"type":"blanks","objective":"4Nf.05","text":"1 − {{f:3/5}} = <span class='frac'><span class='n'>[[1]]</span><span class='d'>5</span></span>","blanks":[{"answer":2,"width":3}],"explanation":"1 whole = {{f:5/5}}. {{f:5/5}} − {{f:3/5}} = {{f:2/5}}."},
 {"type":"order","objective":"4Nf.07","items":["{{f:1/10}}","{{f:1/5}}","{{f:1/2}}","{{f:3/4}}"],"ends":["smallest","largest"],"prompt":"Put these fractions in order, starting with the <b>smallest</b>.",
  "explanation":"For unit fractions, the bigger the denominator the smaller the fraction: {{f:1/10}} < {{f:1/5}} < {{f:1/2}}, and {{f:3/4}} is more than {{f:1/2}}."},
 {"type":"blanks","objective":"4Nf.07","prompt":"Choose <, > or = to make each statement correct.",
  "text":"{{f:3/4}} [[1]] {{f:5/8}}<br>{{f:2/5}} [[2]] {{f:4/10}}<br>{{f:1/3}} [[3]] {{f:1/2}}",
  "blanks":[{"options":["<",">","="],"answer":1},{"options":["<",">","="],"answer":2},{"options":["<",">","="],"answer":0}],
  "explanation":"{{f:3/4}} = {{f:6/8}}, which is more than {{f:5/8}}. {{f:2/5}} = {{f:4/10}}. A third is smaller than a half."},
 {"type":"mcq","objective":"4Nf.07","prompt":"Which fraction is <b>greater</b> than {{f:1/2}}?","options":["{{f:1/4}}","{{f:3/8}}","{{f:2/5}}","{{f:5/8}}"],"answer":3,
  "explanation":"{{f:1/2}} = {{f:4/8}}, and {{f:5/8}} is more than {{f:4/8}}. The others are all less than a half."},
]
rubric={
 "4Nf.03":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of finding a unit fraction of a quantity.","feedback":"Can find a half of a small number with support, but does not yet link a unit fraction to dividing.","feedforward":"Use counters to share a number into equal groups, e.g. {{f:1/4}} of 12 = 12 shared into 4 groups."},
  "Developing":{"descriptor":"Demonstrates developing understanding of unit fractions as operators.","feedback":"Can find some unit fractions of numbers when the division fact is well known, but makes errors with others.","feedforward":"Practise the rule 'to find {{f:1/n}}, divide by n' using times-table facts you know."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of finding unit fractions of quantities.","feedback":"Usually divides by the denominator correctly in straightforward questions.","feedforward":"Apply the method to word problems and check the answer by multiplying back."},
  "Secure":{"descriptor":"Demonstrates secure understanding of unit fractions as operators.","feedback":"Finds unit fractions of quantities accurately, including in word problems, with only minor slips.","feedforward":"Explain why {{f:1/6}} of 24 is less than {{f:1/4}} of 24, and try non-unit fractions such as {{f:3/4}} of 24."},
  "Exceeding":{"descriptor":"Demonstrates confident, accurate and flexible use of unit fractions as operators.","feedback":"Consistently finds unit fractions of amounts accurately and chooses the correct operation in problems.","feedforward":"Solve inverse problems, e.g. '{{f:1/5}} of a number is 7. What is the number?'"}},
 "4Nf.04":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of equivalent fractions.","feedback":"Recognises halves in pictures but does not yet see that different fractions can show the same amount.","feedforward":"Fold paper strips into 2, 4 and 8 parts and compare the shaded amounts."},
  "Developing":{"descriptor":"Demonstrates developing understanding of equivalent fractions.","feedback":"Can find some equivalent fractions from diagrams but is not yet using multiplication to find them.","feedforward":"Use a fraction wall and practise: multiply the numerator and denominator by the same number."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of equivalent proper fractions.","feedback":"Usually identifies equivalent fractions for halves, quarters, fifths and tenths.","feedforward":"Find missing numerators and denominators without a diagram, e.g. {{f:3/5}} = {{f:?/10}}."},
  "Secure":{"descriptor":"Demonstrates secure understanding of equivalent fractions.","feedback":"Finds and matches equivalent fractions accurately, using diagrams or multiplication.","feedforward":"Find several equivalent fractions for the same fraction and spot the pattern."},
  "Exceeding":{"descriptor":"Demonstrates confident and flexible understanding of equivalent fractions.","feedback":"Consistently recognises and generates equivalent fractions, and explains why they are equal.","feedforward":"Use equivalence to simplify fractions, e.g. write {{f:6/8}} in its simplest form."}},
 "4Nf.05":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of adding and subtracting fractions with the same denominator.","feedback":"Often adds or subtracts both numerators and denominators.","feedforward":"Draw bar models: the parts (denominator) stay the same size, you only count how many parts."},
  "Developing":{"descriptor":"Demonstrates developing understanding of adding and subtracting fractions with the same denominator.","feedback":"Adds some fractions correctly but is inconsistent, especially with subtraction or problems.","feedforward":"Say the fractions in words ('2 sevenths + 3 sevenths') before writing the answer."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of adding and subtracting fractions with the same denominator.","feedback":"Usually adds and subtracts correctly in calculations, with some errors in word problems.","feedforward":"Practise two-step problems and subtracting from one whole ({{f:5/5}}, {{f:8/8}})."},
  "Secure":{"descriptor":"Demonstrates secure understanding of adding and subtracting fractions with the same denominator.","feedback":"Calculates accurately, including word problems, with only minor errors.","feedforward":"Estimate first: is the answer more or less than one half? Check your answer makes sense."},
  "Exceeding":{"descriptor":"Demonstrates confident and accurate addition and subtraction of fractions with the same denominator.","feedback":"Consistently calculates accurately and explains why the denominator does not change.","feedforward":"Try answers greater than one whole and write them as mixed numbers, e.g. {{f:5/6}} + {{f:4/6}}."}},
 "4Nf.07":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of comparing and ordering fractions.","feedback":"Often thinks a bigger denominator means a bigger fraction.","feedforward":"Compare unit fractions with a fraction wall: more parts means smaller parts."},
  "Developing":{"descriptor":"Demonstrates developing understanding of comparing and ordering proper fractions.","feedback":"Compares fractions with the same denominator but finds different denominators difficult.","feedforward":"Change one fraction to an equivalent fraction first, then compare, e.g. {{f:3/4}} = {{f:6/8}}."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of comparing proper fractions using =, > and <.","feedback":"Usually uses the symbols correctly, with some errors when denominators differ.","feedforward":"Use {{f:1/2}} as a benchmark: decide whether each fraction is more or less than a half."},
  "Secure":{"descriptor":"Demonstrates secure understanding of comparing and ordering proper fractions.","feedback":"Orders and compares fractions accurately using equivalence, with only minor slips.","feedforward":"Order sets of four or five fractions with different denominators and explain your method."},
  "Exceeding":{"descriptor":"Demonstrates confident and flexible comparing and ordering of fractions.","feedback":"Consistently compares and orders fractions accurately and chooses efficient strategies.","feedforward":"Find a fraction that lies between two given fractions, e.g. between {{f:1/4}} and {{f:1/2}}."}},
}
spec={"title":"Fractions Unit Quiz","year":4,"quiz_number":3,"teacher":"Maths Department","mode":"test","duration_minutes":25,"calculator":False,
 "intro":"Unit 3: fractions.","questions":q,"rubric":rubric}
json.dump(spec,open("spec.json","w"),indent=1,ensure_ascii=False)
