# Cambridge Lower Secondary Mathematics (0862) — learning objectives, Stages 7–9

Source: Cambridge Lower Secondary Mathematics Curriculum Framework 0862 (first teaching 2020).
PEPS mapping: **Year N = Stage N** (Year 7 → Stage 7, Year 8 → Stage 8, Year 9 → Stage 9). Stage 9 ends with the Cambridge Lower Secondary Checkpoint.

Code format: `<stage><strand letter><sub-strand letter>.<nn>`
- N = Number: **Ni** Integers, powers and roots · **Np** Place value, ordering and rounding · **Nf** Fractions, decimals, percentages, ratio and proportion
- A = Algebra: **Ae** Expressions, equations and formulae · **As** Sequences, functions and graphs
- G = Geometry and Measure: **Gg** Geometrical reasoning, shapes and measurements · **Gp** Position and transformation
- S = Statistics and Probability: **Ss** Statistics · **Sp** Probability

Extract only the stage you need, e.g. `sed -n '/^## Stage 8/,/^## Stage 9/p' references/objectives-lower-secondary.md`.

Practical objectives (construct, draw, design and conduct experiments, select sampling methods) can only be assessed indirectly in an auto-marked quiz — say so in the reply when a teacher asks for them.

## Thinking and Working Mathematically (all stages, Primary and Lower Secondary)
- TWM.01 Specialising — choosing an example and checking to see if it satisfies or does not satisfy specific mathematical criteria.
- TWM.02 Generalising — recognising an underlying pattern by identifying many examples that satisfy the same mathematical criteria.
- TWM.03 Conjecturing — forming mathematical questions or ideas.
- TWM.04 Convincing — presenting evidence to justify or challenge a mathematical idea or solution.
- TWM.05 Characterising — identifying and describing the mathematical properties of an object.
- TWM.06 Classifying — organising objects into groups according to their mathematical properties.
- TWM.07 Critiquing — comparing and evaluating mathematical ideas, representations or solutions to identify advantages and disadvantages.
- TWM.08 Improving — refining mathematical ideas or representations to develop a more effective approach or solution.

TWM codes are used as a *secondary* tag on reasoning questions ("Which statement is always true?", "Spot the mistake", "Which method is better?") — every question still needs a content objective as its main tag.

## Stage 7

### Number — Integers, powers and roots
- 7Ni.01 Estimate, add and subtract integers, recognising generalisations.
- 7Ni.02 Understand that brackets, positive indices and operations follow a particular order.
- 7Ni.03 Estimate, multiply and divide integers including where one integer is negative.
- 7Ni.04 Understand lowest common multiple and highest common factor (numbers less than 100).
- 7Ni.05 Use knowledge of tests of divisibility to find factors of numbers greater than 100.
- 7Ni.06 Understand the relationship between squares and corresponding square roots, and cubes and corresponding cube roots.

### Number — Place value, ordering and rounding
- 7Np.01 Use knowledge of place value to multiply and divide whole numbers and decimals by any positive power of 10.
- 7Np.02 Round numbers to a given number of decimal places.

### Number — Fractions, decimals, percentages, ratio and proportion
- 7Nf.01 Recognise that fractions, terminating decimals and percentages have equivalent values.
- 7Nf.02 Estimate and add mixed numbers, and write the answer as a mixed number in its simplest form.
- 7Nf.03 Estimate, multiply and divide proper fractions.
- 7Nf.04 Use knowledge of common factors, laws of arithmetic and order of operations to simplify calculations containing decimals or fractions.
- 7Nf.05 Recognise percentages of shapes and whole numbers, including percentages less than 1 or greater than 100.
- 7Nf.06 Understand the relative size of quantities to compare and order decimals and fractions, using the symbols =, ≠, > and <.
- 7Nf.07 Estimate, add and subtract positive and negative numbers with the same or different number of decimal places.
- 7Nf.08 Estimate, multiply and divide decimals by whole numbers.
- 7Nf.09 Understand and use the unitary method to solve problems involving ratio and direct proportion in a range of contexts.
- 7Nf.10 Use knowledge of equivalence to simplify and compare ratios (same units).
- 7Nf.11 Understand how ratios are used to compare quantities to divide an amount into a given ratio with two parts.

### Algebra — Expressions, equations and formulae
- 7Ae.01 Understand that letters can be used to represent unknown numbers, variables or constants.
- 7Ae.02 Understand that the laws of arithmetic and order of operations apply to algebraic terms and expressions (four operations).
- 7Ae.03 Understand how to manipulate algebraic expressions including: collecting like terms; applying the distributive law with a constant.
- 7Ae.04 Understand that a situation can be represented either in words or as an algebraic expression, and move between the two representations (linear with integer coefficients).
- 7Ae.05 Understand that a situation can be represented either in words or as a formula (single operation), and move between the two representations.
- 7Ae.06 Understand that a situation can be represented either in words or as an equation. Move between the two representations and solve the equation (integer coefficients, unknown on one side).
- 7Ae.07 Understand that letters can represent an open interval (one term).

### Algebra — Sequences, functions and graphs
- 7As.01 Understand term-to-term rules, and generate sequences from numerical and spatial patterns (linear and integers).
- 7As.02 Understand and describe nth term rules algebraically (in the form n ± a, a × n where a is a whole number).
- 7As.03 Understand that a function is a relationship where each input has a single output. Generate outputs from a given function and identify inputs from a given output by considering inverse operations (linear and integers).
- 7As.04 Understand that a situation can be represented either in words or as a linear function in two variables (of the form y = x + c or y = mx), and move between the two representations.
- 7As.05 Use knowledge of coordinate pairs to construct tables of values and plot the graphs of linear functions, where y is given explicitly in terms of x (y = x + c or y = mx).
- 7As.06 Recognise straight-line graphs parallel to the x- or y-axis.
- 7As.07 Read and interpret graphs related to rates of change. Explain why they have a specific shape.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 7Gg.01 Identify, describe and sketch regular polygons, including reference to sides, angles and symmetrical properties.
- 7Gg.02 Understand that if two 2D shapes are congruent, corresponding sides and angles are equal.
- 7Gg.03 Know the parts of a circle: centre, radius, diameter, circumference, chord, tangent.
- 7Gg.04 Understand the relationships and convert between metric units of area, including hectares (ha), square metres (m²), square centimetres (cm²) and square millimetres (mm²).
- 7Gg.05 Derive and know the formula for the area of a triangle. Use the formula to calculate the area of triangles and compound shapes made from rectangles and triangles.
- 7Gg.06 Identify and describe the combination of properties that determine a specific 3D shape.
- 7Gg.07 Derive and use a formula for the volume of a cube or cuboid. Use the formula to calculate the volume of compound shapes made from cuboids, in cubic centimetres (cm³), cubic metres (m³) and cubic millimetres (mm³).
- 7Gg.08 Visualise and represent front, side and top view of 3D shapes.
- 7Gg.09 Use knowledge of area, and properties of cubes and cuboids to calculate their surface area.
- 7Gg.10 Identify reflective symmetry and order of rotational symmetry of 2D shapes and patterns.
- 7Gg.11 Derive the property that the sum of the angles in a quadrilateral is 360°, and use this to calculate missing angles.
- 7Gg.12 Know that the sum of the angles around a point is 360°, and use this to calculate missing angles.
- 7Gg.13 Recognise the properties of angles on: parallel lines and transversals; perpendicular lines; intersecting lines.
- 7Gg.14 Draw parallel and perpendicular lines, and quadrilaterals.

### Geometry and Measure — Position and transformation
- 7Gp.01 Use knowledge of scaling to interpret maps and plans.
- 7Gp.02 Use knowledge of 2D shapes and coordinates to find the distance between two coordinates that have the same x or y coordinate (without the aid of a grid).
- 7Gp.03 Use knowledge of translation of 2D shapes to identify the corresponding points between the original and the translated image, without the use of a grid.
- 7Gp.04 Reflect 2D shapes on coordinate grids, in a given mirror line (x- or y-axis), recognising that the image is congruent to the object after a reflection.
- 7Gp.05 Rotate shapes 90° and 180° around a centre of rotation, recognising that the image is congruent to the object after a rotation.
- 7Gp.06 Understand that the image is mathematically similar to the object after enlargement. Use positive integer scale factors to perform and identify enlargements.

### Statistics and Probability — Statistics
- 7Ss.01 Select and trial data collection and sampling methods to investigate predictions for a set of related statistical questions, considering what data to collect (categorical, discrete and continuous data).
- 7Ss.02 Understand the effect of sample size on data collection and analysis.
- 7Ss.03 Record, organise and represent categorical, discrete and continuous data. Choose and explain which representation to use in a given situation: Venn and Carroll diagrams; tally charts, frequency tables and two-way tables; dual and compound bar charts; waffle diagrams and pie charts; frequency diagrams for continuous data; line graphs; scatter graphs; infographics.
- 7Ss.04 Use knowledge of mode, median, mean and range to describe and summarise large data sets. Choose and explain which one is the most appropriate for the context.
- 7Ss.05 Interpret data, identifying patterns, within and between data sets, to answer statistical questions. Make informal inferences and generalisations, identifying wrong or misleading information.

### Statistics and Probability — Probability
- 7Sp.01 Use the language associated with probability and proportion to describe, compare, order and interpret the likelihood of outcomes.
- 7Sp.02 Understand and explain that probabilities range from 0 to 1, and can be represented as proper fractions, decimals and percentages.
- 7Sp.03 Identify all the possible mutually exclusive outcomes of a single event, and recognise when they are equally likely to happen.
- 7Sp.04 Understand how to find the theoretical probabilities of equally likely outcomes.
- 7Sp.05 Design and conduct chance experiments or simulations, using small and large numbers of trials. Analyse the frequency of outcomes to calculate experimental probabilities.

## Stage 8

### Number — Integers, powers and roots
- 8Ni.01 Understand that brackets, indices (square and cube roots) and operations follow a particular order.
- 8Ni.02 Estimate, multiply and divide integers, recognising generalisations.
- 8Ni.03 Understand factors, multiples, prime factors, highest common factors and lowest common multiples.
- 8Ni.04 Understand the hierarchy of natural numbers, integers and rational numbers.
- 8Ni.05 Use positive and zero indices, and the index laws for multiplication and division.
- 8Ni.06 Recognise squares of negative and positive numbers, and corresponding square roots.
- 8Ni.07 Recognise positive and negative cube numbers, and the corresponding cube roots.

### Number — Place value, ordering and rounding
- 8Np.01 Use knowledge of place value to multiply and divide integers and decimals by 0.1 and 0.01.
- 8Np.02 Round numbers to a given number of significant figures.

### Number — Fractions, decimals, percentages, ratio and proportion
- 8Nf.01 Recognise fractions that are equivalent to recurring decimals.
- 8Nf.02 Estimate and subtract mixed numbers, and write the answer as a mixed number in its simplest form.
- 8Nf.03 Estimate and multiply an integer by a mixed number, and divide an integer by a proper fraction.
- 8Nf.04 Use knowledge of the laws of arithmetic and order of operations (including brackets) to simplify calculations containing decimals or fractions.
- 8Nf.05 Understand percentage increase and decrease, and absolute change.
- 8Nf.06 Understand the relative size of quantities to compare and order decimals and fractions (positive and negative), using the symbols =, ≠, >, <, ≤ and ≥.
- 8Nf.07 Estimate and multiply decimals by integers and decimals.
- 8Nf.08 Estimate and divide decimals by numbers with one decimal place.
- 8Nf.09 Understand and use the relationship between ratio and direct proportion.
- 8Nf.10 Use knowledge of equivalence to simplify and compare ratios (different units).
- 8Nf.11 Understand how ratios are used to compare quantities to divide an amount into a given ratio with two or more parts.

### Algebra — Expressions, equations and formulae
- 8Ae.01 Understand that letters have different meanings in expressions, formulae and equations.
- 8Ae.02 Understand that the laws of arithmetic and order of operations apply to algebraic terms and expressions (four operations, squares and cubes).
- 8Ae.03 Understand how to manipulate algebraic expressions including: applying the distributive law with a single term (squares and cubes); identifying the highest common factor to factorise.
- 8Ae.04 Understand that a situation can be represented either in words or as an algebraic expression, and move between the two representations (linear with integer or fractional coefficients).
- 8Ae.05 Understand that a situation can be represented either in words or as a formula (mixed operations), and manipulate using knowledge of inverse operations to change the subject of a formula.
- 8Ae.06 Understand that a situation can be represented either in words or as an equation. Move between the two representations and solve the equation (integer or fractional coefficients, unknown on either or both sides).
- 8Ae.07 Understand that letters can represent open and closed intervals (two terms).

### Algebra — Sequences, functions and graphs
- 8As.01 Understand term-to-term rules, and generate sequences from numerical and spatial patterns (including fractions).
- 8As.02 Understand and describe nth term rules algebraically (in the form n ± a, a × n, or an ± b, where a and b are positive or negative integers or fractions).
- 8As.03 Understand that a function is a relationship where each input has a single output. Generate outputs from a given function and identify inputs from a given output by considering inverse operations (including fractions).
- 8As.04 Understand that a situation can be represented either in words or as a linear function in two variables (of the form y = mx + c), and move between the two representations.
- 8As.05 Use knowledge of coordinate pairs to construct tables of values and plot the graphs of linear functions, where y is given explicitly in terms of x (y = mx + c).
- 8As.06 Recognise that equations of the form y = mx + c correspond to straight-line graphs, where m is the gradient and c is the y-intercept (integer values of m).
- 8As.07 Read and interpret graphs with more than one component. Explain why they have a specific shape and the significance of intersections of the graphs.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 8Gg.01 Identify and describe the hierarchy of quadrilaterals.
- 8Gg.02 Understand π as the ratio between a circumference and a diameter. Know and use the formula for the circumference of a circle.
- 8Gg.03 Know that distances can be measured in miles or kilometres, and that a kilometre is approximately 5/8 of a mile or a mile is 1.6 kilometres.
- 8Gg.04 Use knowledge of rectangles, squares and triangles to derive the formulae for the area of parallelograms and trapezia. Use the formulae to calculate the area of parallelograms and trapezia.
- 8Gg.05 Understand and use Euler's formula to connect number of vertices, faces and edges of 3D shapes.
- 8Gg.06 Use knowledge of area and volume to derive the formula for the volume of a triangular prism. Use the formula to calculate the volume of triangular prisms.
- 8Gg.07 Represent front, side and top view of 3D shapes to scale.
- 8Gg.08 Use knowledge of area, and properties of cubes, cuboids, triangular prisms and pyramids to calculate their surface area.
- 8Gg.09 Understand that the number of sides of a regular polygon is equal to the number of lines of symmetry and the order of rotation.
- 8Gg.10 Derive and use the fact that the exterior angle of a triangle is equal to the sum of the two interior opposite angles.
- 8Gg.11 Recognise and describe the properties of angles on parallel and intersecting lines, using geometric vocabulary such as alternate, corresponding and vertically opposite.
- 8Gg.12 Construct triangles, midpoint and perpendicular bisector of a line segment, and the bisector of an angle.

### Geometry and Measure — Position and transformation
- 8Gp.01 Understand and use bearings as a measure of direction.
- 8Gp.02 Use knowledge of coordinates to find the midpoint of a line segment.
- 8Gp.03 Translate points and 2D shapes using vectors, recognising that the image is congruent to the object after a translation.
- 8Gp.04 Reflect 2D shapes and points in a given mirror line on or parallel to the x- or y-axis, or y = ± x on coordinate grids. Identify a reflection and its mirror line.
- 8Gp.05 Understand that the centre of rotation, direction of rotation and angle are needed to identify and perform rotations.
- 8Gp.06 Enlarge 2D shapes, from a centre of enlargement (outside or on the shape) with a positive integer scale factor. Identify an enlargement, centre of enlargement and scale factor.

### Statistics and Probability — Statistics
- 8Ss.01 Select, trial and justify data collection and sampling methods to investigate predictions for a set of related statistical questions, considering what data to collect (categorical, discrete and continuous data).
- 8Ss.02 Understand the advantages and disadvantages of different sampling methods.
- 8Ss.03 Record, organise and represent categorical, discrete and continuous data. Choose and explain which representation to use in a given situation: Venn and Carroll diagrams; tally charts, frequency tables and two-way tables; dual and compound bar charts; pie charts; frequency diagrams for continuous data; line graphs and time series graphs; scatter graphs; stem-and-leaf diagrams; infographics.
- 8Ss.04 Use knowledge of mode, median, mean and range to compare two distributions, considering the interrelationship between centrality and spread.
- 8Ss.05 Interpret data, identifying patterns, trends and relationships, within and between data sets, to answer statistical questions. Make informal inferences and generalisations, identifying wrong or misleading information.

### Statistics and Probability — Probability
- 8Sp.01 Understand that complementary events are two events that have a total probability of 1.
- 8Sp.02 Understand that tables, diagrams and lists can be used to identify all mutually exclusive outcomes of combined events (independent events only).
- 8Sp.03 Understand how to find the theoretical probabilities of equally likely combined events.
- 8Sp.04 Design and conduct chance experiments or simulations, using small and large numbers of trials. Compare the experimental probabilities with theoretical outcomes.

## Stage 9

### Number — Integers, powers and roots
- 9Ni.01 Understand the difference between rational and irrational numbers.
- 9Ni.02 Use positive, negative and zero indices, and the index laws for multiplication and division.
- 9Ni.03 Understand the standard form for representing large and small numbers.
- 9Ni.04 Use knowledge of square and cube roots to estimate surds.

### Number — Place value, ordering and rounding
- 9Np.01 Multiply and divide integers and decimals by 10 to the power of any positive or negative number.
- 9Np.02 Understand that when a number is rounded there are upper and lower limits for the original number.

### Number — Fractions, decimals, percentages, ratio and proportion
- 9Nf.01 Deduce whether fractions will have recurring or terminating decimal equivalents.
- 9Nf.02 Estimate, add and subtract proper and improper fractions, and mixed numbers, using the order of operations.
- 9Nf.03 Estimate, multiply and divide fractions, interpret division as a multiplicative inverse, and cancel common factors before multiplying or dividing.
- 9Nf.04 Use knowledge of the laws of arithmetic, inverse operations, equivalence and order of operations (brackets and indices) to simplify calculations containing decimals and fractions.
- 9Nf.05 Understand compound percentages.
- 9Nf.06 Estimate, multiply and divide decimals by integers and decimals.
- 9Nf.07 Understand the relationship between two quantities when they are in direct or inverse proportion.
- 9Nf.08 Use knowledge of ratios and equivalence for a range of contexts.

### Algebra — Expressions, equations and formulae
- 9Ae.01 Understand that the laws of arithmetic and order of operations apply to algebraic terms and expressions (four operations and integer powers).
- 9Ae.02 Understand how to manipulate algebraic expressions including: expanding the product of two algebraic expressions; applying the laws of indices; simplifying algebraic fractions.
- 9Ae.03 Understand that a situation can be represented either in words or as an algebraic expression, and move between the two representations (including squares, cubes and roots).
- 9Ae.04 Understand that a situation can be represented either in words or as a formula (including squares and cubes), and manipulate using knowledge of inverse operations to change the subject of a formula.
- 9Ae.05 Understand that a situation can be represented either in words or as an equation. Move between the two representations and solve the equation (including those with an unknown in the denominator).
- 9Ae.06 Understand that the solution of simultaneous linear equations: is the pair of values that satisfy both equations; can be found algebraically (eliminating one variable); can be found graphically (point of intersection).
- 9Ae.07 Understand that a situation can be represented either in words or as an inequality. Move between the two representations and solve linear inequalities.

### Algebra — Sequences, functions and graphs
- 9As.01 Generate linear and quadratic sequences from numerical patterns and from a given term-to-term rule (any indices).
- 9As.02 Understand and describe nth term rules algebraically (in the form an ± b, where a and b are positive or negative integers or fractions, and in the form n/a, n², n³ or n² ± a, where a is a whole number).
- 9As.03 Understand that a function is a relationship where each input has a single output. Generate outputs from a given function and identify inputs from a given output by considering inverse operations (including indices).
- 9As.04 Understand that a situation can be represented either in words or as a linear function in two variables (of the form y = mx + c or ax + by = c), and move between the two representations.
- 9As.05 Use knowledge of coordinate pairs to construct tables of values and plot the graphs of linear functions, including where y is given implicitly in terms of x (ax + by = c), and quadratic functions of the form y = x² ± a.
- 9As.06 Understand that straight-line graphs can be represented by equations. Find the equation in the form y = mx + c or where y is given implicitly in terms of x (fractional, positive and negative gradients).
- 9As.07 Read, draw and interpret graphs and use compound measures to compare graphs.

### Geometry and Measure — Geometrical reasoning, shapes and measurements
- 9Gg.01 Know and use the formulae for the area and circumference of a circle.
- 9Gg.02 Know and recognise very small or very large units of length, capacity and mass.
- 9Gg.03 Estimate and calculate areas of compound 2D shapes made from rectangles, triangles and circles.
- 9Gg.04 Use knowledge of area and volume to derive the formula for the volume of prisms and cylinders. Use the formula to calculate the volume of prisms and cylinders.
- 9Gg.05 Use knowledge of area, and properties of cubes, cuboids, triangular prisms, pyramids and cylinders to calculate their surface area.
- 9Gg.06 Identify reflective symmetry in 3D shapes.
- 9Gg.07 Derive and use the formula for the sum of the interior angles of any polygon.
- 9Gg.08 Know that the sum of the exterior angles of any polygon is 360°.
- 9Gg.09 Use properties of angles, parallel and intersecting lines, triangles and quadrilaterals to calculate missing angles.
- 9Gg.10 Know and use Pythagoras' theorem.
- 9Gg.11 Construct 60°, 45° and 30° angles and regular polygons.

### Geometry and Measure — Position and transformation
- 9Gp.01 Use knowledge of bearings and scaling to interpret position on maps and plans.
- 9Gp.02 Use knowledge of coordinates to find points on a line segment.
- 9Gp.03 Transform points and 2D shapes by combinations of reflections, translations and rotations.
- 9Gp.04 Identify and describe a transformation (reflections, translations, rotations and combinations of these) given an object and its image.
- 9Gp.05 Recognise and explain that after any combination of reflections, translations and rotations the image is congruent to the object.
- 9Gp.06 Enlarge 2D shapes, from a centre of enlargement (outside, on or inside the shape) with a positive integer scale factor. Identify an enlargement, centre of enlargement and scale factor.
- 9Gp.07 Analyse and describe changes in perimeter and area of squares and rectangles when side lengths are enlarged by a positive integer scale factor.

### Statistics and Probability — Statistics
- 9Ss.01 Select, trial and justify data collection and sampling methods to investigate predictions for a set of related statistical questions, considering what data to collect (categorical, discrete and continuous data).
- 9Ss.02 Explain potential issues and sources of bias with data collection and sampling methods, identifying further questions to ask.
- 9Ss.03 Record, organise and represent categorical, discrete and continuous data. Choose and explain which representation to use in a given situation: Venn and Carroll diagrams; tally charts, frequency tables and two-way tables; dual and compound bar charts; pie charts; line graphs, time series graphs and frequency polygons; scatter graphs; stem-and-leaf and back-to-back stem-and-leaf diagrams; infographics.
- 9Ss.04 Use mode, median, mean and range to compare two distributions, including grouped data.
- 9Ss.05 Interpret data, identifying patterns, trends and relationships, within and between data sets, to answer statistical questions. Make informal inferences and generalisations, identifying wrong or misleading information.

### Statistics and Probability — Probability
- 9Sp.01 Understand that the probability of multiple mutually exclusive events can be found by summation and all mutually exclusive events have a total probability of 1.
- 9Sp.02 Identify when successive and combined events are independent and when they are not.
- 9Sp.03 Understand how to find the theoretical probabilities of combined events.
- 9Sp.04 Design and conduct chance experiments or simulations, using small and large numbers of trials. Calculate the expected frequency of occurrences and compare with observed outcomes.
