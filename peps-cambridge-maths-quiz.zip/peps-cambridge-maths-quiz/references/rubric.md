# PEPS Cambridge Attainment Rubric

Taken from the school's rubric document. Compulsory on every quiz; the quiz engine draws the tables and highlights each learner's band — Claude supplies the words.

## Rules
- Exactly five bands, always in this order: **Emerging (0–20%) | Developing (21–40%) | Meets Expectations (41–60%) | Secure (61–80%) | Exceeding (81%+)**.
- One combined table: bands are columns, each objective is a row (never one table per objective).
- Row header: objective code and statement, question numbers mapped, total marks for that objective.
- Mark ranges come **only from that objective's marks** (the engine calculates them; e.g. 23 marks → 0–4 | 5–9 | 10–13 | 14–18 | 19–23; 12 marks → 0–2 | 3–4 | 5–7 | 8–9 | 10–12; 3 marks → 0 | 1 | *No exact whole-mark score* | 2 | 3). A percentage exactly on a boundary belongs to the lower band (20 % = Emerging, 40 % = Developing, 60 % = Meets Expectations, 80 % = Secure).
- Each band cell gives: **Attainment · Mark Band · Achievement Descriptor · Feedback · Feedforward**.
- Also shown: student information header (Name / Class / Section / Date / Teacher / Marks ___ / total) and the objective summary table (Strand/Objective | Total Marks | Marks Obtained | Level). Quizzes use "Marks" throughout.

## Writing the text (spec["rubric"])
```json
"rubric": {
  "4Nf.05": {
    "Emerging":           {"descriptor": "...", "feedback": "...", "feedforward": "..."},
    "Developing":         {"descriptor": "...", "feedback": "...", "feedforward": "..."},
    "Meets Expectations": {"descriptor": "...", "feedback": "...", "feedforward": "..."},
    "Secure":             {"descriptor": "...", "feedback": "...", "feedforward": "..."},
    "Exceeding":          {"descriptor": "...", "feedback": "...", "feedforward": "..."}
  }
}
```
One entry per content objective in the quiz (TWM secondary tags don't get rows unless `count_secondary_objectives` is true).

- **Achievement Descriptor** — one sentence in the school's pattern, naming the objective's skill:
  Emerging "Demonstrates limited understanding of …" · Developing "Demonstrates developing understanding of …" · Meets Expectations "Demonstrates an appropriate understanding of …" · Secure "Demonstrates secure understanding and accurate use of …" · Exceeding "Demonstrates confident, accurate and flexible use of …".
- **Feedback** — what a learner at this level typically *can do* and the typical error, specific to the maths in this quiz (e.g. "Often adds both numerators and denominators").
- **Feedforward** — one concrete next step the learner can act on, with a mini example where it helps (e.g. "Change one fraction to an equivalent fraction first, e.g. {{f:3/4}} = {{f:6/8}}"). Exceeding feedforward should stretch (explain, generalise, harder problem), not repeat.
- Written to the learner-and-parent reader: plain words, ≤ 30 words per field, supportive, no marks or percentages (the table shows those). `{{f:a/b}}` fractions and `^{2}` are allowed.
- Base Feedback and Feedforward on the misconceptions your distractors target — the rubric and the quiz should tell the same story.

A full worked set (four fraction objectives × five bands) is in the `rubric` block of `references/example_make_spec.py`.
