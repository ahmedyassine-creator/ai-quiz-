# Pre-delivery checklist

Go through every item. Fix, rebuild, re-check.

## Curriculum
- [ ] Every question's `objective` is a real code for the requested **stage** (build script errors/warnings are clear).
- [ ] The question actually assesses that objective — not an easier or neighbouring one — at the stage's number range and vocabulary.
- [ ] All requested objectives are covered; marks roughly reflect their weight. Objectives that can't be auto-marked are named in the reply.
- [ ] No content from a higher stage.

## Rubric
- [ ] Every objective has ≥ 4–5 marks where possible (so the five bands are reachable); objectives with fewer are a deliberate choice.
- [ ] `spec["rubric"]` has objective-specific Descriptor / Feedback / Feedforward for all five bands of every objective (no "generic wording" warning).
- [ ] Rubric feedback matches the misconceptions the distractors target; Exceeding feedforward stretches.
- [ ] `99_results.png` checked: summary table, rubric table and ★ highlight look right.

## Correctness
- [ ] Every answer and every numeric distractor was computed in Python.
- [ ] Each MCQ has exactly one correct option; distractors are plausible misconceptions, not nonsense.
- [ ] `accept` / `exact_text` / `tolerance` / `require` cover every reasonable correct form and reject wrong ones.
- [ ] Explanations are correct and show the method.
- [ ] Figures match the question text (values, labels, scale); nothing in a figure gives the answer away.

## Checker
- [ ] `check_quiz.py` passed: correct 100 %, blank 0 %, wrong 0 %, no JavaScript errors.
- [ ] Contact sheet viewed: text readable, figures sized well, no overflow; mobile screenshot fine.
- [ ] MCQ answer letters reasonably spread (build warns if not).

## Learner experience
- [ ] Language suits the year group; contexts familiar (AED, local names); no reading-heavy items for Years 1–4.
- [ ] Easy → hard order; length and timer suit the year (see SKILL.md defaults).
- [ ] Mode matches purpose (test vs practice); hints only where useful in practice mode.
- [ ] Title, year and class list (if given) are right.

## Worksheets / practice sheets
- [ ] `type` set; no quiz number; `date` is the day it will be set (or today).
- [ ] Remember box: 2–4 key points + a worked example that doesn't give away an answer.
- [ ] 2–3 Challenge questions that genuinely stretch, tagged with objectives.

## Delivery
- [ ] `quiz_number` is the one the teacher gave (never invented) — quizzes only; worksheets have none.
- [ ] The delivered quiz is the real build (not `--preview`), and the build said "results → school Drive" (or the reply says results can't save yet).
- [ ] Quiz .html, answer key .html and spec.json sent; quiz published as an artifact when possible.
- [ ] Reply states: year/stage, questions, marks, time, mode, objectives covered, assumptions made, how to share.
