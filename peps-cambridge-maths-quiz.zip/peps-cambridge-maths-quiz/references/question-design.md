# Designing good auto-marked maths questions

## 1. Pick the type that tests the objective, not the easiest to build
| What the objective asks | Best types |
|---|---|
| Calculate / find / work out | `numeric`, `fraction`, `blanks` (several related answers) |
| Recognise, identify, name, compare | `mcq` (with diagnostic distractors), `classify`, `tf` |
| Order / sequence | `order`, `blanks` for missing terms |
| Represent fractions of shapes | `shade`, `mcq` with shape figures |
| Read scales, clocks, charts, timetables | figure/table + `numeric` or `mcq` |
| Convert units / equivalences | `blanks`, `match` |
| Algebraic manipulation (7–9) | `expression` (see spec-format.md), `mcq` for choose-the-correct-step |
| Solve equations | `numeric` with `prefix: "x ="` |
| Reasoning / TWM (convincing, critiquing, generalising) | `mcq` "Which statement is always true?", "Spot the mistake in Ali's working", "Which method works?"; tag TWM in `also` |
| Draw, construct, measure physically, conduct an investigation | **Can't be auto-marked.** Test the underlying knowledge instead (read a given measurement, choose the correct construction step, interpret given results) and tell the teacher. |

Aim for a mix: at most ~50 % MCQ/TF; the rest require the learner to produce an answer. `tf` is a 50 % guess — use sparingly and never for more than 1–2 marks per quiz.

## 2. Distractors (MCQ, match, classify)
Every wrong option must come from a real misconception, so a wrong choice tells the teacher something. Examples:
- Place value: 40 × 30 → 120 (dropped zeros), 1 200 ✓, 12 000 (extra zero)
- Fractions: {{f:1/3}} + {{f:1/4}} → {{f:2/7}} (added tops and bottoms), {{f:7/12}} ✓, {{f:2/12}}
- Perimeter vs area; radius vs diameter; 12-hour vs 24-hour; hours as decimals (1.5 h = 1 h 50 min ✗)
- Negative numbers: −3 − 5 → −2 or 8; ✓ −8
- Algebra: 3(x + 2) → 3x + 2; 2x × 3x → 6x; (x + 3)² → x² + 9
- Percentages: 15 % off 240 → 225 (subtracted 15) or 36 (gave the discount)
Keep options parallel in form and similar in length; numeric options in ascending order; avoid "all/none of the above" for young learners; four options (three for Years 1–2).

## 3. Accepting every correct answer (the most common failure)
- `numeric` accepts `12500`, `12,500` and `12 500` (Cambridge spacing), `−5` or `-5`, `.5`, fractions like `3/4` and mixed numbers `1 1/2` for the same value, and `25%` only when `allow_percent` is true.
- Money: put the currency in `prefix` ("AED") and ask for the number only; for fils/dirhams mixes, ask in one unit.
- Units: put them in `suffix` so learners type only the number.
- Decimals vs fractions: if either is fine, `numeric` with answer 0.75 accepts "3/4" and "0.75". If a fraction is required, use `fraction`.
- Rounding: if the written form matters (2 d.p., 3 s.f. with trailing zero), use `exact_text` with each acceptable form.
- Time: ask for hours and minutes in two blanks, or use `mcq`; don't make learners type "20:40" free-form unless using `text` with accept ["20:40","2040","20.40"].
- Coordinates, ratios, lists: `text` with `accept` for spaced/unspaced forms, or split into `blanks`.
- Words: `text` is case-insensitive; add common spellings (e.g. "centre", "center"), singular/plural.
- Always run `check_quiz.py` — it proves the model answer is markable; you still must think about alternatives.

## 4. Stage-appropriate language and layout
- **Years 1–2:** one idea per question, ≤ 12 words, pictures wherever possible (`objects`, `shape2d`, `clock`, `fraction_shape`, `dot_array`), numbers ≤ 20 (Y1) / ≤ 100 (Y2). Prefer `mcq` with picture options, `shade`, `order`, `numeric`. Read-aloud is on automatically. 8–10 questions, no timer.
- **Years 3–4:** short word problems in familiar contexts (school trip, canteen, souk, cricket, Sharjah to Dubai). Introduce `blanks`, `match`, `classify`.
- **Years 5–6:** multi-step problems, data displays, reasoning MCQs ("Which is the best estimate?", "Who is correct?").
- **Years 7–9:** Checkpoint-style wording and command words (calculate, show, explain → reasoning MCQ, simplify, expand, factorise, solve, estimate). Include some `expression` questions for algebra.
- Use the Cambridge objective's vocabulary. Don't test reading ability instead of maths: avoid long contexts for EAL learners.
- Order questions easy → hard; start with a confidence-builder.

## 5. Marks
1 mark per simple recall/one-step item; 2–3 marks for multi-part (`blanks`, `match`, `classify`) where each part is an independent skill. Don't award many marks for one idea (e.g. four blanks that are all the same calculation → set `marks: 1` with `all_or_nothing`, or reduce blanks).

## 6. Explanations
One worked line that a learner could learn from: the method, not just "The answer is 28." For MCQ, name the likely error: "If you got 225, you subtracted 15 instead of 15 %."

## 7. Figures checklist
Values on gridlines; axes labelled with units; one scale division easy to read (not 7s); shaded parts unambiguous; "Not drawn accurately" for angle calculations; no answer given away by the figure (e.g. don't label the missing side); figures ≤ ~520 px wide so they fit phones.
