# Worked example: Year 4 Maths online WORKSHEET "Fractions Practice" — no number, dated, points,
# practice mode, compulsory Remember box and Challenge questions, full rubric.
# Run it to write spec.json, then:
#   python <skill_dir>/scripts/build_quiz.py spec.json --key --preview -o preview.html   (check with check_quiz.py)
#   python <skill_dir>/scripts/build_quiz.py spec.json                                   (the real worksheet)
import json
assert 20 // 4 == 5 and 35 // 5 == 7 and 4 * 6 == 24 and 36 // 9 == 4
q = [
 {"type":"numeric","objective":"4Nf.03","prompt":"What is {{f:1/4}} of 20?","answer":5,"hint":"Divide by 4.","explanation":"20 ÷ 4 = 5."},
 {"type":"numeric","objective":"4Nf.03","prompt":"What is {{f:1/5}} of 35?","answer":7,"hint":"Divide by 5.","explanation":"35 ÷ 5 = 7."},
 {"type":"numeric","objective":"4Nf.03","prompt":"A box has 36 dates. Huda eats {{f:1/9}} of them. How many does she eat?","answer":4,"suffix":"dates","hint":"Which number do you divide by?","explanation":"36 ÷ 9 = 4."},
 {"type":"mcq","objective":"4Nf.04","shuffle":True,"prompt":"Which fraction is equivalent to {{f:1/2}}?","options":["{{f:3/6}}","{{f:2/3}}","{{f:1/4}}","{{f:2/5}}"],"answer":0,"hint":"Which one shows half of the whole?","explanation":"3 is half of 6, so {{f:3/6}} = {{f:1/2}}."},
 {"type":"match","objective":"4Nf.04","prompt":"Match each fraction to an equivalent fraction.","left":["{{f:1/2}}","{{f:1/4}}","{{f:3/4}}"],"right":["5/10","2/8","6/8","3/8"],"answer":[0,1,2],"explanation":"Multiply the top and bottom by the same number."},
 {"type":"fraction","objective":"4Nf.05","prompt":"Work out {{f:2/7}} + {{f:3/7}}","answer":"5/7","hint":"The denominator stays the same.","explanation":"2 + 3 = 5 sevenths."},
 {"type":"fraction","objective":"4Nf.05","prompt":"Work out {{f:7/10}} − {{f:4/10}}","answer":"3/10","explanation":"7 − 4 = 3 tenths."},
]
challenge = [
 {"type":"numeric","objective":"4Nf.03","prompt":"{{f:1/6}} of a number is 4. What is the number?","answer":24,"points":2,"explanation":"If one sixth is 4, the whole is 6 × 4 = 24."},
 {"type":"mcq","objective":"4Nf.05","prompt":"Which is bigger: {{f:3/8}} + {{f:2/8}} or {{f:1/2}}?","options":["{{f:3/8}} + {{f:2/8}}","{{f:1/2}}","They are equal"],"answer":0,"explanation":"{{f:3/8}} + {{f:2/8}} = {{f:5/8}}, and {{f:1/2}} = {{f:4/8}}."},
]
remember = {"key_points": ["To find {{f:1/4}} of a number, **divide by 4**. To find {{f:1/5}}, divide by 5.",
                           "Equivalent fractions show the same amount: {{f:1/2}} = {{f:2/4}} = {{f:4/8}}.",
                           "To add or subtract fractions with the same denominator, add or subtract the **numerators** only."],
            "example": "{{f:1/3}} of 12 = 12 ÷ 3 = 4"}
rubric={
 "4Nf.03":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of finding a unit fraction of a quantity.","feedback":"Can find a half of a small number with support, but does not yet link a unit fraction to dividing.","feedforward":"Use counters to share a number into equal groups, e.g. {{f:1/4}} of 12 = 12 shared into 4 groups."},
  "Developing":{"descriptor":"Demonstrates developing understanding of unit fractions as operators.","feedback":"Can find some unit fractions of numbers when the division fact is well known, but makes errors with others.","feedforward":"Practise the rule 'to find {{f:1/n}}, divide by n' using times-table facts you know."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of finding unit fractions of quantities.","feedback":"Usually divides by the denominator correctly in straightforward questions.","feedforward":"Apply the method to word problems and check the answer by multiplying back."},
  "Secure":{"descriptor":"Demonstrates secure understanding of unit fractions as operators.","feedback":"Finds unit fractions of quantities accurately, including in word problems, with only minor slips.","feedforward":"Explain why {{f:1/6}} of 24 is less than {{f:1/4}} of 24, and try non-unit fractions such as {{f:3/4}} of 24."},
  "Exceeding":{"descriptor":"Demonstrates confident, accurate and flexible use of unit fractions as operators.","feedback":"Consistently finds unit fractions of amounts accurately and chooses the correct operation in problems.","feedforward":"Solve inverse problems, e.g. '{{f:1/5}} of a number is 7. What is the number?'"}},
 "4Nf.04":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of equivalent fractions.","feedback":"Recognises halves in pictures but does not yet see that different fractions can show the same amount.","feedforward":"Fold paper strips into 2, 4 and 8 parts and compare the shaded amounts."},
  "Developing":{"descriptor":"Demonstrates developing understanding of equivalent fractions.","feedback":"Can find some equivalent fractions from diagrams but is not yet using multiplication to find them.","feedforward":"Use a fraction wall and practise: multiply the numerator and denominator by the same number."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of equivalent proper fractions.","feedback":"Usually identifies equivalent fractions for halves, quarters, fifths and tenths.","feedforward":"Find missing numerators and denominators without a diagram, e.g. {{f:3/5}} = {{f:?/10}}."},
  "Secure":{"descriptor":"Demonstrates secure understanding of equivalent fractions.","feedback":"Finds and matches equivalent fractions accurately, using diagrams or multiplication.","feedforward":"Find several equivalent fractions for the same fraction and spot the pattern."},
  "Exceeding":{"descriptor":"Demonstrates confident and flexible understanding of equivalent fractions.","feedback":"Consistently recognises and generates equivalent fractions, and explains why they are equal.","feedforward":"Use equivalence to simplify fractions, e.g. write {{f:6/8}} in its simplest form."}},
 "4Nf.05":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of adding and subtracting fractions with the same denominator.","feedback":"Often adds or subtracts both numerators and denominators.","feedforward":"Draw bar models: the parts (denominator) stay the same size, you only count how many parts."},
  "Developing":{"descriptor":"Demonstrates developing understanding of adding and subtracting fractions with the same denominator.","feedback":"Adds some fractions correctly but is inconsistent, especially with subtraction or problems.","feedforward":"Say the fractions in words ('2 sevenths + 3 sevenths') before writing the answer."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of adding and subtracting fractions with the same denominator.","feedback":"Usually adds and subtracts correctly in calculations, with some errors in word problems.","feedforward":"Practise two-step problems and subtracting from one whole ({{f:5/5}}, {{f:8/8}})."},
  "Secure":{"descriptor":"Demonstrates secure understanding of adding and subtracting fractions with the same denominator.","feedback":"Calculates accurately, including word problems, with only minor errors.","feedforward":"Estimate first: is the answer more or less than one half? Check your answer makes sense."},
  "Exceeding":{"descriptor":"Demonstrates confident and accurate addition and subtraction of fractions with the same denominator.","feedback":"Consistently calculates accurately and explains why the denominator does not change.","feedforward":"Try answers greater than one whole and write them as mixed numbers, e.g. {{f:5/6}} + {{f:4/6}}."}},
 "4Nf.07":{
  "Emerging":{"descriptor":"Demonstrates limited understanding of comparing and ordering fractions.","feedback":"Often thinks a bigger denominator means a bigger fraction.","feedforward":"Compare unit fractions with a fraction wall: more parts means smaller parts."},
  "Developing":{"descriptor":"Demonstrates developing understanding of comparing and ordering proper fractions.","feedback":"Compares fractions with the same denominator but finds different denominators difficult.","feedforward":"Change one fraction to an equivalent fraction first, then compare, e.g. {{f:3/4}} = {{f:6/8}}."},
  "Meets Expectations":{"descriptor":"Demonstrates an appropriate understanding of comparing proper fractions using =, > and <.","feedback":"Usually uses the symbols correctly, with some errors when denominators differ.","feedforward":"Use {{f:1/2}} as a benchmark: decide whether each fraction is more or less than a half."},
  "Secure":{"descriptor":"Demonstrates secure understanding of comparing and ordering proper fractions.","feedback":"Orders and compares fractions accurately using equivalence, with only minor slips.","feedforward":"Order sets of four or five fractions with different denominators and explain your method."},
  "Exceeding":{"descriptor":"Demonstrates confident and flexible comparing and ordering of fractions.","feedback":"Consistently compares and orders fractions accurately and chooses efficient strategies.","feedforward":"Find a fraction that lies between two given fractions, e.g. between {{f:1/4}} and {{f:1/2}}."}},
}

spec = {"type":"worksheet","title":"Fractions Practice","year":4,"date":"2026-09-28",
        "questions":q,"challenge":challenge,"remember":remember,"rubric":rubric}
json.dump(spec, open("spec.json","w"), indent=1, ensure_ascii=False)
print("spec.json written")
