# How results reach Google Drive (for Claude)

The school has one results service: a Google Apps Script (`assets/results_service.gs`) inside the private **School Setup Sheet**, owned by `peps@pepsschool.ae` and published as a web app. Its address is `results_url` in `assets/school_config.json`, so every quiz built by this skill uses it automatically. Maths and Science share the same service.

## What the quiz and the service do
| Step | Quiz page | Results service |
|---|---|---|
| Page opens | asks for the sections of the quiz's year | reads the **Classes** tab |
| Learner types the class code, presses *Show my class* | sends year + section + code | checks the code (8 wrong tries per class → 10-minute wait); returns names from the class tab (e.g. `4B`) |
| Learner finishes | sends the full report (HTML) + marks | re-checks code and name, saves `Q<nn>_<class>_<Name>_<yyyy-mm-dd>.pdf` (`_attempt2` … for later tries) under `PEPS Quiz Results / <Subject> / Year <n> / <n><Section> / Q<nn> – <Title> /`, adds a row to the section summary Sheet and the year-group summary Sheet (first attempt = **Official**). **Worksheets / practice sheets** go to `… / <n><Section> / Worksheets / <yyyy-mm-dd> – <Title> /` as `WS_<date>_<class>_<Name>_<date taken>.pdf` (PS_ for practice sheets), with the year summary in `… / Year <n> / Worksheets /` |
| New folder | — | shares section folders with that class's subject teacher(s), subject folders with the subject HOD(s), the root with SLT (Classes and Access tabs) |

Nothing about students is stored in the quiz file. If the internet drops, the learner's page offers **Send results again**; the report can also be printed.

## What the teacher/admin maintains (School Setup Sheet)
- **Class tabs 1A … 9D** — student names (and optional IDs).
- **Classes** — Year · Section · Class code (4 digits, one per class for the year, same for both subjects) · Maths teacher email · Science teacher email · (columns H–I) **Maths teacher name · Science teacher name**. The report's *Teacher* field is filled from these names for the section the learner picks, so one quiz can serve all sections; the spec's `teacher` is only a fallback.
- **Access** — SLT and HODs (with subject).
- After changing teachers, HODs or SLT: menu **PEPS Quiz → Update folder access now**. **PEPS Quiz → Check setup** lists missing tabs, codes, teachers and empty class lists.

## Updating the results service
The worksheet folders need the results service version of September 2026 (it reads `kind`, `ws_date` and `unit` from the quiz). If worksheet results land in a "Q00 – …" folder, the school's Apps Script is older: paste the current `assets/results_service.gs` into the School Setup Sheet's Apps Script and publish a **New version of the same deployment** (Deploy → Manage deployments → ✏️ → New version) — never a new deployment, which would change the address.

## If a teacher reports a problem
- *"That class code is not right"* — check the Classes tab for that section (4 digits). Too many wrong tries: wait 10 minutes.
- *"Your class list could not be found"* — the class tab (e.g. `4B`) is missing or named differently.
- *"No connection to the school system"* / results not saving — school Wi-Fi may block `script.google.com` / `script.googleusercontent.com` (ask IT to allow them), or the service was redeployed with a new address: update `results_url` in `assets/school_config.json` and rebuild the quiz.
- A quiz built with `--preview` (or before `results_url` existed) never saves results — rebuild without `--preview`.
