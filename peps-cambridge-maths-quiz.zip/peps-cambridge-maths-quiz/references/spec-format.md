# Quiz spec format (spec.json)

The build script turns this JSON into the quiz page. Fields not listed are ignored. (Comments below are annotations — real JSON has none.)

## Top level

```json
{
  "type": "quiz",                           // "quiz" (default) | "worksheet" | "practice sheet" — see "Worksheets" below
  "title": "Fractions Check-up",            // required, learner-facing
  "year": 4,                                 // required, 1–9 (stage defaults to year)
  "quiz_number": 3,                          // quizzes only — the teacher's quiz number (1–99); names the Drive folder "Q03 – <title>"
  "stage": 4,                                // optional override
  "teacher": "Ms Ayesha",                    // shown on start page and in the report header — ask for it
  "intro": "A short check on Unit 3.",       // optional, one line
  "mode": "test",                            // "test" (mark at end) | "practice" (Check per question, hints, retry)
  "layout": "paged",                         // "paged" (one question per screen) | "scroll" (all on one page)
  "duration_minutes": 25,                    // 0 or omit = no timer; auto-submits at 0
  "calculator": false,                       // true / false adds an instruction line; omit = say nothing
  "sections": ["A","B","C","D"],             // optional; normally read from the school's Classes tab
  "shuffle_questions": false,
  "show_objectives": true,                   // code chip on each question
  "show_objectives_on_start": true,          // "What this quiz checks" list on start page
  "show_answers": true,                      // question-by-question review on the results page
  "allow_retry": false,                      // default: true in practice mode, false in test mode
  "read_aloud": true,                        // default: true for stages 1–3
  "instructions": ["..."],                   // replaces the default instruction list
  "rubric": { "4Nf.05": { "Emerging": {"descriptor":"…","feedback":"…","feedforward":"…"}, … } },  // see rubric.md — one entry per objective, all five bands
  "band_messages": {"Secure": "…"},          // optional: overall-level message under the score (defaults provided)
  "results_url": "",                         // leave out: taken from assets/school_config.json (the school's results service)
  "collect_hint": "",                        // optional text under the score in preview copies
  "quiz_id": "",                             // optional; default <Subject short>_Y<year>_Q<nn>_<title>
  "file_name": "",                           // optional output file name
  "allow_other_stages": false,               // silence the warning for objectives from another stage
  "count_secondary_objectives": false,       // include "also" codes in the mastery table marks
  "questions": [ ... ]
}
```

## Every question

```json
{
  "id": "q1",                  // optional, unique
  "type": "mcq",               // see types below
  "objective": "4Nf.04",       // required: ONE Cambridge code from the references
  "also": ["TWM.04"],          // optional secondary codes (shown on start page; TWM tags go here)
  "marks": 1,                  // defaults per type (see below)
  "prompt": "Which fraction is equivalent to {{f:1/2}}?",
  "figure": "<svg…>",          // optional: inline SVG/HTML, or a path to .svg/.png/.jpg, or {"src": "...", "width": 300}
  "table": {"headers": ["Day","Visitors"], "rows": [["Mon", 12], ["Tue", 9]], "caption": "…", "row_headers": false},
  "explanation": "…",          // shown after marking — always include (worked step, not just the answer)
  "hint": "…"                  // practice mode only
}
```

### Text markup (prompts, options, explanations, items)
- `{{f:3/4}}` stacked fraction · `{{f:2 1/3}}` mixed number
- `x^{2}` superscript · `a_{1}` subscript · `**bold**` or `<b>bold</b>` · `\n` or `<br>` new line
- Plain HTML is allowed. Use the real minus sign − (U+2212) in displayed negatives, × and ÷ for operations.

## Types

| type | answer fields | default marks | marking |
|---|---|---|---|
| `mcq` | `options` [text or {"text","figure"}], `answer` (0-based index); `columns` 2/4 optional; `shuffle` true to shuffle | 1 | exact |
| `tf` | `answer` true/false (or 0/1); `options` default ["True","False"] | 1 | exact |
| `multi` | `options`, `answer` [indices]; `partial` true for +1 each right −1 each wrong; `hide_count` true to not reveal how many | 1 | all-or-nothing (default) |
| `numeric` | `answer` number or "3/4", "1 1/2", "25%"; `accept` [alternatives]; `tolerance` (± absolute); `prefix`/`suffix` (units, "x =", "AED"); `allow_percent`; `exact_text` [strings] when the written form matters (e.g. "0.040" to 2 s.f.); `answer_display` | 1 | numeric value |
| `text` | `answer`, `accept` [alternatives]; `ignore_spaces` (default true); `prefix`/`suffix`; `input_hint` | 1 | case-insensitive match |
| `expression` | `answer` e.g. "2x+15"; `check` "equivalent" (default, algebraic equivalence) or "exact" (form matters; list forms in `accept`); `require` "simplified" / "expanded" / "factorised" (with equivalent) | 1 | see below |
| `fraction` | `answer` "7/4" or "1 3/4"; `input` "fraction" (default) or "mixed"; `simplest` true; `form` "improper" | 1 | value (+ form rules) |
| `blanks` | `text` with `[[1]]`, `[[2]]` …; `blanks` [{`answer`, `type` "numeric" (default) / "text", `accept`, `tolerance`, `width`} or {`options`: [...], `answer`: index}]; optional `prompt` above | one per blank | proportional |
| `match` | `left` [...], `right` [...] (may include extra distractors), `answer` [right index for each left] | one per pair | proportional |
| `classify` | `categories` [...], `items` [{"text","category": index}] | one per item | proportional |
| `order` | `items` in the CORRECT order (shown shuffled); `ends` ["smallest","largest"]; `partial` true for marks per correct position | 1 | all-or-nothing |
| `shade` | `shape` "bar" / "rect" / "circle"; `parts` or `rows`+`cols`; `answer` count or fraction "3/4" | 1 | number of parts shaded |

Proportional = `floor(marks × correct parts / all parts)`; set `"all_or_nothing": true` to require every part.

### Expression marking in detail
- `equivalent` evaluates both expressions at several random values; `3(x+2)`, `3x+6`, `6+3x` are all equivalent.
- `require: "simplified"` or `"expanded"` also needs: no brackets and no more terms than the model answer (rejects `6x+15-4x`, `3(2x+5)-4x`).
- `require: "factorised"` needs a bracket and a single top-level term — but it does **not** check "fully". For "factorise fully", use `check: "exact"` and list the acceptable forms in `accept` (e.g. `6(2y-3)`, `6(-3+2y)`, `-6(3-2y)`); exact matching ignores spaces, `×`/`*` and case.
- Learners type `x^2` for x², may omit ×, may use `sqrt(…)`. Single-letter variables only.
- Equations and inequalities: ask for the value (`numeric` with `prefix: "x ="`) rather than the whole equation; for inequalities use `text` with every acceptable form in `accept` (`x>3`, `3<x`).

## Example

```json
{
  "title": "Angles Practice", "year": 6, "mode": "practice",
  "questions": [
    {"type": "numeric", "objective": "6Gg.10", "prompt": "Find the size of angle x. (Not drawn accurately.)",
     "figure": "fig_triangle.svg", "answer": 58, "suffix": "°",
     "explanation": "Angles in a triangle add up to 180°. 180 − 90 − 32 = 58°."},
    {"type": "classify", "objective": "6Gg.09", "prompt": "Classify each angle.",
     "categories": ["acute", "obtuse", "reflex"],
     "items": [{"text": "124°", "category": 1}, {"text": "37°", "category": 0}, {"text": "215°", "category": 2}],
     "explanation": "Acute < 90°, obtuse between 90° and 180°, reflex between 180° and 360°."}
  ]
}
```

## Worksheets and practice sheets (`"type": "worksheet"` or `"practice sheet"`)
PEPS rules — automatic once `type` is set:
- **No quiz number.** The screen and report say *Worksheet*; the file is `PEPS_Y5_<Subject>_<Title>_Worksheet.html`.
- **Dated.** `"date": "2026-09-28"` (default: the day it is built). Results save under `<Subject> / Year n / <section> / Worksheets / 2026-09-28 – <Title> /`, with the year summary in `<Subject> / Year n / Worksheets /`, so worksheets never mix with quiz results. Use the date the teacher will set it (ask if they mention one).
- **Points, not marks**, everywhere (question brackets, score, report, rubric, summary sheets). Write `"points": 2` or `"marks": 2` — both work.
- **Practice mode by default** (Check after each question, hints, retry allowed); set `"mode": "test"` to mark at the end instead. Every attempt is still saved; the first is marked Official.
- **Remember box — compulsory**: shown on the start screen and reopened any time with the 📘 Remember button.
  `"remember": {"key_points": ["To find {{f:1/4}} of a number, **divide by 4**.", "…"], "example": "{{f:1/3}} of 12 = 12 ÷ 3 = 4", "figure": "<svg…>" (optional)}` — 2–4 key points in the objective's vocabulary + one worked example showing the method (never the answer to a question).
- **Challenge — compulsory**: `"challenge": [ … ]`, 2–3 harder questions in the normal question format (with objectives and points). They always come last (even with `shuffle_questions`), under a ★ CHALLENGE banner; their points count in the total and the rubric. `challenge_note` changes the line under the banner.
- The rubric and question-by-question report are included as usual.
