/**
 * PEPS Quiz Results service  (Mathematics, Science & English, Years 1–9)
 * -------------------------------------------------------------
 * Lives inside the "School Setup Sheet" (Extensions → Apps Script), owned by peps@pepsschool.ae.
 *
 * What it does
 *  • Gives each quiz the list of names for a class — only after the correct class code is entered.
 *  • Saves every finished quiz as a PDF report in Google Drive:
 *        PEPS Quiz Results / <Subject> / Year <n> / <n><Section> / Q<nn> – <Quiz title> / Q<nn>_<class>_<Name>_<date>.pdf
 *  • Keeps two summary Google Sheets per quiz: one per section (in the quiz folder) and one for the
 *    whole year group (in the Year folder). Every attempt is kept; the first one is marked "Official".
 *  • Shares folders automatically: each teacher sees only the section folders of their classes and subject;
 *    HODs see their whole subject; SLT see everything (from the Classes and Access tabs).
 *
 * The sheet gets a "PEPS Quiz" menu:  Check setup · Update folder access now.
 * Setup and deployment steps: see the step-by-step guide (PEPS_Quiz_Setup_Guide).
 */

// ============================ SETTINGS ============================
var ROOT_FOLDER_NAME = 'PEPS Quiz Results';   // the folder in this account's My Drive
var TIME_ZONE = 'Asia/Dubai';
var SUBJECTS = ['Mathematics', 'Science', 'English'];
var MAX_WRONG_CODES = 8;                      // per class, per 10 minutes
// ==================================================================

// ---------------------------------------------------------------- web entry points
function doGet() {
  return json_({ ok: true, service: 'PEPS Quiz Results', time: new Date().toISOString() });
}

function doPost(e) {
  var d;
  try { d = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false, error: 'bad_request', message: 'bad request' }); }
  try {
    if (d.action === 'sections') return json_(apiSections_(d));
    if (d.action === 'roster') return json_(apiRoster_(d));
    if (d.action === 'submit') return json_(apiSubmit_(d));
    return json_({ ok: false, error: 'unknown_action', message: 'unknown action' });
  } catch (err) {
    console.error(err && err.stack || err);
    return json_({ ok: false, error: 'server', message: String(err && err.message || err).substring(0, 120) });
  }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// ---------------------------------------------------------------- API
function apiSections_(d) {
  var year = Number(d.year);
  var secs = readClasses_().filter(function (c) { return c.year === year; }).map(function (c) { return c.section; });
  secs.sort();
  return { ok: true, sections: secs };
}

function apiRoster_(d) {
  var cls = checkCode_(d);
  if (!cls.ok) return cls;
  var subject = SUBJECTS.indexOf(d.subject) >= 0 ? d.subject : '';
  return { ok: true, teacher: subject ? (cls.teacherNames[subject] || '') : '',
           students: readRoster_(cls.tab).map(function (s) { return { name: s.name, id: s.id }; }) };
}

function apiSubmit_(d) {
  var cls = checkCode_(d);
  if (!cls.ok) return cls;
  var subject = SUBJECTS.indexOf(d.subject) >= 0 ? d.subject : null;
  if (!subject) return { ok: false, error: 'subject', message: 'unknown subject' };
  var roster = readRoster_(cls.tab);
  var st = roster.filter(function (s) { return s.name === String(d.name || '').trim(); })[0];
  if (!st) return { ok: false, error: 'name', message: 'name not in class list' };

  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    var qn = ('0' + Number(d.quiz_number || 0)).slice(-2);
    var title = cleanName_(d.title || 'Quiz');
    // worksheets / practice sheets: no number, own "Worksheets" folders, dated by the worksheet's date
    var ws = d.kind === 'worksheet' || d.kind === 'practice sheet';
    var kindLabel = d.kind === 'practice sheet' ? 'Practice Sheet' : 'Worksheet';
    var wsDate = /^\d{4}-\d{2}-\d{2}$/.test(String(d.ws_date || '')) ? String(d.ws_date) : Utilities.formatDate(new Date(), TIME_ZONE, 'yyyy-MM-dd');
    var quizLabel = ws ? wsDate + ' – ' + title : 'Q' + qn + ' – ' + title;
    var yearFolder = getOrCreate_(getOrCreate_(getRoot_(), subject, function (f) { shareSubject_(f, subject); }), 'Year ' + cls.year);
    var secFolder = getOrCreate_(yearFolder, cls.tab, function (f) { shareSection_(f, cls, subject); });
    var quizFolder = getOrCreate_(ws ? getOrCreate_(secFolder, 'Worksheets') : secFolder, quizLabel);

    // summaries
    var secSheet = ws ? getSummary_(quizFolder, 'Summary – ' + kindLabel + ' ' + wsDate + ' ' + title + ' (' + cls.tab + ')', d, false)
                      : getSummary_(quizFolder, 'Summary – Q' + qn + ' ' + title + ' (' + cls.tab + ')', d, false);
    var yearSheet = ws ? getSummary_(getOrCreate_(yearFolder, 'Worksheets'), 'Year ' + cls.year + ' – ' + kindLabel + ' ' + wsDate + ' ' + title + ' – All Sections', d, true)
                       : getSummary_(yearFolder, 'Year ' + cls.year + ' – Q' + qn + ' ' + title + ' – All Sections', d, true);

    var attempt = countAttempts_(secSheet, st.name, st.id) + 1;
    var official = attempt === 1;

    // PDF report
    var date = Utilities.formatDate(new Date(d.finished || new Date()), TIME_ZONE, 'yyyy-MM-dd');
    var fname = (ws ? (d.kind === 'practice sheet' ? 'PS_' : 'WS_') + wsDate : 'Q' + qn) + '_' + cls.tab + '_' + st.name.replace(/[^A-Za-z0-9؀-ۿ]+/g, '_') + '_' + date +
                (attempt > 1 ? '_attempt' + attempt : '') + '.pdf';
    var html = String(d.report_html || '');
    if (!html || html.length > 3000000) html = fallbackReport_(d, st, cls);
    var pdf = Utilities.newBlob(html, 'text/html', 'report.html').getAs('application/pdf').setName(fname);
    var file = quizFolder.createFile(pdf);

    var row = summaryRow_(d, st, cls, attempt, official, file.getUrl(), false);
    secSheet.appendRow(row);
    yearSheet.appendRow(summaryRow_(d, st, cls, attempt, official, file.getUrl(), true));
    formatLastRow_(secSheet, official);
    formatLastRow_(yearSheet, official);
    return { ok: true, attempt: attempt, official: official };
  } finally {
    lock.releaseLock();
  }
}

// ---------------------------------------------------------------- class codes and rosters
function checkCode_(d) {
  var year = Number(d.year), section = String(d.section || '').trim().toUpperCase();
  var code = String(d.code || '').trim();
  var cls = readClasses_().filter(function (c) { return c.year === year && c.section === section; })[0];
  if (!cls) return { ok: false, error: 'class', message: 'class not found' };
  var cache = CacheService.getScriptCache(), key = 'bad_' + cls.tab, bad = Number(cache.get(key) || 0);
  if (bad >= MAX_WRONG_CODES) return { ok: false, error: 'wait', message: 'too many wrong codes' };
  if (!cls.code || code !== cls.code) {
    cache.put(key, String(bad + 1), 600);
    return { ok: false, error: 'code', message: 'wrong class code' };
  }
  cls.ok = true;
  return cls;
}

function readClasses_() {
  var sh = setupSheet_('Classes');
  var v = sh.getDataRange().getDisplayValues();
  var h = v[0].map(function (x) { return String(x).toLowerCase(); });
  var cY = findCol_(h, ['year']), cS = findCol_(h, ['section']), cC = findCol_(h, ['class code', 'code']),
      cM = findCol_(h, ['maths teacher email', 'maths email', 'math']), cSc = findCol_(h, ['science teacher email', 'science email', 'science']),
      cMn = findCol_(h, ['maths teacher name', 'math teacher name']), cScn = findCol_(h, ['science teacher name']),
      cEn = findCol_(h, ['english teacher email', 'english email']), cEnn = findCol_(h, ['english teacher name']);
  var out = [];
  for (var i = 1; i < v.length; i++) {
    var y = Number(v[i][cY]), s = String(v[i][cS] || '').trim().toUpperCase();
    if (!y || !s) continue;
    var code = String(v[i][cC] || '').replace(/\D/g, '');
    if (code && code.length < 4) code = ('0000' + code).slice(-4);
    out.push({ year: y, section: s, tab: y + s, code: code,
               teachers: { Mathematics: emails_(v[i][cM]), Science: emails_(v[i][cSc]), English: cEn >= 0 ? emails_(v[i][cEn]) : [] },
               teacherNames: { Mathematics: cMn >= 0 ? String(v[i][cMn] || '').trim() : '',
                               Science: cScn >= 0 ? String(v[i][cScn] || '').trim() : '',
                               English: cEnn >= 0 ? String(v[i][cEnn] || '').trim() : '' } });
  }
  return out;
}

function readRoster_(tab) {
  var sh = setupSheet_(tab);
  var v = sh.getDataRange().getDisplayValues();
  var h = v[0].map(function (x) { return String(x).toLowerCase(); });
  var cN = findCol_(h, ['student name', 'name']), cI = findCol_(h, ['student id', 'id']);
  var out = [];
  for (var i = 1; i < v.length; i++) {
    var n = String(v[i][cN] || '').trim();
    if (n) out.push({ name: n, id: cI >= 0 ? String(v[i][cI] || '').trim() : '' });
  }
  return out;
}

function readAccess_() {
  var sh = setupSheet_('Access');
  var v = sh.getDataRange().getDisplayValues();
  var h = v[0].map(function (x) { return String(x).toLowerCase(); });
  var cE = findCol_(h, ['email']), cR = findCol_(h, ['role']), cS = findCol_(h, ['subject']);
  var slt = [], hod = { Mathematics: [], Science: [], English: [] };
  var alias = { maths: 'Mathematics', math: 'Mathematics', mathematics: 'Mathematics', science: 'Science',
                english: 'English', esl: 'English', 'english as a second language': 'English' };
  for (var i = 1; i < v.length; i++) {
    var em = emails_(v[i][cE]), role = String(v[i][cR] || '').trim().toUpperCase(), sub = String(v[i][cS] || '').trim();
    sub = alias[sub.toLowerCase()] || sub;
    if (!em.length) continue;
    if (role === 'SLT') slt = slt.concat(em);
    else if (role === 'HOD' && hod[sub]) hod[sub] = hod[sub].concat(em);
  }
  return { slt: slt, hod: hod };
}

function setupSheet_(name) {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
  if (!sh) throw new Error('Tab "' + name + '" not found in the School Setup Sheet');
  return sh;
}
function findCol_(headers, names) {
  for (var n = 0; n < names.length; n++)
    for (var i = 0; i < headers.length; i++) if (headers[i].indexOf(names[n]) >= 0) return i;
  return -1;
}
function emails_(cell) {
  return String(cell || '').split(/[,;\s]+/).map(function (x) { return x.trim().toLowerCase(); })
    .filter(function (x) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x); });
}
function cleanName_(s) { return String(s).replace(/[\\\/:*?"<>|#%]+/g, ' ').replace(/\s+/g, ' ').trim().substring(0, 80); }

// ---------------------------------------------------------------- folders and sharing
function getRoot_() {
  var props = PropertiesService.getScriptProperties(), id = props.getProperty('ROOT_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) { /* re-find below */ } }
  var it = DriveApp.getRootFolder().getFoldersByName(ROOT_FOLDER_NAME);
  if (!it.hasNext()) throw new Error('Folder "' + ROOT_FOLDER_NAME + '" not found in My Drive');
  var f = it.next();
  props.setProperty('ROOT_ID', f.getId());
  return f;
}

function getOrCreate_(parent, name, onCreate) {
  var it = parent.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  var f = parent.createFolder(name);
  if (onCreate) { try { onCreate(f); } catch (e) { console.error('sharing failed: ' + e); } }
  return f;
}

function shareSubject_(folder, subject) {
  var acc = readAccess_();
  addViewers_(folder, acc.hod[subject]);
  addViewers_(getRoot_(), acc.slt);          // SLT see everything
}
function shareSection_(folder, cls, subject) {
  addViewers_(folder, cls.teachers[subject] || []);
}
function addViewers_(folder, list) {
  var have = folder.getViewers().concat(folder.getEditors()).map(function (u) { return String(u.getEmail()).toLowerCase(); });
  var owner = folder.getOwner() ? String(folder.getOwner().getEmail()).toLowerCase() : '';
  list.forEach(function (em) {
    if (em && em !== owner && have.indexOf(em) < 0) { try { folder.addViewer(em); } catch (e) { console.error('addViewer ' + em + ': ' + e); } }
  });
}
function removeViewersExcept_(folder, keep) {
  folder.getViewers().forEach(function (u) {
    var em = String(u.getEmail()).toLowerCase();
    if (keep.indexOf(em) < 0) { try { folder.removeViewer(em); } catch (e) { /* inherited access cannot be removed here */ } }
  });
}

/** Menu: re-applies access for every folder from the Classes and Access tabs (use after changing teachers/HODs/SLT). */
function updateFolderAccess() {
  var root = getRoot_(), acc = readAccess_(), classes = readClasses_(), n = 0;
  addViewers_(root, acc.slt);
  removeViewersExcept_(root, acc.slt);
  SUBJECTS.forEach(function (subject) {
    var it = root.getFoldersByName(subject);
    if (!it.hasNext()) return;
    var subFolder = it.next();
    addViewers_(subFolder, acc.hod[subject]);
    removeViewersExcept_(subFolder, acc.slt.concat(acc.hod[subject]));
    classes.forEach(function (c) {
      var yi = subFolder.getFoldersByName('Year ' + c.year);
      if (!yi.hasNext()) return;
      var si = yi.next().getFoldersByName(c.tab);
      if (!si.hasNext()) return;
      var sf = si.next(), teachers = c.teachers[subject] || [];
      addViewers_(sf, teachers);
      removeViewersExcept_(sf, acc.slt.concat(acc.hod[subject]).concat(teachers));
      n++;
    });
  });
  return n;
}

// ---------------------------------------------------------------- summary sheets
function getSummary_(folder, name, d, withSection) {
  var it = folder.getFilesByName(name);
  if (it.hasNext()) return SpreadsheetApp.open(it.next()).getSheets()[0];
  var ss = SpreadsheetApp.create(name);
  DriveApp.getFileById(ss.getId()).moveTo(folder);
  var sh = ss.getSheets()[0];
  sh.setName('Results');
  var unit = d.unit === 'point' ? 'points' : 'marks';
  var head = ['Finished', 'Date taken', 'Name', 'Student ID'];
  if (withSection) head.push('Section');
  head = head.concat(['Attempt', 'Status', 'Score', 'Max', 'Percent', 'Level', 'Minutes', 'Time ran out']);
  (d.objectives || []).forEach(function (o) { head.push(o.code + ' ' + unit, o.code + ' level'); });
  (d.questions || []).forEach(function (q) { head.push('Q' + q.n + ' (' + q.objective + ')'); });
  head.push('Report (PDF)');
  sh.appendRow(head);
  sh.getRange(1, 1, 1, head.length).setFontWeight('bold').setBackground('#efecfb').setWrap(true);
  sh.setFrozenRows(1);
  sh.setFrozenColumns(withSection ? 5 : 4);
  return sh;
}

function summaryRow_(d, st, cls, attempt, official, url, withSection) {
  var fin = new Date(d.finished || new Date());
  var row = [Utilities.formatDate(fin, TIME_ZONE, 'yyyy-MM-dd HH:mm'), Utilities.formatDate(fin, TIME_ZONE, 'd MMM yyyy'), st.name, st.id];
  if (withSection) row.push(cls.tab);
  row = row.concat([attempt, official ? 'Official' : 'Attempt ' + attempt, Number(d.score), Number(d.max),
                    Number(d.max) ? Number(d.score) / Number(d.max) : 0, d.band, Number(d.minutes || 0), d.time_up ? 'yes' : '']);
  (d.objectives || []).forEach(function (o) { row.push("'" + o.got + '/' + o.max, o.level); });
  (d.questions || []).forEach(function (q) { row.push("'" + q.score + '/' + q.marks); });
  row.push(url);
  return row;
}

function countAttempts_(sh, name, id) {
  var v = sh.getDataRange().getDisplayValues(), n = 0;
  for (var i = 1; i < v.length; i++) if (v[i][2] === name && String(v[i][3]) === String(id)) n++;
  return n;
}

function formatLastRow_(sh, official) {
  var r = sh.getLastRow(), h = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  var pc = h.indexOf('Percent') + 1;
  if (pc > 0) sh.getRange(r, pc).setNumberFormat('0%');
  if (!official) sh.getRange(r, 1, 1, sh.getLastColumn()).setFontColor('#777777');
}

function fallbackReport_(d, st, cls) {
  return '<h2>' + (d.title || 'Quiz') + '</h2><p>' + st.name + ' – ' + cls.tab + '</p><p>Score: ' + d.score + ' / ' + d.max +
         ' (' + d.percent + '%) – ' + d.band + '</p>';
}

// ---------------------------------------------------------------- menu (in the School Setup Sheet)
function onOpen() {
  SpreadsheetApp.getUi().createMenu('PEPS Quiz')
    .addItem('Check setup', 'checkSetup')
    .addItem('Update folder access now', 'menuUpdateAccess')
    .addToUi();
}

function checkSetup() {
  var ui = SpreadsheetApp.getUi(), msgs = [];
  try { var root = getRoot_(); msgs.push('✓ Results folder found: ' + root.getName()); } catch (e) { msgs.push('✗ ' + e.message); }
  try {
    var classes = readClasses_(), missingTab = [], noCode = [], noTeacher = [];
    classes.forEach(function (c) {
      if (!SpreadsheetApp.getActiveSpreadsheet().getSheetByName(c.tab)) missingTab.push(c.tab);
      if (!c.code || c.code.length !== 4) noCode.push(c.tab);
      if (!c.teachers.Mathematics.length && !c.teachers.Science.length && !c.teachers.English.length) noTeacher.push(c.tab);
    });
    msgs.push('✓ Classes listed: ' + classes.length);
    if (missingTab.length) msgs.push('✗ Class tab missing for: ' + missingTab.join(', '));
    if (noCode.length) msgs.push('✗ Class code missing / not 4 digits: ' + noCode.join(', '));
    if (noTeacher.length) msgs.push('• No teacher email yet: ' + noTeacher.join(', '));
    var empty = classes.filter(function (c) { try { return readRoster_(c.tab).length === 0; } catch (e) { return false; } })
                       .map(function (c) { return c.tab; });
    if (empty.length) msgs.push('• No students typed yet in: ' + empty.join(', '));
  } catch (e) { msgs.push('✗ ' + e.message); }
  try { var a = readAccess_(); msgs.push('✓ SLT: ' + a.slt.length + ' · Maths HOD: ' + a.hod.Mathematics.length + ' · Science HOD: ' + a.hod.Science.length + ' · English HOD: ' + a.hod.English.length); }
  catch (e) { msgs.push('✗ ' + e.message); }
  ui.alert('PEPS Quiz – setup check', msgs.join('\n'), ui.ButtonSet.OK);
}

function menuUpdateAccess() {
  var n = updateFolderAccess();
  SpreadsheetApp.getUi().alert('Folder access updated for ' + n + ' class folders.');
}

/** Run once from the editor (▶ Run) to give the script permission to use Drive and Sheets. */
function authorize() {
  getRoot_();
  readClasses_();
  Utilities.newBlob('<p>test</p>', 'text/html', 't.html').getAs('application/pdf');
  Logger.log('All permissions granted. Results folder: ' + getRoot_().getName());
}
