#!/usr/bin/env python3
"""
Test a built PEPS quiz in a real (headless) browser.

Usage:
    python check_quiz.py QUIZ.html [--out DIR] [--mobile]

What it does
  1. Opens the quiz, enters a test name/class, starts it.
  2. Answers EVERY question correctly through the real page controls (click, type, select,
     re-order, shade) and screenshots each question.
  3. Finishes and checks the result is 100 %. Any question that doesn't score full marks is
     listed — that means the answer in the spec can't be entered or is marked wrongly.
  4. Runs again leaving everything blank and checks the result is 0 % (nothing is free).
  5. Runs a third time with deliberately wrong answers and checks nothing scores.
  6. Saves screenshots (start page, each question, results) and a contact sheet
     DIR/contact_sheet.png to look at with the Read tool.
Exit code 1 if any check fails or the page logs a JavaScript error.
"""
import argparse, os, sys, json
from playwright.sync_api import sync_playwright

ANSWER_JS = r"""
(mode) => {
  const {Q} = window.__PEPSQUIZ__;
  const fire = (el) => { el.dispatchEvent(new Event('input', {bubbles:true})); el.dispatchEvent(new Event('change', {bubbles:true})); };
  const setVal = (el, v) => { el.value = v; fire(el); };
  const wrongNum = (a) => { const n = parseFloat(String(a).replace(/[^0-9.\-]/g,'')); return isFinite(n) ? String(n + 7) : '999'; };
  const cards = [...document.querySelectorAll('.qcard')];
  const log = [];
  for (const card of cards) {
    const qi = +card.dataset.qi; const q = Q.questions[qi];
    if (mode === 'blank') continue;
    const W = mode === 'wrong';
    try {
    switch (q.type) {
      case 'mcq': case 'tf': {
        const target = W ? q.options.findIndex((_,i)=>i!==q.answer) : q.answer;
        card.querySelector(`.opt[data-oi="${target}"]`).click(); break; }
      case 'multi': {
        if (W) { const w = q.options.findIndex((_,i)=>!q.answer.includes(i)); card.querySelector(`.opt[data-oi="${w}"]`).click(); }
        else q.answer.forEach(i => card.querySelector(`.opt[data-oi="${i}"]`).click());
        break; }
      case 'numeric': setVal(card.querySelector('.ansArea input'), W ? wrongNum(q.answer) : String(q.answer)); break;
      case 'text': setVal(card.querySelector('.ansArea input'), W ? 'zzz' : String(q.answer)); break;
      case 'expression': setVal(card.querySelector('.ansArea input'), W ? String(q.answer)+'+1' : String(q.answer)); break;
      case 'fraction': {
        let s = String(q.answer).trim(); let w=0,n,d,m;
        if ((m = s.match(/^(-?\d+)\s+(\d+)\s*\/\s*(\d+)$/))) { w=+m[1]; n=+m[2]; d=+m[3]; }
        else if ((m = s.match(/^(-?\d+)\s*\/\s*(\d+)$/))) { n=+m[1]; d=+m[2]; }
        else { w=+s; n=0; d=1; }
        const mixed = q.input === 'mixed';
        if (mixed && !w && n >= d && d>0) { w = Math.floor(n/d); n = n % d; }
        if (!mixed && w) { n = Math.abs(w)*d + n; if (w<0) n=-n; w=0; }
        if (W) n = n + 1;
        const wi = card.querySelector('input[data-k="w"]'); if (wi) setVal(wi, w ? String(w) : '');
        setVal(card.querySelector('input[data-k="n"]'), String(n)); setVal(card.querySelector('input[data-k="d"]'), String(d)); break; }
      case 'blanks':
        q.blanks.forEach((b,i) => { const el = card.querySelector(`[data-b="${i}"]`);
          if (b.options) setVal(el, String(W ? (b.answer+1) % b.options.length : b.answer));
          else setVal(el, W ? (b.type==='text' ? 'zzz' : wrongNum(b.answer)) : String(b.answer)); });
        break;
      case 'match':
        q.answer.forEach((a,i) => setVal(card.querySelector(`select[data-i="${i}"]`), String(W ? (a+1) % q.right.length : a))); break;
      case 'classify':
        q.items.forEach((it,i) => { const c = typeof it === 'object' ? it.category : q.answer[i];
          setVal(card.querySelector(`select[data-i="${i}"]`), String(W ? (c+1) % q.categories.length : c)); }); break;
      case 'order': {
        const want = q.items.map((_,i)=>i); if (W) want.reverse();
        for (let k = 0; k < want.length; k++) {
          let guard = 0;
          while (guard++ < 50) {
            const lis = [...card.querySelectorAll('.order-item')];
            const j = lis.findIndex(li => +li.dataset.it === want[k]);
            if (j <= k) break;
            lis[j].querySelector('button[data-d="-1"]').click();
          }
        }
        if (W) { const lis=[...card.querySelectorAll('.order-item')]; if (lis.every((li,i)=>+li.dataset.it===i)) lis[1].querySelector('button[data-d="-1"]').click(); }
        break; }
      case 'shade': {
        const parts = [...card.querySelectorAll('.part')]; const n = W ? (q.answer === parts.length ? 1 : q.answer + 1) : q.answer;
        for (let i = 0; i < n; i++) parts[i].dispatchEvent(new MouseEvent('click', {bubbles:true})); break; }
    }
    } catch (e) { log.push(`Q${+card.dataset.pos+1} (${q.id}, ${q.type}): could not enter answer: ${e.message}`); }
  }
  return log;
}
"""

PER_Q_JS = r"""
() => { const {Q, MARK} = window.__PEPSQUIZ__; const out=[];
  document.querySelectorAll('.review .rq').forEach((el,i)=>{ const t=el.querySelector('.marks').textContent; out.push(t.trim()); });
  return out; }
"""


def fill_start(page):
    if page.locator("#offlineBox.hidden").count():
        raise SystemExit("✗ This quiz is in ONLINE mode (it has a results_url). Build a preview copy for checking: "
                         "build_quiz.py spec.json --preview -o preview.html, then check preview.html.")
    page.fill("#inName", "Test Student")
    page.select_option("#inSec", index=1)


def run(page, url, mode, shots_dir=None):
    page.goto(url)
    fill_start(page)
    if shots_dir:
        page.screenshot(path=os.path.join(shots_dir, "00_start.png"), full_page=True)
    page.click("#btnStart")
    log = page.evaluate(ANSWER_JS, mode)
    shots = []
    if shots_dir:
        n = page.locator(".qcard").count()
        paged = page.locator(".qcard.hidden").count() > 0 or n == 1
        for pos in range(n):
            if paged:
                page.evaluate("p=>document.querySelectorAll('.dot')[p].click()", pos)
                page.wait_for_timeout(120)
                card = page.locator(f'.qcard[data-pos="{pos}"]')
            else:
                card = page.locator(f'.qcard[data-pos="{pos}"]')
            p = os.path.join(shots_dir, f"q{pos+1:02d}.png")
            card.screenshot(path=p)
            shots.append(p)
    page.evaluate("()=>{window.onbeforeunload=null}")
    # finish
    if page.locator("#btnFinish").is_visible():
        page.click("#btnFinish")
    else:
        page.evaluate("()=>{const b=[...document.querySelectorAll('.qcard .next')].pop(); b.click();}")
    page.click("#mdYes")
    page.wait_for_selector("#scrResults:not(.hidden)")
    pct = page.inner_text("#rsPct")
    marks = page.inner_text("#rsMarks")
    per_q = page.evaluate(PER_Q_JS)
    if shots_dir:
        page.screenshot(path=os.path.join(shots_dir, "99_results.png"), full_page=True)
    return log, pct, marks, per_q, shots


def contact_sheet(paths, out, cols=3, width=460):
    from PIL import Image
    ims = [Image.open(p) for p in paths]
    if not ims:
        return
    th = []
    for im in ims:
        r = width / im.width
        th.append(im.resize((width, max(1, int(im.height * r)))))
    rows = [th[i:i + cols] for i in range(0, len(th), cols)]
    H = sum(max(t.height for t in row) + 10 for row in rows)
    sheet = Image.new("RGB", (cols * (width + 10) + 10, H + 10), "white")
    y = 10
    for row in rows:
        x = 10
        for t in row:
            sheet.paste(t, (x, y))
            x += width + 10
        y += max(t.height for t in row) + 10
    sheet.save(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("quiz")
    ap.add_argument("--out", default=None)
    ap.add_argument("--mobile", action="store_true", help="also screenshot the first question at phone width")
    a = ap.parse_args()
    url = "file://" + os.path.abspath(a.quiz)
    out = a.out or os.path.splitext(os.path.abspath(a.quiz))[0] + "_check"
    os.makedirs(out, exist_ok=True)
    problems = []
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context(viewport={"width": 1000, "height": 900})
        page = ctx.new_page()
        js_errors = []
        page.on("pageerror", lambda e: js_errors.append(str(e)))
        page.on("dialog", lambda d: d.accept())

        log, pct, marks, per_q, shots = run(page, url, "correct", out)
        problems += log
        print(f"All-correct run: {pct} ({marks})")
        if pct != "100%":
            for i, t in enumerate(per_q):
                got, mx = [s.strip() for s in t.split("/")]
                if got != mx:
                    problems.append(f"Q{i+1}: correct answer scored {t} — check the spec answer / accept list")
        log2, pct2, marks2, _, _ = run(page, url, "blank")
        print(f"All-blank run:   {pct2} ({marks2})")
        if pct2 != "0%":
            problems.append(f"Blank run scored {pct2} — some question gives marks for no answer")
        log3, pct3, marks3, per_q3, _ = run(page, url, "wrong")
        print(f"All-wrong run:   {pct3} ({marks3})")
        for i, t in enumerate(per_q3):
            got = t.split("/")[0].strip()
            if got != "0":
                problems.append(f"Q{i+1}: a deliberately wrong answer scored {t} — check tolerance/accept list")
        if a.mobile:
            m = b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2)
            mp = m.new_page()
            mp.goto(url)
            fill_start(mp)
            mp.click("#btnStart")
            mp.screenshot(path=os.path.join(out, "mobile_q1.png"), full_page=True)
            print(f"Mobile screenshot: {os.path.join(out, 'mobile_q1.png')}")
        b.close()
    problems += [f"JavaScript error: {e}" for e in js_errors]
    sheet = os.path.join(out, "contact_sheet.png")
    contact_sheet(shots, sheet)
    print(f"Screenshots: {out}/  (contact sheet: {sheet}; start page 00_start.png; results 99_results.png)")
    if problems:
        print("\n✗ PROBLEMS:")
        for x in problems:
            print("  - " + x)
        sys.exit(1)
    print("✓ Marking checks passed: every correct answer scores full marks; blank and wrong answers score 0.")


if __name__ == "__main__":
    main()
