#!/usr/bin/env python3
"""
Build a self-contained, auto-marked PEPS Cambridge quiz (Maths or Science, per assets/school_config.json) (single .html file) from a JSON spec.

Usage:
    python build_quiz.py spec.json [-o OUT.html] [--key] [--quiet]

  -o      output path (default: <file_name from spec>.html next to the spec)
  --key   also write a printable teacher answer key: <out>_ANSWER_KEY.html

The spec format is documented in references/spec-format.md.
The script validates the spec (objective codes, answer structures, marks), inlines figures
and the PEPS logo, encodes the answers, and prints a coverage summary.
Exit code 1 if there are errors (warnings don't block the build).
"""
import argparse, base64, html, json, os, random, re, string, sys
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
TEMPLATE = os.path.join(SKILL, "assets", "quiz_template.html")
LOGO = os.path.join(SKILL, "assets", "peps_logo.jpg")
import glob
REFS = sorted(glob.glob(os.path.join(SKILL, "references", "objectives-*.md")))
CONFIG_PATH = os.path.join(SKILL, "assets", "school_config.json")
with open(CONFIG_PATH, encoding="utf-8") as _f:
    CONFIG = json.load(_f)

TYPES = {"mcq", "multi", "tf", "numeric", "text", "expression", "fraction",
         "blanks", "match", "classify", "order", "shade"}

# Cambridge Attainment Rubric (PEPS): exactly five bands, by percentage of the objective's marks.
BANDS = [("Emerging", "0–20%", 20), ("Developing", "21–40%", 40), ("Meets Expectations", "41–60%", 60),
         ("Secure", "61–80%", 80), ("Exceeding", "81%+", 100)]
BAND_ALIASES = {"emerging": "Emerging", "developing": "Developing", "meets expectations": "Meets Expectations",
                "meeting expectations": "Meets Expectations", "meets": "Meets Expectations", "secure": "Secure",
                "exceeding": "Exceeding"}
GENERIC = {
    "Emerging": ("Demonstrates limited understanding of this objective.",
                 "Can attempt some of the questions but makes frequent errors.",
                 "Revisit the key ideas with your teacher and practise simple, worked examples."),
    "Developing": ("Demonstrates developing understanding of this objective.",
                   "Answers some familiar questions correctly, but accuracy is inconsistent.",
                   "Practise more questions of this type and check each step of your working."),
    "Meets Expectations": ("Demonstrates an appropriate understanding of this objective.",
                           "Usually answers familiar questions correctly, with some errors.",
                           "Apply the method accurately in a wider range of questions and contexts."),
    "Secure": ("Demonstrates secure understanding and accurate use of this objective.",
               "Answers accurately with only minor errors.",
               "Increase consistency and independence, including in unfamiliar or multi-step problems."),
    "Exceeding": ("Demonstrates confident, accurate and flexible understanding of this objective.",
                  "Consistently answers accurately, including harder questions.",
                  "Explain your reasoning and try more challenging problems that extend this objective."),
}


def band_idx(got, total):
    if not total:
        return 0
    p = 100 * got / total
    for i, (_, _, upto) in enumerate(BANDS):
        if p <= upto + 1e-9:
            return i
    return 4


def mark_range(total, bi):
    ms = [m for m in range(total + 1) if band_idx(m, total) == bi]
    if not ms:
        return f"No exact whole-{UNIT} score"
    if len(ms) == 1:
        return f"{ms[0]} {UNIT}" + ("" if ms[0] == 1 else "s")
    return f"{ms[0]}–{ms[-1]} {UNIT}s"


def build_rubric(spec, objectives):
    """Normalise spec['rubric'] to {code: {band: {descriptor, feedback, feedforward}}}; fill gaps with generic text."""
    raw = spec.get("rubric", {}) or {}
    out, missing = {}, []
    for o in objectives:
        code = o["code"]
        if o["marks"] == 0 and not spec.get("count_secondary_objectives"):
            continue   # secondary tag only: no rubric row
        given = {}
        for k, v in (raw.get(code) or {}).items():
            key = BAND_ALIASES.get(str(k).strip().lower())
            if not key:
                err(f"rubric {code}: unknown band '{k}' (use Emerging, Developing, Meets Expectations, Secure, Exceeding)")
                continue
            given[key] = v
        out[code] = {}
        for band, _, _ in BANDS:
            g = given.get(band) or {}
            d, f, ff = GENERIC[band]
            entry = {"descriptor": g.get("descriptor") or d, "feedback": g.get("feedback") or f, "feedforward": g.get("feedforward") or ff}
            if not (g.get("descriptor") and g.get("feedback") and g.get("feedforward")):
                missing.append(f"{code}/{band}")
            out[code][band] = entry
    if missing:
        warn(f"rubric text missing for {len(missing)} objective/band cells — generic wording used "
             f"({', '.join(missing[:5])}{'…' if len(missing) > 5 else ''}). Write objective-specific text in spec['rubric'].")
    return out


errors, warnings = [], []
UNIT = "mark"      # "point" on worksheets / practice sheets
DOC = "Quiz"
def err(m): errors.append(m)
def warn(m): warnings.append(m)


def load_objectives():
    objs = {}
    for p in REFS:
        with open(p, encoding="utf-8") as f:
            for line in f:
                m = re.match(r"^- (\d[A-Z][A-Za-z]{1,4}\.\d\d|TWM\.\d\d) (.+)$", line.strip())
                if m:
                    objs[m.group(1)] = m.group(2).strip()
    return objs


def data_uri(path):
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}.get(ext)
    with open(path, "rb") as f:
        b = base64.b64encode(f.read()).decode()
    return f"data:{mime};base64,{b}"


def resolve_figure(fig, base, where):
    """Return inline HTML for a figure given inline SVG/HTML, or a path to .svg/.png/.jpg."""
    if not fig:
        return None
    if isinstance(fig, dict):  # {"src": path, "width": 300, "alt": ""}
        src, width, alt = fig.get("src"), fig.get("width"), fig.get("alt", "")
    else:
        src, width, alt = fig, None, ""
    s = str(src).strip()
    if s.startswith("<"):
        out = s
    else:
        path = s if os.path.isabs(s) else os.path.join(base, s)
        if not os.path.exists(path):
            err(f"{where}: figure file not found: {s}")
            return None
        if path.lower().endswith(".svg"):
            with open(path, encoding="utf-8") as f:
                out = f.read()
            out = re.sub(r"<\?xml[^>]*\?>", "", out)
            out = re.sub(r"<!DOCTYPE[^>]*>", "", out).strip()
        else:
            w = f' width="{int(width)}"' if width else ""
            return f'<img src="{data_uri(path)}" alt="{html.escape(alt)}"{w}>'
    if width and out.startswith("<svg"):
        out = re.sub(r"<svg\b", f'<svg style="width:{int(width)}px;max-width:100%"', out, count=1)
    return out


def parse_num(x):
    if isinstance(x, (int, float)):
        return float(x)
    s = str(x).strip().replace(",", "")
    m = re.match(r"^(-?)(\d+)\s+(\d+)\s*/\s*(\d+)$", s)
    if m:
        v = int(m.group(2)) + Fraction(int(m.group(3)), int(m.group(4)))
        return float(-v if m.group(1) else v)
    m = re.match(r"^(-?\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)$", s)
    if m:
        return float(m.group(1)) / float(m.group(2))
    if s.endswith("%"):
        return float(s[:-1]) / 100
    return float(s)


def check_question(q, i, objs, stage, base, allow_other):
    where = f"Q{i+1} ({q.get('id', '?')})"
    t = q.get("type")
    if t not in TYPES:
        err(f"{where}: unknown type '{t}'. Use one of: {', '.join(sorted(TYPES))}")
        return
    q.setdefault("id", f"q{i+1}")
    # objective
    code = q.get("objective")
    if not code:
        err(f"{where}: missing 'objective' (a Cambridge learning objective code, e.g. {stage}Nf.03)")
    elif code not in objs:
        err(f"{where}: objective '{code}' is not in the Cambridge framework reference")
    else:
        q["objective_text"] = objs[code]
        if code[0].isdigit() and int(code[0]) != stage and not allow_other:
            warn(f"{where}: objective {code} is from Stage {code[0]} but the quiz is Stage {stage} (set allow_other_stages to silence)")
    for c in q.get("also", []):
        if c not in objs:
            err(f"{where}: secondary objective '{c}' is not in the framework reference")
    if t != "blanks" and not str(q.get("prompt", "")).strip():
        err(f"{where}: missing 'prompt'")
    if not q.get("explanation"):
        warn(f"{where}: no 'explanation' — students see only the right answer after marking")

    # figures
    if q.get("figure"):
        q["figure"] = resolve_figure(q["figure"], base, where)
    if "options" in q and isinstance(q["options"], list):
        for k, o in enumerate(q["options"]):
            if isinstance(o, dict) and o.get("figure"):
                o["figure"] = resolve_figure(o["figure"], base, f"{where} option {k+1}")

    # type-specific checks + default marks
    def need(field):
        if field not in q:
            err(f"{where}: type '{t}' needs '{field}'")
            return False
        return True

    if t in ("mcq", "tf"):
        if t == "tf":
            q.setdefault("options", ["True", "False"])
            if isinstance(q.get("answer"), bool):
                q["answer"] = 0 if q["answer"] else 1
        if need("options") and need("answer"):
            if not isinstance(q["answer"], int) or not (0 <= q["answer"] < len(q["options"])):
                err(f"{where}: 'answer' must be the 0-based index of the correct option")
            texts = [json.dumps(o, sort_keys=True) for o in q["options"]]
            if len(set(texts)) != len(texts):
                err(f"{where}: duplicate options")
        q.setdefault("marks", 1)
    elif t == "multi":
        if need("options") and need("answer"):
            if not isinstance(q["answer"], list) or not q["answer"] or any(not isinstance(a, int) or a >= len(q["options"]) for a in q["answer"]):
                err(f"{where}: 'answer' must be a list of 0-based option indices")
        q.setdefault("marks", 1)
    elif t == "numeric":
        if need("answer"):
            try:
                parse_num(q["answer"])
                for a in q.get("accept", []):
                    parse_num(a)
            except Exception:
                err(f"{where}: numeric 'answer'/'accept' must be numbers (or strings like '3/4', '1 1/2', '25%')")
        q.setdefault("marks", 1)
    elif t in ("text",):
        if need("answer") and not str(q["answer"]).strip():
            err(f"{where}: empty answer")
        q.setdefault("marks", 1)
    elif t == "expression":
        need("answer")
        if q.get("check", "equivalent") not in ("equivalent", "exact"):
            err(f"{where}: 'check' must be 'equivalent' or 'exact'")
        if q.get("require") not in (None, "simplified", "expanded", "factorised"):
            err(f"{where}: 'require' must be simplified, expanded or factorised")
        q.setdefault("marks", 1)
    elif t == "fraction":
        if need("answer"):
            if not re.match(r"^-?\d+(\s+\d+)?\s*/\s*\d+$|^-?\d+$", str(q["answer"]).strip()):
                err(f"{where}: fraction 'answer' must look like '3/4' or '1 3/4'")
        if q.get("input") not in (None, "fraction", "mixed"):
            err(f"{where}: fraction 'input' must be 'fraction' or 'mixed'")
        q.setdefault("marks", 1)
    elif t == "blanks":
        if need("text") and need("blanks"):
            n = sorted(set(int(x) for x in re.findall(r"\[\[(\d+)\]\]", q["text"])))
            if n != list(range(1, len(q["blanks"]) + 1)):
                err(f"{where}: text has blanks {n} but {len(q['blanks'])} blank definitions")
            for k, b in enumerate(q["blanks"]):
                if "answer" not in b:
                    err(f"{where}: blank {k+1} has no answer")
                elif b.get("options") and not isinstance(b["answer"], int):
                    err(f"{where}: blank {k+1} has options, so its answer must be the option index")
        q.setdefault("marks", len(q.get("blanks", [])) or 1)
    elif t == "match":
        if need("left") and need("right") and need("answer"):
            if len(q["answer"]) != len(q["left"]) or any(a >= len(q["right"]) for a in q["answer"]):
                err(f"{where}: match 'answer' must give a right-hand index for every left item")
        q.setdefault("marks", len(q.get("left", [])) or 1)
    elif t == "classify":
        if need("categories") and need("items"):
            for k, it in enumerate(q["items"]):
                c = it.get("category") if isinstance(it, dict) else (q.get("answer") or [None] * 999)[k]
                if not isinstance(c, int) or c >= len(q["categories"]):
                    err(f"{where}: item {k+1} needs a valid category index")
        q.setdefault("marks", len(q.get("items", [])) or 1)
    elif t == "order":
        if need("items") and len(q["items"]) < 3:
            warn(f"{where}: ordering with fewer than 3 items is guessable")
        q.setdefault("marks", 1)
    elif t == "shade":
        if need("answer"):
            parts = q.get("parts") or (q.get("rows", 1) * q.get("cols", 0))
            q["parts"] = q.get("parts") or parts
            if isinstance(q["answer"], str) and "/" in q["answer"]:
                fr = Fraction(q["answer"].replace(" ", ""))
                shaded = fr * parts
                if shaded.denominator != 1:
                    err(f"{where}: {q['answer']} of {parts} parts is not a whole number of parts")
                q["answer"] = int(shaded)
            if not (0 < q["answer"] <= parts):
                err(f"{where}: shade answer must be between 1 and {parts}")
        q.setdefault("shape", "bar")
        q.setdefault("marks", 1)

    if not isinstance(q.get("marks"), int) or q["marks"] < 1:
        err(f"{where}: 'marks' must be a whole number ≥ 1")


def encode(obj, key):
    raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    kb = key.encode()
    out = bytes(b ^ kb[i % len(kb)] for i, b in enumerate(raw))
    return base64.b64encode(out).decode()


def slug(s):
    return re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_")


def plain(s):
    s = re.sub(r"\{\{f:([^}]+)\}\}", r"\1", str(s))
    s = s.replace("^{2}", "²").replace("^{3}", "³")
    s = re.sub(r"\^\{([^}]*)\}", r"^\1", s)
    s = re.sub(r"\[\[(\d+)\]\]", r"___(\1)", s)
    s = re.sub(r"<br\s*/?>", " / ", s)
    s = re.sub(r"<[^>]+>", "", s)
    return html.unescape(s.replace("**", ""))


def answer_text(q):
    t = q["type"]
    if t in ("mcq", "tf"):
        o = q["options"][q["answer"]]
        return f"{chr(65 + q['answer'])}  ({plain(o.get('text') or 'picture' if isinstance(o, dict) else o)})"
    if t == "multi":
        return ", ".join(f"{chr(65 + a)}" for a in q["answer"])
    if t in ("numeric", "text", "expression", "fraction"):
        a = q.get("answer_display", q["answer"])
        extra = ""
        if q.get("accept"):
            extra = f"  (also accept: {', '.join(map(str, q['accept']))})"
        if t == "numeric" and q.get("tolerance"):
            extra += f"  (± {q['tolerance']})"
        if t == "fraction" and q.get("simplest"):
            extra += "  (simplest form required)"
        if t == "expression" and q.get("require"):
            extra += f"  ({q['require']} form required)"
        return f"{q.get('prefix', '')} {a} {q.get('suffix', '')}".strip() + extra
    if t == "blanks":
        return " | ".join(f"({k+1}) " + (plain(b['options'][b['answer']]) if b.get('options') else str(b.get('answer_display', b['answer']))) for k, b in enumerate(q["blanks"]))
    if t == "match":
        return "; ".join(f"{plain(l)} → {plain(q['right'][a])}" for l, a in zip(q["left"], q["answer"]))
    if t == "classify":
        return "; ".join(f"{plain(it['text'] if isinstance(it, dict) else it)} → {plain(q['categories'][it['category'] if isinstance(it, dict) else q['answer'][k]])}" for k, it in enumerate(q["items"]))
    if t == "order":
        return " , ".join(plain(x) for x in q["items"])
    if t == "shade":
        return f"{q['answer']} of {q['parts']} parts shaded"
    return ""


def rubric_html(qs, objectives, rubric):
    if not rubric:
        return ""
    rows = []
    for o in objectives:
        if o["code"] not in rubric:
            continue
        nums = [i + 1 for i, q in enumerate(qs) if q["objective"] == o["code"]]
        rng, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            rng.append(f"Q{nums[i]}–{nums[j]}" if j > i else f"Q{nums[i]}")
            i = j + 1
        cells = "".join(
            f"<td><b>Attainment:</b> {b}<br><b>{UNIT.capitalize()} Band:</b> {mark_range(o['marks'], k)} ({r})<br><br>"
            f"<b>Achievement Descriptor:</b> {html.escape(plain(rubric[o['code']][b]['descriptor']))}<br><br>"
            f"<b>Feedback:</b> {html.escape(plain(rubric[o['code']][b]['feedback']))}<br><br>"
            f"<b>Feedforward:</b> {html.escape(plain(rubric[o['code']][b]['feedforward']))}</td>"
            for k, (b, r, _) in enumerate(BANDS))
        rows.append(f"<tr><td><b>Objective:</b> {o['code']} – {html.escape(o['text'])}<br><br><b>Questions:</b> {', '.join(rng)} (question order as set)"
                    f"<br><b>Total {UNIT.capitalize()}s:</b> {o['marks']}</td>{cells}</tr>")
    head = "".join(f"<th>{b}<br><span style='font-weight:400'>({r})</span></th>" for b, r, _ in BANDS)
    return (f"<h2 style='page-break-before:always'>Cambridge Attainment Rubric</h2><p><b>Cambridge Attainment Bands:</b> "
            f"{' | '.join(f'{b} ({r})' for b, r, _ in BANDS)}</p>"
            f"<table class='rub'><tr><th>Objective &amp; Assessment Mapping</th>{head}</tr>{''.join(rows)}</table>")


def write_key(spec, qs, objectives, path, rubric=None):
    rows = []
    for i, q in enumerate(qs):
        rows.append(f"<tr><td>{i+1}{' ★' if q.get('challenge') else ''}</td><td><code>{q['objective']}</code></td><td>{q['type']}</td><td>{q['marks']}</td>"
                    f"<td>{html.escape(plain(q.get('prompt') or q.get('text', '')))[:220]}</td><td><b>{html.escape(answer_text(q))}</b>"
                    f"{('<br><small>' + html.escape(plain(q['explanation'])) + '</small>') if q.get('explanation') else ''}</td></tr>")
    cov = "".join(f"<tr><td><code>{o['code']}</code></td><td>{html.escape(o['text'])}</td><td>{o['marks']}</td></tr>" for o in objectives)
    total = sum(q["marks"] for q in qs)
    passages_html = "".join(
        f"<h2>Text {html.escape(pid)}{(': ' + html.escape(plain(P.get('title', '')))) if P.get('title') else ''}</h2>"
        f"<div style='border:1px solid #bbb;border-left:5px solid #f2c230;padding:8px 12px;white-space:pre-wrap'>{html.escape(plain(P.get('text', '')))}</div>"
        for pid, P in (spec.get("passages") or {}).items())
    doc = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Answer key – {html.escape(spec['title'])}</title>
<style>body{{font:13px/1.45 'Segoe UI',Arial,sans-serif;margin:24px;color:#1d1b2c}}h1{{color:#3b2a86;margin:0}}
.hd{{display:flex;gap:14px;align-items:center;border-bottom:4px solid #f2c230;padding-bottom:10px;margin-bottom:14px}}
table{{border-collapse:collapse;width:100%;margin:10px 0 22px}}th,td{{border:1px solid #bbb;padding:6px 8px;vertical-align:top;text-align:left}}
th{{background:#efecfb}}.rub{{font-size:10px}}.rub th{{text-align:center}}code{{color:#3b2a86}}.conf{{color:#b3261e;font-weight:700}}</style></head><body>
<div class="hd"><img src="{data_uri(LOGO)}" width="60"><div><div class="conf">TEACHER COPY – CONFIDENTIAL</div><h1>Answer key: {html.escape(spec['title'])}</h1>
<div>{CONFIG['subject']} · Year {spec['year']} (Stage {spec['stage']}) · {DOC} · {total} {UNIT}s · {len(qs)} questions · {spec.get('duration_minutes') or 'no'} minute time limit</div></div></div>
{passages_html}<h2>Answers</h2><table><tr><th>#</th><th>Objective</th><th>Type</th><th>{UNIT.capitalize()}s</th><th>Question</th><th>Answer</th></tr>{''.join(rows)}</table>
<h2>Objective coverage</h2><table><tr><th>Code</th><th>Learning objective</th><th>{UNIT.capitalize()}s</th></tr>{cov}</table>
{rubric_html(qs, objectives, rubric or {})}</body></html>"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(doc)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("spec")
    ap.add_argument("-o", "--out")
    ap.add_argument("--key", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--preview", action="store_true", help="build without results_url (for check_quiz.py and teacher previews)")
    a = ap.parse_args()

    base = os.path.dirname(os.path.abspath(a.spec))
    with open(a.spec, encoding="utf-8") as f:
        spec = json.load(f)
    objs = load_objectives()

    for f in ("title", "year", "questions"):
        if f not in spec:
            err(f"spec is missing '{f}'")
    if errors:
        report_and_exit()
    year = int(spec["year"])
    if not 1 <= year <= 9:
        err("year must be 1–9 (Cambridge Primary 1–6, Lower Secondary 7–9)")
    stage = int(spec.get("stage", year))
    spec["stage"] = stage
    programme = CONFIG["programme_primary"] if stage <= 6 else CONFIG["programme_lower_secondary"]
    subject, short = CONFIG["subject"], CONFIG["subject_short"]
    kind = re.sub(r"[_\-]+", " ", str(spec.get("type", "quiz")).strip().lower())
    if kind not in ("quiz", "worksheet", "practice sheet"):
        err("'type' must be quiz, worksheet or practice sheet")
        report_and_exit()
    worksheet = kind != "quiz"
    label = {"quiz": "Quiz", "worksheet": "Worksheet", "practice sheet": "Practice Sheet"}[kind]
    unit = "point" if worksheet else "mark"
    global UNIT, DOC
    UNIT = unit
    qn = spec.get("quiz_number")
    if worksheet:
        qn = None
    elif qn in (None, ""):
        err("spec is missing 'quiz_number' — ask the teacher which quiz number this is (e.g. 3)")
        report_and_exit()
    else:
        try:
            qn = int(qn)
            assert 1 <= qn <= 99
        except Exception:
            err("'quiz_number' must be a whole number from 1 to 99")
            report_and_exit()
    import datetime
    ws_date = str(spec.get("date") or datetime.date.today().isoformat()) if worksheet else ""
    DOC = f"Quiz {qn}" if not worksheet else f"{label} · {ws_date}"
    if worksheet and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", ws_date):
        err("'date' must look like 2026-09-28")

    qs = list(spec["questions"])
    if not qs:
        err("no questions")
    remember = spec.get("remember")
    challenge = list(spec.get("challenge") or [])
    if worksheet:
        if not remember or not (remember.get("key_points") or remember.get("text")):
            err(f"a {label.lower()} needs a 'remember' box: {{\"key_points\": [...], \"example\": \"...\"}}")
        if not challenge:
            err(f"a {label.lower()} needs 'challenge' questions (2–3 harder questions)")
    for k, q in enumerate(challenge):
        q["challenge"] = True
        if k == 0:
            q["challenge_start"] = True
    qs += challenge
    spec["questions"] = qs
    for q in qs:
        if "points" in q and "marks" not in q:
            q["marks"] = q.pop("points")
    ids = [q.get("id") for q in qs if q.get("id")]
    if len(ids) != len(set(ids)):
        err("question ids must be unique")
    passages = spec.get("passages") or {}
    if not isinstance(passages, dict):
        err("'passages' must be an object: {\"P1\": {\"title\": ..., \"text\": ...}}")
        passages = {}
    for pid, P in passages.items():
        if not isinstance(P, dict) or not str(P.get("text", "")).strip():
            err(f"passage '{pid}' needs 'text'")
        elif P.get("figure"):
            P["figure"] = resolve_figure(P["figure"], base, f"passage {pid}")
    for i, q in enumerate(qs):
        check_question(q, i, objs, stage, base, spec.get("allow_other_stages", False))
        if q.get("passage") and q["passage"] not in passages:
            err(f"Q{i+1}: passage '{q['passage']}' is not defined in 'passages'")

    # MCQ key spread
    keys = [q["answer"] for q in qs if q.get("type") == "mcq" and isinstance(q.get("answer"), int) and not q.get("shuffle")]
    if len(keys) >= 6:
        counts = {chr(65 + k): keys.count(k) for k in range(max(keys) + 1)}
        if max(counts.values()) > 0.45 * len(keys):
            warn(f"MCQ answer keys are unbalanced: {counts}")

    if errors:
        report_and_exit()

    # objectives covered (main + secondary), in code order
    used = {}
    for q in qs:
        for k, c in enumerate([q["objective"]] + q.get("also", [])):
            if c not in used:
                used[c] = {"code": c, "text": objs[c], "marks": 0}
            if k == 0:
                used[c]["marks"] += q["marks"]
    def sort_key(c):
        return (1, c) if c.startswith("TWM") else (0, c)
    objectives = [used[c] for c in sorted(used, key=sort_key)]

    rubric = build_rubric(spec, objectives)
    if errors:
        report_and_exit()
    settings = {
        "title": spec["title"], "year": year, "stage": stage, "programme": "Cambridge " + programme,
        "teacher": spec.get("teacher", ""), "intro": spec.get("intro", ""),
        "instructions": spec.get("instructions", []),
        "duration": spec.get("duration_minutes", 0) or 0,
        "mode": spec.get("mode", "practice" if worksheet else "test"),
        "layout": spec.get("layout", "paged"),
        "shuffle_questions": spec.get("shuffle_questions", False),
        "show_objectives": spec.get("show_objectives", True),
        "show_objectives_on_start": spec.get("show_objectives_on_start", True),
        "show_answers": spec.get("show_answers", True),
        "allow_retry": spec.get("allow_retry", spec.get("mode", "practice" if worksheet else "test") == "practice"),
        "read_aloud": spec.get("read_aloud", stage <= 3),
        "calculator": spec.get("calculator"),
        "classes": spec.get("classes", []),
        "results_url": "" if a.preview else spec.get("results_url", CONFIG.get("results_url", "")),
        "subject": subject, "subject_short": short, "quiz_number": qn,
        "kind": kind, "doc_label": f"Quiz {qn}" if not worksheet else label, "doc_word": label.lower(), "unit": unit,
        "ws_date": ws_date, "challenge_note": spec.get("challenge_note", "Try these harder questions."), "remember": ({**remember, "figure_html": resolve_figure(remember.get("figure"), base, "remember")} if remember else None),
        "collect_hint": spec.get("collect_hint", ""),
        "count_secondary": spec.get("count_secondary_objectives", False),
        "sections": spec.get("sections", CONFIG.get("sections", ["A", "B", "C", "D"])),
        "band_messages": spec.get("band_messages", {}),
        "quiz_id": spec.get("quiz_id") or (slug(f"{short}_Y{year}_Q{qn:02d}_{spec['title']}") if not worksheet
                                           else slug(f"{short}_Y{year}_WS_{ws_date}_{spec['title']}")),
    }
    payload = {"settings": settings, "objectives": [{"code": o["code"], "text": o["text"]} for o in objectives], "questions": qs, "rubric": rubric,
               "passages": passages}
    key = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(24))

    with open(TEMPLATE, encoding="utf-8") as f:
        page = f.read()
    page = (page.replace("__TITLE__", html.escape(spec["title"]))
                .replace("__LOGO__", data_uri(LOGO))
                .replace("__PROGRAMME__", programme)
                .replace("__SUBJECT__", html.escape(subject))
                .replace("__PAYLOAD__", encode(payload, key))
                .replace("__KEY__", key))

    topic = slug(spec["title"])
    if worksheet:
        topic_ws = slug(re.sub(r"(?i)\b(worksheet|practice sheet)\b", "", spec["title"]))
        default_name = f"PEPS_Y{year}_{short}_{topic_ws}_{label.replace(' ', '_')}.html"
    else:
        default_name = f"PEPS_Y{year}_{short}_Q{qn:02d}_{topic}" + ("" if re.search(r"(Quiz|Test)$", topic, re.I) else "_Quiz") + ".html"
    out = a.out or os.path.join(base, spec.get("file_name") or default_name)
    with open(out, "w", encoding="utf-8") as f:
        f.write(page)
    key_path = None
    if a.key:
        key_path = re.sub(r"\.html?$", "", out) + "_ANSWER_KEY.html"
        write_key(spec, qs, objectives, key_path, rubric)

    total = sum(q["marks"] for q in qs)
    if not a.quiet:
        print(f"✓ Built {out}  ({os.path.getsize(out)//1024} KB)")
        if key_path:
            print(f"✓ Answer key {key_path}")
        where = f"Quiz {qn}" if not worksheet else f"{label} {ws_date} (Drive folder: Worksheets / {ws_date} – {spec['title']})"
        print(f"  {subject} · {where} · results {'→ school Drive' if settings['results_url'] else 'NOT saved (preview mode: no results_url)'}")
        print(f"  Year {year} / Stage {stage} · {len(qs)} questions ({len(challenge)} challenge) · {total} {unit}s · mode={settings['mode']} · time={settings['duration'] or 'none'}")
        types = {}
        for q in qs:
            types[q["type"]] = types.get(q["type"], 0) + 1
        print("  Types: " + ", ".join(f"{k}×{v}" for k, v in sorted(types.items())))
        print(f"  Objective coverage ({unit}s):")
        for o in objectives:
            print(f"    {o['code']:<8} {o['marks']:>3}  {o['text'][:78]}")
    report_and_exit(ok_exit=True)


def report_and_exit(ok_exit=False):
    for w in warnings:
        print("  ⚠ " + w)
    for e in errors:
        print("  ✗ " + e)
    if errors:
        print(f"✗ {len(errors)} error(s) — fix the spec and rebuild.")
        sys.exit(1)
    if ok_exit:
        sys.exit(0)


if __name__ == "__main__":
    main()
