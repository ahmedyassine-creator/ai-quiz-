"""
SVG figure helpers for PEPS Cambridge Maths quizzes.

Every function returns an SVG *string* that can be put straight into a question's "figure"
(or an option's "figure") in the quiz spec, or saved with save(svg, "fig1.svg").

    import sys; sys.path.insert(0, "<skill_dir>/scripts")
    from figures import *
    clock(3, 30)                                   # analogue clock showing 3:30
    number_line(0, 20, 1, labels="every:5", arrow_at=13)
    bar_chart(["Red","Blue","Green"], [5,8,3], y_step=1, y_label="Number of children")
    pictogram([("Mon",6),("Tue",3)], key_value=2)
    fraction_shape("circle", 8, 3)                 # circle in 8 parts, 3 shaded
    polygon([(0,0),(6,0),(6,4),(0,4)], side_labels=["6 cm","4 cm","",""])
    grid_shape(cells, rows=6, cols=8)              # shape drawn on squared paper
    coordinate_grid(-5,5,-5,5, points={"A":(2,3)}, polygons=[[(1,1),(3,1),(3,2)]])
    angle_fig(125, label="x")                      # two rays with an arc
    base10(2, 3, 5)                                # 2 hundreds, 3 tens, 5 ones
    dot_array(3, 4)
    shape2d("hexagon"), shape3d("cylinder")
    measuring_scale("jug", 1000, 200, 50, 650, "ml")
    venn(["Even","Multiples of 3"], a_only=[2,4], both=[6], b_only=[3,9], outside=[1,5])
    pie_chart(["Walk","Bus","Car"], [10,6,4])
    line_graph(["Mon","Tue","Wed"], [12,15,9], y_step=5)
    tally(7)

House style: black lines, one purple fill (#cfc6f3), Arial, labels ≥ 14 px, no decoration.
Always LOOK at a figure (save it, open it with the Read tool, or check the rendered quiz)
before using it: check values match the question and labels don't overlap.
"""
import math
import itertools, random
_ids = itertools.count()
_pre = "f%04x" % random.randrange(65536)

def _uid(p):
    """Unique id so several inline SVGs on one page never share clipPath/marker ids."""
    return f"{_pre}{p}{next(_ids)}"

INK = "#1d1b2c"
FILL = "#cfc6f3"
ACCENT = "#5a45b8"
GOLD = "#f2c230"
FONT = "font-family:Arial,Helvetica,sans-serif"


def _svg(w, h, body, label="figure"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w:.0f} {h:.0f}" width="{w:.0f}" height="{h:.0f}" '
            f'role="img" aria-label="{label}" style="{FONT}">{body}</svg>')


def _t(x, y, s, size=15, anchor="middle", weight="normal", fill=INK, extra=""):
    s = str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" text-anchor="{anchor}" font-weight="{weight}" fill="{fill}" {extra}>{s}</text>'


def _nice(v):
    return int(v) if float(v).is_integer() else round(v, 4)


def save(svg, path):
    with open(path, "w", encoding="utf-8") as f:
        f.write(svg)
    return path


# ---------------------------------------------------------------- clock
def clock(h, m, size=200, numbers=True, minute_ticks=True, label=None):
    """Analogue clock. Hour hand moves proportionally with minutes (as on a real clock)."""
    c = size / 2
    r = c - 6
    b = f'<circle cx="{c}" cy="{c}" r="{r}" fill="#fff" stroke="{INK}" stroke-width="4"/>'
    for i in range(60):
        a = math.radians(i * 6 - 90)
        long_ = i % 5 == 0
        if not long_ and not minute_ticks:
            continue
        r1 = r - (12 if long_ else 6)
        b += (f'<line x1="{c + r1 * math.cos(a):.1f}" y1="{c + r1 * math.sin(a):.1f}" x2="{c + (r - 2) * math.cos(a):.1f}" '
              f'y2="{c + (r - 2) * math.sin(a):.1f}" stroke="{INK}" stroke-width="{3 if long_ else 1.2}"/>')
    if numbers:
        for n in range(1, 13):
            a = math.radians(n * 30 - 90)
            b += _t(c + (r - 28) * math.cos(a), c + (r - 28) * math.sin(a) + 6, n, size=max(14, size // 11), weight="bold")
    ha = math.radians((h % 12 + m / 60) * 30 - 90)
    ma = math.radians(m * 6 - 90)
    b += f'<line x1="{c}" y1="{c}" x2="{c + r * 0.42 * math.cos(ha):.1f}" y2="{c + r * 0.42 * math.sin(ha):.1f}" stroke="{INK}" stroke-width="7" stroke-linecap="round"/>'
    b += f'<line x1="{c}" y1="{c}" x2="{c + r * 0.62 * math.cos(ma):.1f}" y2="{c + r * 0.62 * math.sin(ma):.1f}" stroke="{ACCENT}" stroke-width="4" stroke-linecap="round"/>'
    b += f'<circle cx="{c}" cy="{c}" r="6" fill="{INK}"/>'
    return _svg(size, size, b, label or "analogue clock")


# ---------------------------------------------------------------- number line
def number_line(start, end, step, labels="all", arrow_at=None, points=None, width=560, minor=None,
                box_at=None, jumps=None, label=None):
    """
    labels: "all" | "ends" | "every:N" (label multiples of N) | list of values to label | dict {value: text}
    arrow_at: value (or list) marked with a downward arrow (the value to read)
    points: dict {value: "A"} dots with letters above
    minor: minor step (small ticks, no labels)
    box_at: list of values where an empty box replaces the label (missing numbers)
    jumps: list of (from, to, "text") arcs drawn above the line
    """
    pad = 30
    mid_ = _uid("ah")
    H = 110 if jumps else 80
    y = H - 40
    span = end - start
    X = lambda v: pad + (v - start) / span * (width - 2 * pad)
    b = f'<line x1="{pad - 12}" y1="{y}" x2="{width - pad + 12}" y2="{y}" stroke="{INK}" stroke-width="2"/>'
    if minor:
        n = round(span / minor)
        for i in range(n + 1):
            v = start + i * minor
            b += f'<line x1="{X(v):.1f}" y1="{y - 5}" x2="{X(v):.1f}" y2="{y + 5}" stroke="{INK}" stroke-width="1"/>'
    n = round(span / step)
    box_at = set(box_at or [])
    for i in range(n + 1):
        v = start + i * step
        v = round(v, 6)
        b += f'<line x1="{X(v):.1f}" y1="{y - 9}" x2="{X(v):.1f}" y2="{y + 9}" stroke="{INK}" stroke-width="2"/>'
        show = None
        if isinstance(labels, dict):
            show = labels.get(v)
        elif isinstance(labels, (list, tuple, set)):
            show = _nice(v) if v in labels else None
        elif labels == "all":
            show = _nice(v)
        elif labels == "ends":
            show = _nice(v) if i in (0, n) else None
        elif isinstance(labels, str) and labels.startswith("every:"):
            k = float(labels.split(":")[1])
            show = _nice(v) if abs(v / k - round(v / k)) < 1e-9 else None
        if v in box_at:
            b += f'<rect x="{X(v) - 16:.1f}" y="{y + 14}" width="32" height="24" fill="#fff" stroke="{INK}" stroke-width="1.5"/>'
        elif show is not None:
            b += _t(X(v), y + 30, show)
    for v in ([arrow_at] if isinstance(arrow_at, (int, float)) else (arrow_at or [])):
        b += f'<path d="M{X(v):.1f},{y - 12} l-7,-14 h14 z" fill="{ACCENT}"/>'
    for v, name in (points or {}).items():
        b += f'<circle cx="{X(v):.1f}" cy="{y}" r="5" fill="{ACCENT}"/>' + _t(X(v), y - 16, name, weight="bold")
    for (a, c, txt) in (jumps or []):
        xa, xc = X(a), X(c)
        mid = (xa + xc) / 2
        b += f'<path d="M{xa:.1f},{y - 4} Q{mid:.1f},{y - 60} {xc:.1f},{y - 4}" fill="none" stroke="{ACCENT}" stroke-width="2" marker-end="url(#{mid_})"/>'
        b += _t(mid, y - 38, txt, size=13, fill=ACCENT)
    defs = f'<defs><marker id="{mid_}" markerUnits="userSpaceOnUse" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="{ACCENT}"/></marker></defs>' if jumps else ""
    return _svg(width, H, defs + b, label or "number line")


# ---------------------------------------------------------------- bar chart
def bar_chart(labels, values, y_step=1, y_max=None, y_label="", x_label="", title="", width=520, height=320,
              gridlines=True, horizontal=False, label=None):
    """Vertical bar chart on a gridded scale. Values should land on or between gridlines readable by pupils."""
    y_max = y_max or (math.ceil(max(values) / y_step) * y_step)
    L, R, T, B = 64, 16, 34 if title else 14, 58 if x_label else 40
    pw, ph = width - L - R, height - T - B
    Y = lambda v: T + ph - v / y_max * ph
    b = _t(width / 2, 22, title, size=16, weight="bold") if title else ""
    k = 0
    while k * y_step <= y_max + 1e-9:
        v = k * y_step
        if gridlines:
            b += f'<line x1="{L}" y1="{Y(v):.1f}" x2="{L + pw}" y2="{Y(v):.1f}" stroke="#bbb" stroke-width="1"/>'
        b += _t(L - 8, Y(v) + 5, _nice(v), size=13, anchor="end")
        k += 1
    n = len(values)
    slot = pw / n
    bw = slot * 0.55
    for i, (lab, v) in enumerate(zip(labels, values)):
        x = L + slot * i + (slot - bw) / 2
        b += f'<rect x="{x:.1f}" y="{Y(v):.1f}" width="{bw:.1f}" height="{Y(0) - Y(v):.1f}" fill="{FILL}" stroke="{INK}" stroke-width="1.5"/>'
        b += _t(x + bw / 2, T + ph + 20, lab, size=13)
    b += f'<line x1="{L}" y1="{T}" x2="{L}" y2="{T + ph}" stroke="{INK}" stroke-width="2"/><line x1="{L}" y1="{T + ph}" x2="{L + pw}" y2="{T + ph}" stroke="{INK}" stroke-width="2"/>'
    if y_label:
        b += _t(16, T + ph / 2, y_label, size=13, extra=f'transform="rotate(-90 16 {T + ph / 2})"')
    if x_label:
        b += _t(L + pw / 2, height - 10, x_label, size=13)
    return _svg(width, height, b, label or "bar chart")


# ---------------------------------------------------------------- pictogram
def pictogram(rows, key_value=1, symbol="circle", key_text=None, width=520, label=None):
    """rows: [(label, value)]. value/key_value may end in .5 (half symbol) or .25/.75 for quarters."""
    size, gap = 28, 6
    L = 110
    H = 20 + len(rows) * (size + 14) + 50
    b = ""

    def sym(x, y, frac=1.0):
        cid = _uid("c")
        clip = f'<clipPath id="{cid}"><rect x="{x}" y="{y}" width="{size * frac}" height="{size}"/></clipPath>'
        if symbol == "square":
            shape = f'<rect x="{x + 2}" y="{y + 2}" width="{size - 4}" height="{size - 4}" fill="{ACCENT}"/>'
        else:
            shape = f'<circle cx="{x + size / 2}" cy="{y + size / 2}" r="{size / 2 - 2}" fill="{ACCENT}"/>'
        return clip + f'<g clip-path="url(#{cid})">{shape}</g>'

    for i, (lab, v) in enumerate(rows):
        y = 16 + i * (size + 14)
        b += _t(L - 12, y + size / 2 + 5, lab, anchor="end")
        b += f'<line x1="{L - 4}" y1="{y - 6}" x2="{width - 10}" y2="{y - 6}" stroke="#ddd"/>'
        units = v / key_value
        full = int(units + 1e-9)
        for k in range(full):
            b += sym(L + k * (size + gap), y)
        rem = units - full
        if rem > 1e-6:
            b += sym(L + full * (size + gap), y, rem)
    ky = H - 26
    b += sym(L, ky - size + 8) + _t(L + size + 10, ky, key_text or f"= {key_value}", anchor="start")
    b += _t(L - 12, ky, "Key:", anchor="end", weight="bold")
    return _svg(width, H, b, label or "pictogram")


# ---------------------------------------------------------------- fraction shapes
def fraction_shape(kind, parts, shaded, size=200, rows=None, label=None):
    """kind: 'circle' | 'bar' | 'rect' (rows×cols grid; give rows). shaded: count (first n parts) or list of indices."""
    idx = set(range(shaded)) if isinstance(shaded, int) else set(shaded)
    b = ""
    if kind == "circle":
        c, R = size / 2, size / 2 - 4
        for i in range(parts):
            a0 = -math.pi / 2 + 2 * math.pi * i / parts
            a1 = -math.pi / 2 + 2 * math.pi * (i + 1) / parts
            f = FILL if i in idx else "#fff"
            if parts == 1:
                b += f'<circle cx="{c}" cy="{c}" r="{R}" fill="{f}" stroke="{INK}" stroke-width="2"/>'
            else:
                big = 1 if a1 - a0 > math.pi else 0
                b += (f'<path d="M{c},{c} L{c + R * math.cos(a0):.1f},{c + R * math.sin(a0):.1f} A{R},{R} 0 {big} 1 '
                      f'{c + R * math.cos(a1):.1f},{c + R * math.sin(a1):.1f} Z" fill="{f}" stroke="{INK}" stroke-width="2"/>')
        return _svg(size, size, b, label or "fraction circle")
    rows = rows or 1
    cols = parts // rows
    W = min(520, cols * 56) if kind == "bar" else size * cols / max(cols, rows)
    H = rows * 56 if kind == "bar" else size * rows / max(cols, rows)
    w, h = (W - 4) / cols, (H - 4) / rows
    k = 0
    for r in range(rows):
        for cc in range(cols):
            f = FILL if k in idx else "#fff"
            b += f'<rect x="{2 + cc * w:.1f}" y="{2 + r * h:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{f}" stroke="{INK}" stroke-width="2"/>'
            k += 1
    return _svg(W, H, b, label or "fraction diagram")


# ---------------------------------------------------------------- polygons with labels
def polygon(points, side_labels=None, angle_labels=None, right_angles=(), vertex_labels=None, scale=None,
            fill="#fff", max_size=340, pad=46, label=None, dashed_sides=(), marks=None):
    """
    points: vertices in any units, listed in order (y up). The drawing is scaled to fit.
    side_labels[i] labels side points[i]→points[i+1] (outside the shape).
    angle_labels: {vertex_index: "x"} drawn inside the angle; right_angles: vertex indices to mark with a square.
    vertex_labels: ["A","B",...]; marks: {side_index: n} equal-length hatch marks.
    Diagrams are NOT drawn to scale for angle questions unless you make them so — say "not drawn to scale" in the prompt when relevant.
    """
    xs, ys = [p[0] for p in points], [p[1] for p in points]
    sc = scale or max_size / max(max(xs) - min(xs), max(ys) - min(ys), 1e-9)
    P = [(pad + (x - min(xs)) * sc, pad + (max(ys) - y) * sc) for x, y in points]
    W, H = (max(xs) - min(xs)) * sc + 2 * pad, (max(ys) - min(ys)) * sc + 2 * pad
    cx, cy = sum(p[0] for p in P) / len(P), sum(p[1] for p in P) / len(P)
    d = "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in P) + " Z"
    b = f'<path d="{d}" fill="{fill}" stroke="{INK}" stroke-width="2.5" stroke-linejoin="round"/>'
    n = len(P)
    for i in range(n):
        (x1, y1), (x2, y2) = P[i], P[(i + 1) % n]
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        dx, dy = x2 - x1, y2 - y1
        ln = math.hypot(dx, dy) or 1
        nx, ny = -dy / ln, dx / ln
        if (mx + nx - cx) ** 2 + (my + ny - cy) ** 2 < (mx - nx - cx) ** 2 + (my - ny - cy) ** 2:
            nx, ny = -nx, -ny
        if side_labels and i < len(side_labels) and side_labels[i]:
            b += _t(mx + nx * 22, my + ny * 22 + 5, side_labels[i])
        if marks and marks.get(i):
            for k in range(marks[i]):
                off = (k - (marks[i] - 1) / 2) * 6
                ox, oy = mx + dx / ln * off, my + dy / ln * off
                b += f'<line x1="{ox - nx * 7:.1f}" y1="{oy - ny * 7:.1f}" x2="{ox + nx * 7:.1f}" y2="{oy + ny * 7:.1f}" stroke="{INK}" stroke-width="2"/>'
    for i in range(n):
        (px, py), (ax, ay), (bx, by) = P[i], P[i - 1], P[(i + 1) % n]
        ua = ((ax - px), (ay - py)); la = math.hypot(*ua); ua = (ua[0] / la, ua[1] / la)
        ub = ((bx - px), (by - py)); lb = math.hypot(*ub); ub = (ub[0] / lb, ub[1] / lb)
        if i in right_angles:
            s = 14
            b += (f'<path d="M{px + ua[0] * s:.1f},{py + ua[1] * s:.1f} L{px + (ua[0] + ub[0]) * s:.1f},{py + (ua[1] + ub[1]) * s:.1f} '
                  f'L{px + ub[0] * s:.1f},{py + ub[1] * s:.1f}" fill="none" stroke="{INK}" stroke-width="1.5"/>')
        if angle_labels and i in angle_labels:
            r = 26
            a0, a1 = math.atan2(ua[1], ua[0]), math.atan2(ub[1], ub[0])
            diff = (a1 - a0) % (2 * math.pi)
            sweep = 1
            if diff > math.pi:
                a0, a1 = a1, a0
                diff = 2 * math.pi - diff
            b += (f'<path d="M{px + r * math.cos(a0):.1f},{py + r * math.sin(a0):.1f} A{r},{r} 0 0 {sweep} '
                  f'{px + r * math.cos(a1):.1f},{py + r * math.sin(a1):.1f}" fill="none" stroke="{ACCENT}" stroke-width="1.8"/>')
            am = a0 + diff / 2
            b += _t(px + (r + 16) * math.cos(am), py + (r + 16) * math.sin(am) + 5, angle_labels[i], size=15, fill=ACCENT, weight="bold")
        if vertex_labels and i < len(vertex_labels) and vertex_labels[i]:
            vx, vy = px - cx, py - cy
            lv = math.hypot(vx, vy) or 1
            b += _t(px + vx / lv * 16, py + vy / lv * 16 + 5, vertex_labels[i], weight="bold")
    return _svg(W, H, b, label or "shape")


def angle_fig(deg, label="", size=260, base_len=180, show_arc=True, label_value=None):
    """Two rays from a vertex: one horizontal, one at `deg` degrees (anticlockwise). Good for classifying/estimating angles."""
    vx, vy = 40, size - 50
    a = math.radians(deg)
    H = size
    b = f'<line x1="{vx}" y1="{vy}" x2="{vx + base_len}" y2="{vy}" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
    ex, ey = vx + base_len * math.cos(a), vy - base_len * math.sin(a)
    minx = min(vx, ex)
    shift = 20 - minx if minx < 20 else 0
    b += f'<line x1="{vx}" y1="{vy}" x2="{ex:.1f}" y2="{ey:.1f}" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
    if show_arc:
        r = 34
        if abs(deg - 90) < 1e-6:
            b += f'<path d="M{vx + 18},{vy} v-18 h-18" fill="none" stroke="{ACCENT}" stroke-width="2"/>'
        else:
            big = 1 if deg > 180 else 0
            b += (f'<path d="M{vx + r},{vy} A{r},{r} 0 {big} 0 {vx + r * math.cos(a):.1f},{vy - r * math.sin(a):.1f}" '
                  f'fill="none" stroke="{ACCENT}" stroke-width="2"/>')
        am = a / 2
        txt = label if label else (f"{label_value}°" if label_value else "")
        if txt:
            b += _t(vx + 56 * math.cos(am), vy - 56 * math.sin(am) + 5, txt, fill=ACCENT, weight="bold")
    W = max(vx + base_len, ex) + 20 + shift
    return _svg(W, H, f'<g transform="translate({shift:.1f},0)">{b}</g>', "angle")


# ---------------------------------------------------------------- grids
def grid_shape(cells, rows, cols, cell=34, shade=True, half_cells=None, label=None):
    """Squared paper with some whole squares shaded (cells = list of (row, col)). half_cells: list of (row,col,'tl'|'tr'|'bl'|'br') triangles."""
    W, H = cols * cell + 4, rows * cell + 4
    b = ""
    for (r, c) in cells:
        b += f'<rect x="{2 + c * cell}" y="{2 + r * cell}" width="{cell}" height="{cell}" fill="{FILL if shade else "#fff"}"/>'
    for (r, c, corner) in (half_cells or []):
        x, y = 2 + c * cell, 2 + r * cell
        pts = {"tl": [(x, y), (x + cell, y), (x, y + cell)], "tr": [(x, y), (x + cell, y), (x + cell, y + cell)],
               "bl": [(x, y), (x, y + cell), (x + cell, y + cell)], "br": [(x + cell, y), (x + cell, y + cell), (x, y + cell)]}[corner]
        b += f'<polygon points="{" ".join(f"{a},{c2}" for a, c2 in pts)}" fill="{FILL}"/>'
    for r in range(rows + 1):
        b += f'<line x1="2" y1="{2 + r * cell}" x2="{2 + cols * cell}" y2="{2 + r * cell}" stroke="#9a96b0" stroke-width="1"/>'
    for c in range(cols + 1):
        b += f'<line x1="{2 + c * cell}" y1="2" x2="{2 + c * cell}" y2="{2 + rows * cell}" stroke="#9a96b0" stroke-width="1"/>'
    # outline of the whole-cell shape
    cs = set(map(tuple, cells))
    for (r, c) in cs:
        x, y = 2 + c * cell, 2 + r * cell
        if (r - 1, c) not in cs: b += f'<line x1="{x}" y1="{y}" x2="{x + cell}" y2="{y}" stroke="{INK}" stroke-width="3"/>'
        if (r + 1, c) not in cs: b += f'<line x1="{x}" y1="{y + cell}" x2="{x + cell}" y2="{y + cell}" stroke="{INK}" stroke-width="3"/>'
        if (r, c - 1) not in cs: b += f'<line x1="{x}" y1="{y}" x2="{x}" y2="{y + cell}" stroke="{INK}" stroke-width="3"/>'
        if (r, c + 1) not in cs: b += f'<line x1="{x + cell}" y1="{y}" x2="{x + cell}" y2="{y + cell}" stroke="{INK}" stroke-width="3"/>'
    return _svg(W, H, b, label or "shape on squared grid")


def coordinate_grid(xmin, xmax, ymin, ymax, points=None, polygons=None, lines=None, cell=32, labels_every=1,
                    polygon_labels=None, mirror=None, label=None):
    """
    Axes with gridlines. points={"A":(2,3)}; polygons=[[(x,y),...]] (filled, outlined);
    polygon_labels=["A","B"] placed at each polygon's centre; lines=[((x1,y1),(x2,y2))] full lines;
    mirror=((x1,y1),(x2,y2)) dashed mirror line.
    """
    pad = 34
    mk = _uid("ax")
    W, H = (xmax - xmin) * cell + 2 * pad, (ymax - ymin) * cell + 2 * pad
    X = lambda x: pad + (x - xmin) * cell
    Y = lambda y: pad + (ymax - y) * cell
    b = ""
    for x in range(xmin, xmax + 1):
        b += f'<line x1="{X(x)}" y1="{Y(ymin)}" x2="{X(x)}" y2="{Y(ymax)}" stroke="#d3d0e2" stroke-width="1"/>'
    for y in range(ymin, ymax + 1):
        b += f'<line x1="{X(xmin)}" y1="{Y(y)}" x2="{X(xmax)}" y2="{Y(y)}" stroke="#d3d0e2" stroke-width="1"/>'
    ax_y = 0 if ymin <= 0 <= ymax else ymin
    ax_x = 0 if xmin <= 0 <= xmax else xmin
    b += f'<line x1="{X(xmin) - 8}" y1="{Y(ax_y)}" x2="{X(xmax) + 22}" y2="{Y(ax_y)}" stroke="{INK}" stroke-width="2" marker-end="url(#{mk})"/>'
    b += f'<line x1="{X(ax_x)}" y1="{Y(ymin) + 8}" x2="{X(ax_x)}" y2="{Y(ymax) - 22}" stroke="{INK}" stroke-width="2" marker-end="url(#{mk})"/>'
    b += _t(X(xmax) + 24, Y(ax_y) + 20, "x", size=15, weight="bold", extra='font-style="italic"')
    b += _t(X(ax_x) - 16, Y(ymax) - 16, "y", size=15, weight="bold", extra='font-style="italic"')
    for x in range(xmin, xmax + 1):
        if x != ax_x and x % labels_every == 0:
            b += _t(X(x), Y(ax_y) + 18, x, size=12)
    for y in range(ymin, ymax + 1):
        if y != ax_y and y % labels_every == 0:
            b += _t(X(ax_x) - 8, Y(y) + 4, y, size=12, anchor="end")
    b += _t(X(ax_x) - 8, Y(ax_y) + 16, "0", size=12, anchor="end")
    for k, poly in enumerate(polygons or []):
        b += f'<polygon points="{" ".join(f"{X(x)},{Y(y)}" for x, y in poly)}" fill="{FILL}" fill-opacity=".8" stroke="{INK}" stroke-width="2.5"/>'
        if polygon_labels and k < len(polygon_labels):
            gx = sum(p[0] for p in poly) / len(poly); gy = sum(p[1] for p in poly) / len(poly)
            b += _t(X(gx), Y(gy) + 6, polygon_labels[k], weight="bold")
    for (p1, p2) in (lines or []):
        b += f'<line x1="{X(p1[0])}" y1="{Y(p1[1])}" x2="{X(p2[0])}" y2="{Y(p2[1])}" stroke="{ACCENT}" stroke-width="2.5"/>'
    if mirror:
        (p1, p2) = mirror
        b += f'<line x1="{X(p1[0])}" y1="{Y(p1[1])}" x2="{X(p2[0])}" y2="{Y(p2[1])}" stroke="{ACCENT}" stroke-width="2.5" stroke-dasharray="8 6"/>'
    for name, (x, y) in (points or {}).items():
        b += f'<circle cx="{X(x)}" cy="{Y(y)}" r="5" fill="{ACCENT}"/>' + _t(X(x) + 10, Y(y) - 8, name, anchor="start", weight="bold")
    defs = f'<defs><marker id="{mk}" markerUnits="userSpaceOnUse" markerWidth="12" markerHeight="12" refX="10" refY="6" orient="auto"><path d="M0,0 L12,6 L0,12 z" fill="{INK}"/></marker></defs>'
    return _svg(W, H, defs + b, label or "coordinate grid")


# ---------------------------------------------------------------- place value & arrays
def base10(hundreds=0, tens=0, ones=0, unit=12, label=None):
    """Base-ten blocks: hundred squares, ten rods, unit cubes."""
    x, b, H = 6, "", 10 * unit + 12
    for _ in range(hundreds):
        for r in range(10):
            for c in range(10):
                b += f'<rect x="{x + c * unit}" y="{6 + r * unit}" width="{unit}" height="{unit}" fill="{FILL}" stroke="{INK}" stroke-width=".8"/>'
        b += f'<rect x="{x}" y="6" width="{10 * unit}" height="{10 * unit}" fill="none" stroke="{INK}" stroke-width="2"/>'
        x += 10 * unit + 14
    for _ in range(tens):
        for r in range(10):
            b += f'<rect x="{x}" y="{6 + r * unit}" width="{unit}" height="{unit}" fill="{FILL}" stroke="{INK}" stroke-width=".8"/>'
        b += f'<rect x="{x}" y="6" width="{unit}" height="{10 * unit}" fill="none" stroke="{INK}" stroke-width="2"/>'
        x += unit + 8
    if ones:
        x += 6
        for k in range(ones):
            r, c = divmod(k, 2)
            b += f'<rect x="{x + c * (unit + 4)}" y="{6 + 10 * unit - (r + 1) * (unit + 4) + 4}" width="{unit}" height="{unit}" fill="{FILL}" stroke="{INK}" stroke-width="1.5"/>'
        x += 2 * (unit + 4)
    return _svg(x + 6, H, b, label or "base ten blocks")


def dot_array(rows, cols, r=10, gap=30, label=None):
    b = "".join(f'<circle cx="{gap / 2 + c * gap + 4}" cy="{gap / 2 + rr * gap + 4}" r="{r}" fill="{ACCENT}"/>' for rr in range(rows) for c in range(cols))
    return _svg(cols * gap + 8, rows * gap + 8, b, label or f"array of {rows} rows and {cols} columns")


def objects(n, per_row=10, kind="circle", size=30, label=None):
    """n simple counters for counting/estimating questions."""
    b = ""
    for k in range(n):
        rr, c = divmod(k, per_row)
        x, y = 6 + c * (size + 8), 6 + rr * (size + 8)
        if kind == "star":
            pts = []
            for i in range(10):
                ang = math.pi / 2 + i * math.pi / 5
                rad = size / 2 if i % 2 == 0 else size / 4.5
                pts.append(f"{x + size / 2 + rad * math.cos(ang):.1f},{y + size / 2 - rad * math.sin(ang):.1f}")
            b += f'<polygon points="{" ".join(pts)}" fill="{GOLD}" stroke="{INK}" stroke-width="1.2"/>'
        elif kind == "square":
            b += f'<rect x="{x + 2}" y="{y + 2}" width="{size - 4}" height="{size - 4}" fill="{FILL}" stroke="{INK}" stroke-width="1.5"/>'
        else:
            b += f'<circle cx="{x + size / 2}" cy="{y + size / 2}" r="{size / 2 - 2}" fill="{FILL}" stroke="{INK}" stroke-width="1.5"/>'
    rows = math.ceil(n / per_row)
    return _svg(min(n, per_row) * (size + 8) + 8, rows * (size + 8) + 8, b, label or "objects to count")


def tally(n, label=None):
    b, x = "", 6
    groups, rem = divmod(n, 5)
    for g in range(groups + (1 if rem else 0)):
        k = 4 if g < groups else rem
        for i in range(k):
            b += f'<line x1="{x + i * 10}" y1="6" x2="{x + i * 10}" y2="44" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
        if g < groups:
            b += f'<line x1="{x - 5}" y1="40" x2="{x + 35}" y2="10" stroke="{INK}" stroke-width="3" stroke-linecap="round"/>'
        x += 54
    return _svg(max(x, 20), 50, b, label or f"tally of {n}")


# ---------------------------------------------------------------- 2D / 3D shapes
def shape2d(name, size=120, fill=FILL, label=None):
    s, c, r = size, size / 2, size / 2 - 8
    def reg(n, rot=-90):
        return " ".join(f"{c + r * math.cos(math.radians(rot + 360 * k / n)):.1f},{c + r * math.sin(math.radians(rot + 360 * k / n)):.1f}" for k in range(n))
    shapes = {
        "circle": f'<circle cx="{c}" cy="{c}" r="{r}"/>',
        "oval": f'<ellipse cx="{c}" cy="{c}" rx="{r}" ry="{r * 0.62}"/>',
        "semicircle": f'<path d="M{c - r},{c + r * .35} A{r},{r} 0 0 1 {c + r},{c + r * .35} Z"/>',
        "triangle": f'<polygon points="{reg(3)}"/>',
        "right triangle": f'<polygon points="12,{s - 12} 12,14 {s - 12},{s - 12}"/>',
        "square": f'<rect x="14" y="14" width="{s - 28}" height="{s - 28}"/>',
        "rectangle": f'<rect x="6" y="{s * .25}" width="{s - 12}" height="{s * .5}"/>',
        "pentagon": f'<polygon points="{reg(5)}"/>',
        "hexagon": f'<polygon points="{reg(6, 0)}"/>',
        "heptagon": f'<polygon points="{reg(7)}"/>',
        "octagon": f'<polygon points="{reg(8, 22.5)}"/>',
        "rhombus": f'<polygon points="{c},8 {s - 20},{c} {c},{s - 8} 20,{c}"/>',
        "kite": f'<polygon points="{c},8 {s - 22},{s * .38} {c},{s - 8} 22,{s * .38}"/>',
        "parallelogram": f'<polygon points="{s * .3},{s * .25} {s - 6},{s * .25} {s * .7},{s * .75} 6,{s * .75}"/>',
        "trapezium": f'<polygon points="{s * .3},{s * .25} {s * .7},{s * .25} {s - 6},{s * .75} 6,{s * .75}"/>',
        "star": "",
    }
    if name not in shapes:
        raise ValueError(f"unknown shape {name}; choose from {list(shapes)}")
    body = shapes[name]
    if name == "star":
        pts = " ".join(f"{c + (r if k % 2 == 0 else r * .42) * math.cos(math.radians(-90 + 36 * k)):.1f},{c + (r if k % 2 == 0 else r * .42) * math.sin(math.radians(-90 + 36 * k)):.1f}" for k in range(10))
        body = f'<polygon points="{pts}"/>'
    return _svg(s, s, f'<g fill="{fill}" stroke="{INK}" stroke-width="3" stroke-linejoin="round">{body}</g>', label or name)


def shape3d(name, size=140, fill=FILL, label=None):
    """Simple oblique drawings with hidden edges dashed: cube, cuboid, cylinder, cone, sphere, square pyramid, triangular prism."""
    s = size
    st = f'fill="{fill}" stroke="{INK}" stroke-width="2.5" stroke-linejoin="round"'
    dash = f'fill="none" stroke="{INK}" stroke-width="1.5" stroke-dasharray="5 4"'
    if name in ("cube", "cuboid"):
        w, h, d = (s * .55, s * .55, s * .28) if name == "cube" else (s * .72, s * .4, s * .25)
        x0, y0 = 8, s - 10 - h
        body = (f'<polygon {st} points="{x0},{y0} {x0 + w},{y0} {x0 + w},{y0 + h} {x0},{y0 + h}"/>'
                f'<polygon {st} points="{x0},{y0} {x0 + d},{y0 - d} {x0 + w + d},{y0 - d} {x0 + w},{y0}" fill-opacity=".7"/>'
                f'<polygon {st} points="{x0 + w},{y0} {x0 + w + d},{y0 - d} {x0 + w + d},{y0 + h - d} {x0 + w},{y0 + h}" fill-opacity=".5"/>'
                f'<path {dash} d="M{x0},{y0 + h} L{x0 + d},{y0 + h - d} L{x0 + w + d},{y0 + h - d} M{x0 + d},{y0 + h - d} L{x0 + d},{y0 - d}"/>')
        return _svg(w + d + 16, h + d + 20, f'<g transform="translate(0,{d - (s - 10 - h) + 10})">{body}</g>', label or name)
    if name == "cylinder":
        rx, ry, top, bot = s * .32, s * .1, s * .16, s * .84
        c = s / 2
        body = (f'<path {st} d="M{c - rx},{top} L{c - rx},{bot} A{rx},{ry} 0 0 0 {c + rx},{bot} L{c + rx},{top} Z"/>'
                f'<ellipse {st} cx="{c}" cy="{top}" rx="{rx}" ry="{ry}" fill-opacity=".7"/>'
                f'<path {dash} d="M{c - rx},{bot} A{rx},{ry} 0 0 1 {c + rx},{bot}"/>')
        return _svg(s, s, body, label or name)
    if name == "cone":
        rx, ry, c = s * .34, s * .1, s / 2
        body = (f'<path {st} d="M{c},{s * .08} L{c - rx},{s * .82} A{rx},{ry} 0 0 0 {c + rx},{s * .82} Z"/>'
                f'<path {dash} d="M{c - rx},{s * .82} A{rx},{ry} 0 0 1 {c + rx},{s * .82}"/>')
        return _svg(s, s, body, label or name)
    if name == "sphere":
        c, r = s / 2, s / 2 - 8
        body = f'<circle {st} cx="{c}" cy="{c}" r="{r}"/><path {dash} d="M{c - r},{c} A{r},{r * .3} 0 0 1 {c + r},{c}"/><path fill="none" stroke="{INK}" stroke-width="1.5" d="M{c - r},{c} A{r},{r * .3} 0 0 0 {c + r},{c}"/>'
        return _svg(s, s, body, label or name)
    if name == "square pyramid":
        A, B, C, D = (10, s * .8), (s * .62, s * .8), (s * .9, s * .6), (s * .38, s * .6)
        T = (s * .47, s * .08)
        f = lambda p: f"{p[0]:.1f},{p[1]:.1f}"
        body = (f'<polygon {st} points="{f(A)} {f(B)} {f(T)}"/><polygon {st} points="{f(B)} {f(C)} {f(T)}" fill-opacity=".6"/>'
                f'<path {dash} d="M{f(A)} L{f(D)} L{f(C)} M{f(D)} L{f(T)}"/>')
        return _svg(s, s * .88, body, label or name)
    if name == "triangular prism":
        A, B, T = (8, s * .8), (s * .42, s * .8), (s * .25, s * .38)
        dx, dy = s * .5, -s * .14
        o = lambda p: (p[0] + dx, p[1] + dy)
        f = lambda p: f"{p[0]:.1f},{p[1]:.1f}"
        body = (f'<polygon {st} points="{f(T)} {f(o(T))} {f(o(B))} {f(B)}" fill-opacity=".6"/>'
                f'<polygon {st} points="{f(A)} {f(B)} {f(T)}"/>'
                f'<path {dash} d="M{f(A)} L{f(o(A))} L{f(o(B))} M{f(o(A))} L{f(o(T))}"/>')
        return _svg(s * 1.02, s * .86, f'<g transform="translate(0,{-s * .02:.1f})">{body}</g>', label or name)
    raise ValueError("unknown 3D shape")


# ---------------------------------------------------------------- measuring
def measuring_scale(kind, max_value, major, minor, value, unit="", height=300, label=None):
    """kind: 'jug' (liquid level), 'thermometer' (can go negative: pass (min,max) as max_value), 'ruler' (horizontal, value=object length)."""
    if kind == "ruler":
        W = 70 + max_value * 50
        b = f'<rect x="10" y="40" width="{W - 20}" height="50" fill="#fdf6d8" stroke="{INK}" stroke-width="1.5"/>'
        steps = round(max_value / minor)
        for k in range(steps + 1):
            v = k * minor
            x = 20 + v * 50
            big = abs(v / major - round(v / major)) < 1e-9
            b += f'<line x1="{x}" y1="40" x2="{x}" y2="{40 + (22 if big else 11)}" stroke="{INK}" stroke-width="{1.6 if big else 1}"/>'
            if big:
                b += _t(x, 80, _nice(v), size=13)
        b += _t(W - 34, 70, unit, size=13, anchor="start")
        b += f'<rect x="20" y="14" width="{value * 50}" height="20" rx="4" fill="{FILL}" stroke="{INK}" stroke-width="2"/>'
        return _svg(W, 100, b, label or "ruler")
    lo, hi = (max_value if isinstance(max_value, (list, tuple)) else (0, max_value))
    T, B = 20, height - 20
    Y = lambda v: B - (v - lo) / (hi - lo) * (B - T)
    if kind == "jug":
        b = f'<rect x="60" y="{Y(value):.1f}" width="120" height="{B - Y(value):.1f}" fill="#bcd7f5"/>'
        b += f'<path d="M60,{T - 10} L60,{B} L180,{B} L180,{T - 10}" fill="none" stroke="{INK}" stroke-width="3"/>'
        x0 = 60
    else:
        b = f'<rect x="92" y="{T - 10}" width="26" height="{B - T + 20}" rx="13" fill="#fff" stroke="{INK}" stroke-width="2.5"/>'
        b += f'<circle cx="105" cy="{B + 14}" r="18" fill="#d9534f" stroke="{INK}" stroke-width="2.5"/>'
        b += f'<rect x="100" y="{Y(value):.1f}" width="10" height="{B + 4 - Y(value):.1f}" fill="#d9534f"/>'
        x0 = 118
    steps = round((hi - lo) / minor)
    for k in range(steps + 1):
        v = lo + k * minor
        big = abs(v / major - round(v / major)) < 1e-9
        y = Y(v)
        if kind == "jug":
            b += f'<line x1="{x0}" y1="{y:.1f}" x2="{x0 + (22 if big else 11)}" y2="{y:.1f}" stroke="{INK}" stroke-width="{1.8 if big else 1}"/>'
            if big:
                b += _t(x0 - 8, y + 5, f"{_nice(v)}", size=13, anchor="end")
        else:
            b += f'<line x1="{x0}" y1="{y:.1f}" x2="{x0 + (16 if big else 8)}" y2="{y:.1f}" stroke="{INK}" stroke-width="{1.8 if big else 1}"/>'
            if big:
                b += _t(x0 + 22, y + 5, f"{_nice(v)}", size=13, anchor="start")
    b += _t(120, B + 18, unit, size=13) if kind == "jug" else _t(70, T + 4, unit, size=14, anchor="end", weight="bold")
    return _svg(220, height + 30, b, label or kind)


# ---------------------------------------------------------------- data displays
def venn(set_names, a_only=(), both=(), b_only=(), outside=(), width=460, height=260, label=None):
    b = f'<rect x="4" y="4" width="{width - 8}" height="{height - 8}" fill="#fff" stroke="{INK}" stroke-width="2"/>'
    ca, cb, cy, r = width * .38, width * .62, height * .55, height * .36
    b += f'<circle cx="{ca}" cy="{cy}" r="{r}" fill="{FILL}" fill-opacity=".45" stroke="{INK}" stroke-width="2"/>'
    b += f'<circle cx="{cb}" cy="{cy}" r="{r}" fill="{GOLD}" fill-opacity=".25" stroke="{INK}" stroke-width="2"/>'
    b += _t(ca - r * .45, cy - r - 8, set_names[0], weight="bold") + _t(cb + r * .45, cy - r - 8, set_names[1], weight="bold")

    def place(items, x, y):
        out = ""
        for k, it in enumerate(items):
            out += _t(x + (k % 2) * 30 - 15 * (min(len(items), 2) - 1), y + (k // 2) * 22, it)
        return out
    b += place(a_only, ca - r * .5, cy - 10) + place(both, width / 2, cy - 10) + place(b_only, cb + r * .5, cy - 10)
    b += "".join(_t(24 + k * 30, height - 16, it) for k, it in enumerate(outside))
    return _svg(width, height, b, label or "Venn diagram")


def pie_chart(labels, values, size=300, show_values=False, label=None):
    tot = sum(values)
    c, r = size / 2, size / 2 - 10
    fills = [FILL, GOLD, "#9fd3b5", "#f4b6a8", "#a9c8ee", "#e2d4a0", "#cfcfcf"]
    a0, b, leg = -math.pi / 2, "", ""
    for i, (lab, v) in enumerate(zip(labels, values)):
        a1 = a0 + 2 * math.pi * v / tot
        big = 1 if a1 - a0 > math.pi else 0
        b += (f'<path d="M{c},{c} L{c + r * math.cos(a0):.1f},{c + r * math.sin(a0):.1f} A{r},{r} 0 {big} 1 {c + r * math.cos(a1):.1f},'
              f'{c + r * math.sin(a1):.1f} Z" fill="{fills[i % len(fills)]}" stroke="{INK}" stroke-width="2"/>')
        am = (a0 + a1) / 2
        b += _t(c + r * .62 * math.cos(am), c + r * .62 * math.sin(am) + 5, f"{lab}" + (f" ({v})" if show_values else ""), size=13, weight="bold")
        a0 = a1
    return _svg(size, size, b, label or "pie chart")


def line_graph(x_labels, values, y_step=1, y_min=0, y_max=None, y_label="", x_label="", title="", width=540, height=320, label=None):
    y_max = y_max or math.ceil(max(values) / y_step) * y_step
    L, R, T, B = 64, 20, 34 if title else 14, 58 if x_label else 40
    pw, ph = width - L - R, height - T - B
    Y = lambda v: T + ph - (v - y_min) / (y_max - y_min) * ph
    X = lambda i: L + pw * (i + .5) / len(values)
    b = _t(width / 2, 22, title, size=16, weight="bold") if title else ""
    k = 0
    while y_min + k * y_step <= y_max + 1e-9:
        v = y_min + k * y_step
        b += f'<line x1="{L}" y1="{Y(v):.1f}" x2="{L + pw}" y2="{Y(v):.1f}" stroke="#ccc"/>' + _t(L - 8, Y(v) + 5, _nice(v), size=13, anchor="end")
        k += 1
    pts = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(values))
    b += f'<polyline points="{pts}" fill="none" stroke="{ACCENT}" stroke-width="3"/>'
    for i, v in enumerate(values):
        b += f'<circle cx="{X(i):.1f}" cy="{Y(v):.1f}" r="4.5" fill="{ACCENT}"/>' + _t(X(i), T + ph + 20, x_labels[i], size=13)
    b += f'<line x1="{L}" y1="{T}" x2="{L}" y2="{T + ph}" stroke="{INK}" stroke-width="2"/><line x1="{L}" y1="{T + ph}" x2="{L + pw}" y2="{T + ph}" stroke="{INK}" stroke-width="2"/>'
    if y_label:
        b += _t(16, T + ph / 2, y_label, size=13, extra=f'transform="rotate(-90 16 {T + ph / 2})"')
    if x_label:
        b += _t(L + pw / 2, height - 10, x_label, size=13)
    return _svg(width, height, b, label or "line graph")
